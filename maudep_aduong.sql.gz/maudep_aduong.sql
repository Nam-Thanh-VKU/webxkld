-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th6 14, 2018 lúc 08:35 AM
-- Phiên bản máy phục vụ: 10.2.12-MariaDB
-- Phiên bản PHP: 7.1.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `maudep_aduong`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_commentmeta`
--

CREATE TABLE `rt_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_commentmeta`
--

INSERT INTO `rt_commentmeta` (`meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'rating', '5'),
(2, 1, 'verified', '0');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_comments`
--

CREATE TABLE `rt_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_comments`
--

INSERT INTO `rt_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 104, 'adminraothue', 'mailtrunggian01@gmail.com', '', '::1', '2017-12-04 22:57:43', '2017-12-04 15:57:43', 'sdfdf', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '', 0, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_cpd_counter`
--

CREATE TABLE `rt_cpd_counter` (
  `id` int(10) NOT NULL,
  `ip` int(10) UNSIGNED NOT NULL,
  `client` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `page` mediumint(9) NOT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referer` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_cpd_counter`
--

INSERT INTO `rt_cpd_counter` (`id`, `ip`, `client`, `date`, `page`, `country`, `referer`) VALUES
(1, 1121751540, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/63.4.160 Chrome/57.4.2987.160 Safari/537.36', '2017-06-15', 0, '', 'http://l.facebook.com/l.php?u=http%3A%2F%2Fraothue.ddns.net%2Fdemo%2Frt-core&#038;h=ATMDMzwZbgK-2UGngysG8Ucz02Q4L48DpQp5MKyKotP8E4E74r4ReB6zvMocLq2fZS'),
(2, 1121751539, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/63.4.160 Chrome/57.4.2987.160 Safari/537.36', '2017-06-15', 0, '', 'http://raothue.ddns.net/demo/rt-core/'),
(3, 2918996571, 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)', '2017-06-15', 39, '', ''),
(4, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-04', 0, '', ''),
(5, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-04', 0, '', 'http://localhost/RT/'),
(6, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-04', 0, '', ''),
(7, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-04', 0, '', ''),
(8, 392390006, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2017-07-04', 0, '', ''),
(9, 223146450, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2017-07-04', 0, '', ''),
(10, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-04', 38, '', 'http://raothue.ddns.net/demo/RT-Fix/'),
(11, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-04', 37, '', 'http://raothue.ddns.net/demo/RT-Fix/san-pham/may-loc-nuoc-ro-5/'),
(12, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/64.4.130 Chrome/58.4.3029.130 Safari/537.36', '2017-07-04', 39, '', 'http://raothue.ddns.net/demo/RT-Fix/'),
(13, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/64.4.130 Chrome/58.4.3029.130 Safari/537.36', '2017-07-04', -2, '', 'http://raothue.ddns.net/demo/RT-Fix/san-pham/may-loc-nuoc-ro-6/'),
(14, 1743668476, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-04', 0, '', ''),
(15, 1743668476, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-04', 38, '', 'http://raothue.ddns.net/demo/RT-Fix/'),
(16, 712281010, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-05', 0, '', ''),
(17, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-05', 0, '', ''),
(18, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-05', 37, '', 'http://raothue.ddns.net/demo/RT-Fix/'),
(19, 1963285907, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-05', 0, '', ''),
(20, 1984344676, 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G920F Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.95 Mobile', '2017-07-07', 0, '', 'http://hungrt.raothue.com/phongkhamphucnhanduong/lorem-ipsum-simply-dummy-text-printing-6/'),
(21, 1984344676, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36 Google (+https://developers.google.com/+/web/', '2017-07-07', 39, '', ''),
(22, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', '2017-07-11', 0, '', ''),
(23, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-19', 0, '', ''),
(24, 1984319673, 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4', '2017-07-20', 0, '', 'http://rtgroup.vn/hoangcuong/07/thoitrangminh/gioi-thieu/'),
(25, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-20', 0, '', ''),
(26, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-23', 0, '', ''),
(27, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-23', 36, '', 'http://raothue.ddns.net/demo/RT-Fix/'),
(28, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-23', 15, '', 'http://raothue.ddns.net/demo/RT-Fix/danh-muc/may-loc-nuoc-nano/'),
(29, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-23', 39, '', 'http://raothue.ddns.net/demo/RT-Fix/'),
(30, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', '2017-07-25', 0, '', ''),
(31, 1984344676, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2017-07-31', 0, '', ''),
(32, 1984344676, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2017-08-01', 0, '', ''),
(33, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', '2017-08-09', 0, '', ''),
(34, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', '2017-08-10', 0, '', ''),
(35, 3555131562, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2017-08-16', 0, '', ''),
(36, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', '2017-08-21', 0, '', ''),
(37, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/66.4.102 Chrome/60.4.3112.102 Safari/537.36', '2017-08-27', 0, '', ''),
(38, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-08-29', 0, '', ''),
(39, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-08-30', 0, '', ''),
(40, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-08-30', 0, '', 'http://localhost/RT_web/RT-Aug/'),
(41, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-05', 0, '', ''),
(42, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-05', 0, '', 'http://localhost/RT-Aug/'),
(43, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-05', 0, '', ''),
(44, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-06', 0, '', ''),
(45, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-06', 104, '', 'http://raothue.ddns.net/demo/RT-Aug/'),
(46, 223146450, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2017-09-07', 0, '', ''),
(47, 392390006, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2017-09-07', 0, '', ''),
(48, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-07', 0, '', ''),
(49, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-08', 0, '', ''),
(50, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-08', -2, '', 'http://raothue.ddns.net/demo/RT-Aug/'),
(51, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-11', 0, '', ''),
(52, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-11', 103, '', 'http://raothue.ddns.net/demo/RT-Aug/'),
(53, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-11', 100, '', 'http://raothue.ddns.net/demo/RT-Aug/danh-muc/tranh-tuong-phong-ngu/'),
(54, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-11', 104, '', 'http://raothue.ddns.net/demo/RT-Aug/'),
(55, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-11', -2, '', 'http://raothue.ddns.net/demo/RT-Aug/san-pham/tranh-ve-tuong-kho-lon-d06/'),
(56, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-12', 0, '', ''),
(57, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-12', 104, '', 'http://raothue.ddns.net/demo/RT-Aug/'),
(58, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/66.4.104 Chrome/60.4.3112.104 Safari/537.36', '2017-09-12', 0, '', 'http://xedienxuanvui.com/san-pham/xe-dap-dien/'),
(59, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-13', 0, '', ''),
(60, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-13', 103, '', 'http://raothue.ddns.net/demo/RT-Aug/'),
(61, 223146450, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2017-09-14', 0, '', ''),
(62, 1963021963, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-14', 0, '', ''),
(63, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-14', 0, '', ''),
(64, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-14', 104, '', 'http://raothue.ddns.net/demo/RT-Aug/'),
(65, 1984344676, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-16', 0, '', 'http://hungrt.raothue.com/mayhutsua24/lien-he/'),
(66, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 0, '', ''),
(67, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 100, '', 'http://raothue.ddns.net/demo/RT-Aug/'),
(68, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 101, '', 'http://raothue.ddns.net/demo/RT-Aug/danh-muc/tranh-tuong-cafe/'),
(69, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 102, '', 'http://raothue.ddns.net/demo/RT-Aug/danh-muc/tranh-tuong-cafe/'),
(70, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 99, '', 'http://raothue.ddns.net/demo/RT-Aug/danh-muc/tranh-tuong-cafe/'),
(71, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 8, '', 'http://raothue.ddns.net/demo/RT-Aug/danh-muc/tranh-tuong-cafe/'),
(72, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 9, '', 'http://raothue.ddns.net/demo/RT-Aug/gio-hang/'),
(73, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 10, '', 'http://raothue.ddns.net/demo/RT-Aug/thanh-toan/'),
(74, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', -2, '', 'http://raothue.ddns.net/demo/RT-Aug/tai-khoan/'),
(75, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 2, '', 'http://raothue.ddns.net/demo/RT-Aug/san-pham/tranh-ve-tuong-kho-lon-d04/'),
(76, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 95, '', 'http://raothue.ddns.net/demo/RT-Aug/'),
(77, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 15, '', 'http://raothue.ddns.net/demo/RT-Aug/iran-tuyen-bo-da-duoi-may-bay-tham-u2-cua-8/'),
(78, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 0, '', ''),
(79, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 0, '', 'http://localhost/code-toiuu/'),
(80, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 0, '', ''),
(81, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', '2017-09-17', 0, '', 'http://localhost/code-toiuu/'),
(82, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-10-30', 0, '', ''),
(83, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-10-31', 0, '', 'http://localhost/baby/wp-content/themes/RT/assets/css/support.css'),
(84, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-10-31', 0, '', 'http://localhost/baby/'),
(85, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(86, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/rt-blog-shortcode.css'),
(87, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(88, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(89, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(90, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(91, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(92, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(93, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(94, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(95, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(96, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(97, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(98, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(99, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(100, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(101, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(102, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(103, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(104, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(105, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(106, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(107, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(108, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(109, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(110, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(111, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(112, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(113, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(114, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(115, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(116, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(117, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(118, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(119, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(120, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(121, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(122, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/wp-content/themes/RT/assets/css/main.css'),
(123, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-01', 0, '', 'http://localhost/thangmaychauau/'),
(124, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-07', 0, '', ''),
(125, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', '2017-11-07', 0, '', 'http://localhost/code-toiuu/'),
(126, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-11-29', 0, '', ''),
(127, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-11-29', 0, '', 'http://localhost/code-toiuu/'),
(128, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-11-29', 104, '', 'http://localhost/code-toiuu/'),
(129, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-11-29', 0, '', 'http://localhost/code-toiuu/san-pham/tranh-ve-tuong-kho-lon-d06/'),
(130, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-04', 0, '', ''),
(131, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-04', 0, '', 'http://localhost/code-toiuu/'),
(132, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-04', 0, '', 'http://localhost/code-toiuu/'),
(133, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-04', 104, '', 'http://localhost/code-toiuu/'),
(134, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-06', 0, '', ''),
(135, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-06', 0, '', 'http://localhost/code-toiuu/'),
(136, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-07', 0, '', ''),
(137, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-07', 0, '', 'http://localhost/code-toiuu/'),
(138, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-07', 0, '', ''),
(139, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-07', 0, '', 'http://localhost/code-toiuu/'),
(140, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-07', 101, '', 'http://localhost/code-toiuu/'),
(141, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-07', 101, '', 'http://localhost/code-toiuu/'),
(142, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-07', 101, '', 'http://localhost/code-toiuu/'),
(143, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-09', 0, '', ''),
(144, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', '2017-12-09', 0, '', 'http://localhost/code-toiuu/'),
(145, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-22', 0, '', ''),
(146, 1952990682, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-22', 0, '', 'http://cuongrt.raothue.com/phong/'),
(147, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', 0, '', 'http://cuongrt.raothue.com/phong/'),
(148, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', 140, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(149, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', -2, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(150, 3730619735, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '2018-01-23', 0, '', ''),
(151, 1962484833, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '2018-01-23', 0, '', ''),
(152, 3060576282, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '2018-01-23', 0, '', ''),
(153, 3731572989, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '2018-01-23', 0, '', ''),
(154, 3069650552, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '2018-01-23', 0, '', ''),
(155, 1963758256, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '2018-01-23', 0, '', ''),
(156, 1949585842, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '2018-01-23', 0, '', ''),
(157, 1886523786, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '2018-01-23', 0, '', ''),
(158, 3066795660, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '2018-01-23', 0, '', ''),
(159, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', 147, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(160, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', 113, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(161, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', 167, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(162, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', 168, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(163, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', -38, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(164, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', 138, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(165, 1984319673, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-23', 0, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/gioi-thieu/'),
(166, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 0, '', ''),
(167, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 166, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(168, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', -38, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(169, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 138, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(170, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 140, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/gioi-thieu/'),
(171, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 145, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/thi-truong-xkld/'),
(172, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', -2, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/tuyen-dung/'),
(173, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 15, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/tin-tuc/'),
(174, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 113, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/lien-he/'),
(175, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 168, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(176, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 167, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(177, 1952990682, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 0, '', 'http://cuongrt.raothue.com/phong/'),
(178, 1952990682, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 166, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(179, 1952990682, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', -2, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/don-hang-dieu-duong-tai-nhat-ban/'),
(180, 1952990682, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-24', 168, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/tin-tuc/'),
(181, 1984319673, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-25', 0, '', 'http://cuongrt.raothue.com/phong/'),
(182, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-01-25', 0, '', ''),
(183, 1952990682, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-01-26', 0, '', 'http://cuongrt.raothue.com/phong/'),
(184, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-27', 0, '', 'http://cuongrt.raothue.com/phong/'),
(185, 3340638370, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534+ (KHTML, like Gecko) BingPreview/1.0b', '2018-01-28', 0, '', ''),
(186, 676180383, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534+ (KHTML, like Gecko) BingPreview/1.0b', '2018-01-28', 0, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/ve-chung-toi/'),
(187, 712088464, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-28', 0, '', 'http://cuongrt.raothue.com/phong/'),
(188, 712088464, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-28', 138, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(189, 712088464, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-01-29', 0, '', 'http://cuongrt.raothue.com/phong/'),
(190, 712088464, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-29', 168, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(191, 712088464, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-29', 138, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/don-hang-lao-dong-cong-hoa-sec/'),
(192, 712088464, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-29', 140, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/gioi-thieu/'),
(193, 712088464, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-29', 116, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(194, 712088464, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-29', -2, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(195, 1952990682, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-29', 0, '', 'http://cuongrt.raothue.com/phong/'),
(196, 1952990682, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-29', 166, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(197, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-30', 0, '', ''),
(198, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-30', 138, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(199, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-30', 140, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/gioi-thieu/'),
(200, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-30', -2, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/thi-truong-xkld/'),
(201, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-30', 145, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/tin-tuc/page/2/'),
(202, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-30', 15, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/tuyen-dung/'),
(203, 1952990682, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-30', 0, '', 'http://cuongrt.raothue.com/phong/'),
(204, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-31', 0, '', 'http://cuongrt.raothue.com/phong/'),
(205, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-31', 138, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(206, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-31', 168, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(207, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-01-31', -2, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/don-hang-lao-dong-cong-hoa-sec/'),
(208, 250623999, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.0 Mobile/14F89 Safari/602.1', '2018-02-03', 168, '', 'https://www.google.com.vn/'),
(209, 250623999, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.0 Mobile/14F89 Safari/602.1', '2018-02-03', 0, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/don-hang-lao-dong-cong-hoa-sec/'),
(210, 712098403, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-04', 0, '', 'http://cuongrt.raothue.com/phong/'),
(211, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-05', 0, '', 'http://cuongrt.raothue.com/phong/'),
(212, 1094177467, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534+ (KHTML, like Gecko) BingPreview/1.0b', '2018-02-07', 113, '', ''),
(213, 1984319673, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-09', 0, '', 'http://cuongrt.raothue.com/phong/'),
(214, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-09', 0, '', 'http://cuongrt.raothue.com/phong/'),
(215, 1963457040, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-09', 0, '', ''),
(216, 1963457040, 'Mozilla/5.0 (Linux; Android 6.0.1; MI 4W Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36', '2018-02-09', 15, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(217, 1963457040, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-10', 0, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(218, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-10', 0, '', ''),
(219, 1984344676, 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Mobile Safari/537.36', '2018-02-10', 168, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/'),
(220, 1984344676, 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Mobile Safari/537.36', '2018-02-10', 15, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/don-hang-lao-dong-cong-hoa-sec/'),
(221, 2214402433, 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53 BingPreview/1.', '2018-02-16', 0, '', ''),
(222, 2214402876, 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53 BingPreview/1.', '2018-02-16', 0, '', ''),
(223, 1907158023, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36', '2018-02-20', 0, '', 'http://cuongrt.raothue.com/phong/'),
(224, 457408614, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_3 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) CriOS/63.0.3239.73 Mobile/14G60 Safari/602.1', '2018-02-20', 168, '', 'https://www.google.com.vn/'),
(225, 457408614, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_3 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) CriOS/63.0.3239.73 Mobile/14G60 Safari/602.1', '2018-02-20', 0, '', 'http://cuongrt.raothue.com/phong/anhduongtaybac/don-hang-lao-dong-cong-hoa-sec/'),
(226, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-02-23', 0, '', ''),
(227, 3075541153, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', '2018-02-23', 0, '', ''),
(228, 453236734, 'Mozilla/5.0 (Linux; Android 7.0; SM-A710F Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36', '2018-02-25', 0, '', ''),
(229, 453236734, 'Mozilla/5.0 (Linux; Android 7.0; SM-A710F Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36', '2018-02-25', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(230, 453236734, 'Mozilla/5.0 (Linux; Android 7.0; SM-A710F Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36', '2018-02-25', 167, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(231, 453236734, 'Mozilla/5.0 (Linux; Android 7.0; SM-A710F Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36', '2018-02-25', 166, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(232, 712099390, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-25', 0, '', ''),
(233, 1984344676, 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Mobile Safari/537.36', '2018-02-26', 0, '', ''),
(234, 1984344676, 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Mobile Safari/537.36', '2018-02-26', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(235, 1121753043, 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)', '2018-02-26', 168, '', ''),
(236, 1984344676, 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Mobile Safari/537.36', '2018-02-26', 167, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(237, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-26', 95, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(238, 458025286, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36', '2018-02-27', 0, '', ''),
(239, 223146450, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-02-27', 0, '', ''),
(240, 392390006, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-02-27', 0, '', ''),
(241, 458025286, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2018-02-28', 0, '', ''),
(242, 1984344676, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-02-28', 0, '', ''),
(243, 2064679398, 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac OS X) AppleWebKit/604.5.6 (KHTML, like Gecko) Mobile/15D60 Zalo iOS', '2018-02-28', 0, '', ''),
(244, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-02-28', 138, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(245, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-02-28', 140, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=138'),
(246, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-02-28', -2, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=140'),
(247, 1908326974, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-02-28', 0, '', ''),
(248, 458025286, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2018-03-01', 0, '', ''),
(249, 1984344676, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-01', 0, '', ''),
(250, 712096327, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36', '2018-03-01', 0, '', ''),
(251, 458025286, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2018-03-02', 0, '', ''),
(252, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-02', 0, '', ''),
(253, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-02', -2, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(254, 392390006, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-03-02', 0, '', ''),
(255, 223146450, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-03-02', 0, '', ''),
(256, 2884507287, 'Mozilla/5.0 (iPad; CPU OS 11_1 like Mac OS X) AppleWebKit/604.3.5 (KHTML, like Gecko) Version/11.0 Mobile/15B93 Safari/604.1', '2018-03-02', 168, '', 'https://www.google.com.vn/');
INSERT INTO `rt_cpd_counter` (`id`, `ip`, `client`, `date`, `page`, `country`, `referer`) VALUES
(257, 2884507287, 'Mozilla/5.0 (iPad; CPU OS 11_1 like Mac OS X) AppleWebKit/604.3.5 (KHTML, like Gecko) Version/11.0 Mobile/15B93 Safari/604.1', '2018-03-02', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?p=168'),
(258, 458025286, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2018-03-03', 0, '', ''),
(259, 3251233014, 'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)', '2018-03-03', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?author=1'),
(260, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', '2018-03-03', 0, '', ''),
(261, 1906375233, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.126 Chrome/62.4.3202.126 Safari/537.36', '2018-03-03', 0, '', ''),
(262, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', '2018-03-03', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(263, 712389539, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-03', 0, '', ''),
(264, 3251233014, 'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)', '2018-03-04', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?author=1'),
(265, 250035898, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2018-03-04', 0, '', ''),
(266, 1962987231, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-04', 0, '', ''),
(267, 1962987231, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-04', -38, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(268, 1962987231, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-04', 138, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(269, 1962987231, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-04', 140, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=138'),
(270, 1962987231, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-04', -2, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=140'),
(271, 1962987231, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-04', 145, '', 'http://khomaudepraothue.com/anhduongtaybac/?cat=2'),
(272, 1962987231, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-04', 15, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=145'),
(273, 1962987231, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-04', 152, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(274, 2918994997, 'facebookexternalhit/1.1', '2018-03-04', 0, '', ''),
(275, 1962987231, 'Mozilla/5.0 (Linux; Android 7.0; SM-P585Y Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/64.0.3282.137 Safari/537.36 [FB_', '2018-03-04', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(276, 1962987231, 'Mozilla/5.0 (Linux; Android 7.0; SM-P585Y Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/64.0.3282.137 Safari/537.36 [FB_', '2018-03-04', 166, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(277, 250052336, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-05', 0, '', ''),
(278, 458025286, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2018-03-05', 0, '', ''),
(279, 3251233014, 'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)', '2018-03-05', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?author=1'),
(280, 2883975084, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393', '2018-03-06', 0, '', ''),
(281, 1984344676, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-06', 0, '', ''),
(282, 458025286, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2018-03-06', 0, '', ''),
(283, 712129319, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-06', 0, '', 'https://www.google.com.vn/'),
(284, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-07', 0, '', ''),
(285, 250052336, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-07', 0, '', ''),
(286, 250052336, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-07', 140, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(287, 250052336, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-07', 145, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(288, 250052336, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-07', 138, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=145'),
(289, 250052336, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-07', 15, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=138'),
(290, 3251233014, 'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)', '2018-03-07', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?author=1'),
(291, 250035898, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', '2018-03-07', 0, '', ''),
(292, 1984319583, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36', '2018-03-08', 0, '', ''),
(293, 1984319583, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36', '2018-03-08', 138, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(294, 1984319583, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36', '2018-03-08', 140, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=138'),
(295, 1984319583, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36', '2018-03-08', -2, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=140'),
(296, 1984319583, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36', '2018-03-08', 145, '', 'http://khomaudepraothue.com/anhduongtaybac/?cat=2'),
(297, 1984319583, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36', '2018-03-08', 15, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=145'),
(298, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-08', 0, '', ''),
(299, 1962987231, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36', '2018-03-08', 0, '', ''),
(300, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-09', 0, '', ''),
(301, 1908329802, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-09', 0, '', ''),
(302, 392390006, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-03-09', 0, '', ''),
(303, 1962968919, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-03-09', 0, '', ''),
(304, 1962968919, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-03-09', 138, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(305, 3251233014, 'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)', '2018-03-10', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?author=1'),
(306, 985376557, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-12', 0, '', ''),
(307, 2064695058, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-12', 0, '', ''),
(308, 223146450, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-03-12', 0, '', ''),
(309, 1984344676, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-12', 0, '', ''),
(310, 392390006, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-03-12', 0, '', ''),
(311, 392390006, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-03-13', 0, '', ''),
(312, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 0, '', ''),
(313, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 138, '', ''),
(314, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 140, '', ''),
(315, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', -2, '', ''),
(316, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 2, '', ''),
(317, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 145, '', ''),
(318, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 15, '', ''),
(319, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', -39, '', ''),
(320, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', -38, '', ''),
(321, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', -40, '', ''),
(322, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', -42, '', ''),
(323, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', -41, '', ''),
(324, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 167, '', ''),
(325, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 168, '', ''),
(326, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 95, '', ''),
(327, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 166, '', ''),
(328, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 147, '', ''),
(329, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 152, '', ''),
(330, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 113, '', ''),
(331, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 154, '', ''),
(332, 246383916, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-03-13', 116, '', ''),
(333, 246512149, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-14', 0, '', ''),
(334, 250074288, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36', '2018-03-14', 0, '', ''),
(335, 250074288, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36', '2018-03-14', 154, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(336, 250074288, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36', '2018-03-14', 140, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=154'),
(337, 250074288, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36', '2018-03-14', 138, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=140'),
(338, 250074288, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36', '2018-03-14', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(339, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-14', 0, '', ''),
(340, 2065186448, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/66.4.134 Chrome/60.4.3112.134 Safari/537.36', '2018-03-14', 0, '', ''),
(341, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-03-15', 0, '', ''),
(342, 1963059974, 'Mozilla/5.0 (Linux; Android 6.0; CPH1609 Build/MRA58K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', '2018-03-15', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(343, 1953224971, 'Mozilla/5.0 (Linux; Android 7.0; SM-J730G Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', '2018-03-15', 0, '', ''),
(344, 1984365332, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.125 Safari/537.36', '2018-03-15', 0, '', ''),
(345, 1984365332, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.125 Safari/537.36', '2018-03-15', -2, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(346, 1984365332, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.125 Safari/537.36', '2018-03-15', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/?cat=2'),
(347, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-16', 0, '', ''),
(348, 712004657, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-16', 0, '', ''),
(349, 1984344676, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-03-17', 0, '', ''),
(350, 1953209961, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-17', 0, '', ''),
(351, 1953224971, 'Mozilla/5.0 (Linux; Android 7.0; SM-J730G Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', '2018-03-17', 0, '', ''),
(352, 3251233014, 'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)', '2018-03-19', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?author=1'),
(353, 3075550236, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-03-20', 0, '', ''),
(354, 3741066485, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-03-21', 0, '', ''),
(355, 1984344676, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36', '2018-03-21', 0, '', ''),
(356, 223146450, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-03-21', 0, '', ''),
(357, 1758575823, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-03-21', 0, '', ''),
(358, 3251233014, 'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)', '2018-03-21', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?author=1'),
(359, 712111744, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-03-21', 0, '', ''),
(360, 1953007303, 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac OS X) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0 Mobile/15D60 Safari/604.1', '2018-03-24', 0, '', 'https://www.google.com.vn/'),
(361, 985376752, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-03-24', 0, '', ''),
(362, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-03-27', 0, '', ''),
(363, 3075546391, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-03-27', 0, '', ''),
(364, 3075546391, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-03-27', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(365, 712002183, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-01', 0, '', ''),
(366, 712002183, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-01', 167, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(367, 712002183, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-01', 93, '', 'http://khomaudepraothue.com/anhduongtaybac/?p=167'),
(368, 2065191287, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-02', 0, '', ''),
(369, 2065191287, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-02', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(370, 3340638565, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534+ (KHTML, like Gecko) BingPreview/1.0b', '2018-04-03', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(371, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-03', 0, '', ''),
(372, 712002183, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-04', 0, '', ''),
(373, 712002183, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-04', 138, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(374, 712002183, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-04', 140, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=138'),
(375, 712002183, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-04', -2, '', 'http://khomaudepraothue.com/anhduongtaybac/?page_id=140'),
(376, 712002183, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-04', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/?cat=2'),
(377, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-04', 0, '', ''),
(378, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-05', 0, '', ''),
(379, 712082891, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-06', 0, '', ''),
(380, 712082891, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-06', 166, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(381, 712082891, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-06', 167, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(382, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-07', 0, '', ''),
(383, 3081457080, 'Mozilla/5.0 (BB10; Kbd) AppleWebKit/537.35+ (KHTML, like Gecko) Version/10.3.3.2205 Mobile Safari/537.35+', '2018-04-08', 0, '', 'http://www.bing.com/'),
(384, 3081457080, 'Mozilla/5.0 (BB10; Kbd) AppleWebKit/537.35+ (KHTML, like Gecko) Version/10.3.3.2205 Mobile Safari/537.35+', '2018-04-08', 167, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(385, 3081457080, 'Mozilla/5.0 (BB10; Kbd) AppleWebKit/537.35+ (KHTML, like Gecko) Version/10.3.3.2205 Mobile Safari/537.35+', '2018-04-08', 166, '', 'http://khomaudepraothue.com/anhduongtaybac/?p=167'),
(386, 712105979, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-09', 0, '', ''),
(387, 250053903, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-04-09', 0, '', ''),
(388, 3251232983, 'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)', '2018-04-09', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?author=1'),
(389, 1984319673, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-04-10', 0, '', ''),
(390, 457726327, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.0.3705;)', '2018-04-11', 0, '', ''),
(391, 1907956173, 'Mozilla/5.0 (iPad; CPU OS 10_1_1 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) coc_coc_browser/68.4.160 CriOS/62.4.3202.160 Mobile/14B100 Sa', '2018-04-13', 0, '', ''),
(392, 1984344676, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-13', 0, '', ''),
(393, 457736519, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-13', 0, '', ''),
(394, 706923702, 'Mozilla/5.0 (Linux; Android 5.1; A1601 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', '2018-04-16', 0, '', ''),
(395, 712004592, 'Mozilla/5.0 (Linux; Android 5.1; A1601 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', '2018-04-16', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(396, 706923702, 'Mozilla/5.0 (Linux; Android 5.1; A1601 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', '2018-04-16', 167, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(397, 706923702, 'Mozilla/5.0 (Linux; Android 5.1; A1601 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36', '2018-04-16', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/?p=167'),
(398, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-16', 0, '', ''),
(399, 712004600, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-17', 0, '', ''),
(400, 245535010, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-17', 0, '', ''),
(401, 245535010, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-17', 166, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(402, 1984319673, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.190 Chrome/62.4.3202.190 Safari/537.36', '2018-04-18', 0, '', ''),
(403, 1984344676, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.190 Chrome/62.4.3202.190 Safari/537.36', '2018-04-18', 0, '', ''),
(404, 457737899, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-21', 0, '', ''),
(405, 676180304, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534+ (KHTML, like Gecko) BingPreview/1.0b', '2018-04-22', 0, '', ''),
(406, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-23', 0, '', ''),
(407, 1962949858, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.154 Chrome/62.4.3202.154 Safari/537.36', '2018-04-23', 0, '', ''),
(408, 1984381806, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_2 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/65.0.3325.152 Mobile/14C92 Safari/602.1', '2018-04-23', 0, '', ''),
(409, 1963392200, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-24', 0, '', ''),
(410, 712006100, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-25', 0, '', ''),
(411, 712006100, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-04-25', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(412, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36', '2018-04-27', 0, '', ''),
(413, 245526698, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-05-02', 0, '', ''),
(414, 2884576465, 'Mozilla/5.0 (Linux; Android 6.0; CAM-L21 Build/HUAWEICAM-L21) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.126 Mobile Safari/537.36', '2018-05-02', 167, '', 'http://www.google.com/'),
(415, 2884576465, 'Mozilla/5.0 (Linux; Android 6.0; CAM-L21 Build/HUAWEICAM-L21) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.126 Mobile Safari/537.36', '2018-05-02', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/?p=167'),
(416, 3802142907, 'Mozilla/5.0 (Linux; Android 5.1; A1601 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.126 Mobile Safari/537.36', '2018-05-03', 0, '', ''),
(417, 3075488809, 'Mozilla/5.0 (Linux; Android 5.1; A1601 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.126 Mobile Safari/537.36', '2018-05-03', 0, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(418, 3802142907, 'Mozilla/5.0 (Linux; Android 5.1; A1601 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.126 Mobile Safari/537.36', '2018-05-03', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(419, 1984302583, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36', '2018-05-04', 0, '', ''),
(420, 1984344676, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.194 Chrome/62.4.3202.194 Safari/537.36', '2018-05-05', 0, '', ''),
(421, 245526698, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '2018-05-07', 0, '', ''),
(422, 245526698, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '2018-05-07', 138, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(423, 1908314506, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '2018-05-07', 0, '', ''),
(424, 245526698, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '2018-05-07', -38, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(425, 985350849, 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '2018-05-09', 0, '', ''),
(426, 3076195048, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '2018-05-09', 0, '', ''),
(427, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '2018-05-12', 0, '', ''),
(428, 1906324622, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.194 Chrome/62.4.3202.194 Safari/537.36', '2018-05-14', 0, '', ''),
(429, 1984319673, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.208 Chrome/64.4.3282.208 Safari/537.36', '2018-05-16', 0, '', ''),
(430, 712042265, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.194 Chrome/62.4.3202.194 Safari/537.36', '2018-05-17', 0, '', ''),
(431, 712042265, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.194 Chrome/62.4.3202.194 Safari/537.36', '2018-05-17', 168, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(432, 712042265, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/68.4.194 Chrome/62.4.3202.194 Safari/537.36', '2018-05-17', 15, '', 'http://khomaudepraothue.com/anhduongtaybac/?p=168'),
(433, 1984319673, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.208 Chrome/64.4.3282.208 Safari/537.36', '2018-05-18', 0, '', ''),
(434, 245519994, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '2018-05-18', 0, '', ''),
(435, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-05-21', 0, '', ''),
(436, 1906324622, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.208 Chrome/64.4.3282.208 Safari/537.36', '2018-05-21', 0, '', ''),
(437, 250044758, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-05-23', 0, '', ''),
(438, 3075488920, 'Mozilla/5.0 (Linux; Android 5.1.1; A37fw Build/LMY47V) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Mobile Safari/537.36 OPR/37.0.2192.1', '2018-05-24', 0, '', ''),
(439, 1934905952, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-05-27', 0, '', ''),
(440, 712483720, 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_3_1 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) CriOS/66.0.3359.122 Mobile/15E302 Safari/604.1', '2018-05-27', 0, '', ''),
(441, 1963048909, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.208 Chrome/64.4.3282.208 Safari/537.36', '2018-05-28', 0, '', ''),
(442, 1984319673, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-05-28', 0, '', ''),
(443, 223146450, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-05-28', 0, '', ''),
(444, 3075481731, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-05-28', 0, '', ''),
(445, 246521107, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-05-28', 0, '', ''),
(446, 1984319673, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-05-30', 0, '', ''),
(447, 1984344676, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.208 Chrome/64.4.3282.208 Safari/537.36', '2018-06-01', 0, '', ''),
(448, 457383670, 'Mozilla/5.0 (Linux; Android 7.0; SM-G610F Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 Mobile Safari/537.', '2018-06-01', 0, '', ''),
(449, 1984344676, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.208 Chrome/64.4.3282.208 Safari/537.36', '2018-06-01', 140, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(450, 1984319673, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-06-04', 0, '', ''),
(451, 223146450, 'Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5', '2018-06-04', 0, '', ''),
(452, 20273860, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36', '2018-06-06', 0, '', ''),
(453, 712016989, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-06-06', 0, '', ''),
(454, 712016989, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-06-06', -39, '', 'http://khomaudepraothue.com/anhduongtaybac/'),
(455, 1741103380, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-06-06', 0, '', ''),
(456, 1907137009, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-06-06', 0, '', ''),
(457, 1984300310, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.222 Chrome/64.4.3282.222 Safari/537.36', '2018-06-06', 0, '', ''),
(458, 2064690596, 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_1 like Mac OS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0 Mobile/15C153 Safari/604.1', '2018-06-06', 0, '', 'https://www.google.com.vn/'),
(459, 1952965022, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0', '2018-06-06', 0, '', ''),
(460, 20298546, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '2018-06-06', 0, '', ''),
(461, 712434893, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36', '2018-06-06', 0, '', ''),
(462, 1984319997, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36', '2018-06-07', 0, '', ''),
(463, 1963454887, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0', '2018-06-09', 0, '', ''),
(464, 1906324622, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.222 Chrome/64.4.3282.222 Safari/537.36', '2018-06-12', 0, '', ''),
(465, 2885051026, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.222 Chrome/64.4.3282.222 Safari/537.36', '2018-06-12', 0, '', ''),
(466, 2885051026, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', '2018-06-13', 0, '', ''),
(467, 2884110819, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/70.4.222 Chrome/64.4.3282.222 Safari/537.36', '2018-06-14', 0, '', ''),
(468, 1984319673, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36', '2018-06-14', 0, '', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_links`
--

CREATE TABLE `rt_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_options`
--

CREATE TABLE `rt_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_options`
--

INSERT INTO `rt_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://raothue.ddns.net/demo/rt-core', 'yes'),
(2, 'home', 'http://raothue.ddns.net/demo/rt-core', 'yes'),
(3, 'blogname', 'Công ty Cổ Phần và Phát triển Ánh Dương Tây Bắc', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mailtrunggian01@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '2', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'j F, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:9:{i:0;s:27:\"colorpicker/colorpicker.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:25:\"count-per-day/counter.php\";i:3;s:23:\"ml-slider/ml-slider.php\";i:4;s:37:\"tinymce-advanced/tinymce-advanced.php\";i:5;s:37:\"user-role-editor/user-role-editor.php\";i:6;s:27:\"woocommerce/woocommerce.php\";i:7;s:24:\"wordpress-seo/wp-seo.php\";i:8;s:19:\"wp-smtp/wp-smtp.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '7', 'yes'),
(38, 'default_email_category', '2', 'yes'),
(39, 'recently_edited', 'a:4:{i:0;s:112:\"/home/rt/domains/raothue.ddns.net/public_html/demo/RT-Fix/wp-content/plugins/disable-xml-rpc/disable-xml-rpc.php\";i:1;s:93:\"/home/rt/domains/raothue.ddns.net/public_html/demo/RT-Fix/wp-content/themes/RT/front-page.php\";i:2;s:88:\"/home/rt/domains/raothue.ddns.net/public_html/demo/RT-Fix/wp-content/themes/RT/style.css\";i:3;s:0:\"\";}', 'no'),
(40, 'template', 'RT', 'yes'),
(41, 'stylesheet', 'RT', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '0', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:4:{i:2;a:3:{s:5:\"title\";s:21:\"Thông tin liên hệ\";s:4:\"text\";s:203:\"Công ty TNHH Aqua-Pura Việt Nam\r\n\r\nTrụ sở chính: Số 268 Mai anh Tuấn - Đống Đa - Hà Nội\r\n\r\nĐiện thoại: 0906 55 67 69\r\n\r\nEmail: aquapuravn@gmail.com\r\n\r\nWebsite: www.aquapura.com.vn\";s:6:\"filter\";s:7:\"content\";}i:4;a:4:{s:5:\"title\";s:29:\"Nộp hồ sơ trực tuyến\";s:4:\"text\";s:48:\"[contact-form-7 id=\"201\" title=\"Nộp hồ sơ\"]\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:5;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:49:\"[contact-form-7 id=\"193\" title=\"form đăng ký\"]\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:3:{s:11:\"counter.php\";s:23:\"count_per_day_uninstall\";s:27:\"wp-pagenavi/wp-pagenavi.php\";s:14:\"__return_false\";s:23:\"loginizer/loginizer.php\";s:22:\"loginizer_deactivation\";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'rt_user_roles', 'a:9:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:141:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:14:\"ure_edit_roles\";b:1;s:16:\"ure_create_roles\";b:1;s:16:\"ure_delete_roles\";b:1;s:23:\"ure_create_capabilities\";b:1;s:23:\"ure_delete_capabilities\";b:1;s:18:\"ure_manage_options\";b:1;s:15:\"ure_reset_roles\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:17:\"edit_shop_webhook\";b:1;s:17:\"read_shop_webhook\";b:1;s:19:\"delete_shop_webhook\";b:1;s:18:\"edit_shop_webhooks\";b:1;s:25:\"edit_others_shop_webhooks\";b:1;s:21:\"publish_shop_webhooks\";b:1;s:26:\"read_private_shop_webhooks\";b:1;s:20:\"delete_shop_webhooks\";b:1;s:28:\"delete_private_shop_webhooks\";b:1;s:30:\"delete_published_shop_webhooks\";b:1;s:27:\"delete_others_shop_webhooks\";b:1;s:26:\"edit_private_shop_webhooks\";b:1;s:28:\"edit_published_shop_webhooks\";b:1;s:25:\"manage_shop_webhook_terms\";b:1;s:23:\"edit_shop_webhook_terms\";b:1;s:25:\"delete_shop_webhook_terms\";b:1;s:25:\"assign_shop_webhook_terms\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:10:\"copy_posts\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:10:\"copy_posts\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:12:\"Khách hàng\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:110:{s:20:\"assign_product_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:25:\"assign_shop_webhook_terms\";b:1;s:19:\"delete_others_pages\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_others_products\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:27:\"delete_others_shop_webhooks\";b:1;s:12:\"delete_pages\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:23:\"delete_private_products\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_private_shop_webhooks\";b:1;s:14:\"delete_product\";b:1;s:20:\"delete_product_terms\";b:1;s:15:\"delete_products\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:25:\"delete_published_products\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:30:\"delete_published_shop_webhooks\";b:1;s:18:\"delete_shop_coupon\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:19:\"delete_shop_coupons\";b:1;s:17:\"delete_shop_order\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:18:\"delete_shop_orders\";b:1;s:19:\"delete_shop_webhook\";b:1;s:25:\"delete_shop_webhook_terms\";b:1;s:20:\"delete_shop_webhooks\";b:1;s:17:\"edit_others_pages\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_others_products\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:25:\"edit_others_shop_webhooks\";b:1;s:10:\"edit_pages\";b:1;s:10:\"edit_posts\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:21:\"edit_private_products\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_private_shop_webhooks\";b:1;s:12:\"edit_product\";b:1;s:18:\"edit_product_terms\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_published_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:23:\"edit_published_products\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:28:\"edit_published_shop_webhooks\";b:1;s:16:\"edit_shop_coupon\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:17:\"edit_shop_coupons\";b:1;s:15:\"edit_shop_order\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:16:\"edit_shop_orders\";b:1;s:17:\"edit_shop_webhook\";b:1;s:23:\"edit_shop_webhook_terms\";b:1;s:18:\"edit_shop_webhooks\";b:1;s:18:\"edit_theme_options\";b:1;s:10:\"edit_users\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:7:\"level_0\";b:1;s:7:\"level_1\";b:1;s:7:\"level_2\";b:1;s:7:\"level_3\";b:1;s:7:\"level_4\";b:1;s:7:\"level_5\";b:1;s:7:\"level_6\";b:1;s:7:\"level_7\";b:1;s:7:\"level_8\";b:1;s:7:\"level_9\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:14:\"manage_options\";b:1;s:20:\"manage_product_terms\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:25:\"manage_shop_webhook_terms\";b:1;s:18:\"manage_woocommerce\";b:1;s:17:\"moderate_comments\";b:1;s:13:\"publish_pages\";b:1;s:13:\"publish_posts\";b:1;s:16:\"publish_products\";b:1;s:20:\"publish_shop_coupons\";b:1;s:19:\"publish_shop_orders\";b:1;s:21:\"publish_shop_webhooks\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:21:\"read_private_products\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:24:\"read_private_shop_orders\";b:1;s:26:\"read_private_shop_webhooks\";b:1;s:12:\"read_product\";b:1;s:16:\"read_shop_coupon\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"read_shop_webhook\";b:1;s:12:\"upload_files\";b:1;s:24:\"view_woocommerce_reports\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:38:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:10:\"copy_posts\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:10:\"copy_posts\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'WPLANG', 'vi', 'yes'),
(95, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:12:{s:6:\"footer\";a:1:{i:0;s:6:\"text-2\";}s:19:\"wp_inactive_widgets\";a:1:{i:0;s:13:\"media_video-2\";}s:6:\"header\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:10:\"nav_menu-2\";i:1;s:16:\"rt_widget_post-2\";i:2;s:22:\"facebook-like-widget-2\";i:3;s:19:\"rt_widget_product-2\";}s:9:\"sidebar-2\";a:6:{i:0;s:16:\"support_online-2\";i:1;s:6:\"text-4\";i:2;s:22:\"facebook-like-widget-3\";i:3;s:16:\"rt_widget_post-3\";i:4;s:7:\"imgqc-4\";i:5;s:20:\"countperday_widget-2\";}s:11:\"site-footer\";a:1:{i:0;s:16:\"rt-widget-text-3\";}s:10:\"front-page\";a:1:{i:0;s:10:\"nav_menu-4\";}s:15:\"before-footer-1\";a:1:{i:0;s:6:\"text-5\";}s:8:\"footer-1\";a:2:{i:0;s:16:\"rt-widget-text-2\";i:1;s:7:\"imgqc-3\";}s:8:\"footer-2\";a:1:{i:0;s:10:\"nav_menu-3\";}s:8:\"footer-3\";a:1:{i:0;s:7:\"imgqc-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(101, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:2:{i:2;a:11:{s:13:\"attachment_id\";i:0;s:3:\"url\";s:43:\"https://www.youtube.com/watch?v=rV_dtahuM4w\";s:5:\"title\";s:5:\"Video\";s:7:\"preload\";s:8:\"metadata\";s:7:\"content\";s:0:\"\";s:3:\"mp4\";s:0:\"\";s:3:\"m4v\";s:0:\"\";s:4:\"webm\";s:0:\"\";s:3:\"ogv\";s:0:\"\";s:3:\"flv\";s:0:\"\";s:4:\"loop\";b:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:4:{i:2;a:2:{s:5:\"title\";s:23:\"Danh mục sản phẩm\";s:8:\"nav_menu\";i:22;}i:3;a:2:{s:5:\"title\";s:29:\"Dịch vụ của chúng tôi\";s:8:\"nav_menu\";i:37;}i:4;a:2:{s:5:\"title\";s:26:\"Danh mục thị trường\";s:8:\"nav_menu\";i:23;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'cron', 'a:12:{i:1519318800;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519321522;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1519357998;a:2:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519359638;a:2:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1519359639;a:1:{s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1519359680;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519359864;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519369415;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519804728;a:1:{s:25:\"wpseo_ping_search_engines\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1520510400;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}i:1521087070;a:1:{s:26:\"upgrader_scheduled_cleanup\";a:1:{s:32:\"9eefae5eac0c0ec17493e2f4f522fedc\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{i:0;i:202;}}}}s:7:\"version\";i:2;}', 'yes'),
(109, 'theme_mods_twentysixteen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1497500485;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(121, 'can_compress_scripts', '0', 'no'),
(140, 'current_theme', 'RT Core 2017 V1', 'yes'),
(141, 'theme_mods_RT', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:22;s:9:\"secondary\";i:22;}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(142, 'theme_switched', '', 'yes'),
(143, 'widget_cs_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(144, 'widget_support_online', 'a:2:{i:2;a:10:{s:16:\"number_supporter\";s:1:\"2\";s:10:\"data_style\";s:12:\"gd_support_1\";s:5:\"title\";s:25:\"Hỗ trợ trực tuyến\";s:8:\"link_img\";s:81:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/support.png\";s:16:\"supporter_1_name\";s:27:\"Hỗ trợ trực tuyến 1\";s:17:\"supporter_1_phone\";s:12:\"0982 906 369\";s:16:\"supporter_1_mail\";s:0:\"\";s:16:\"supporter_2_name\";s:27:\"Hỗ trợ trực tuyến 2\";s:17:\"supporter_2_phone\";s:13:\"0966 99 63 43\";s:16:\"supporter_2_mail\";s:24:\"anhduongtaybac@gmail.com\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(145, 'widget_imgqc', 'a:4:{i:2;a:5:{s:5:\"title\";s:27:\"Bản đồ chỉ đường\";s:7:\"img_num\";s:1:\"1\";s:11:\"img_title_0\";s:0:\"\";s:9:\"img_src_0\";s:77:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/map.png\";s:10:\"img_link_0\";s:0:\"\";}i:3;a:17:{s:5:\"title\";s:0:\"\";s:7:\"img_num\";s:1:\"5\";s:11:\"img_title_0\";s:0:\"\";s:9:\"img_src_0\";s:79:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/icon1.png\";s:10:\"img_link_0\";s:0:\"\";s:11:\"img_title_1\";s:0:\"\";s:9:\"img_src_1\";s:79:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/icon2.png\";s:10:\"img_link_1\";s:0:\"\";s:11:\"img_title_2\";s:0:\"\";s:9:\"img_src_2\";s:79:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/icon3.png\";s:10:\"img_link_2\";s:0:\"\";s:11:\"img_title_3\";s:0:\"\";s:9:\"img_src_3\";s:79:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/icon4.png\";s:10:\"img_link_3\";s:0:\"\";s:11:\"img_title_4\";s:0:\"\";s:9:\"img_src_4\";s:79:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/icon5.png\";s:10:\"img_link_4\";s:0:\"\";}i:4;a:17:{s:5:\"title\";s:22:\"Đơn vị liên kết\";s:7:\"img_num\";s:1:\"5\";s:11:\"img_title_0\";s:0:\"\";s:9:\"img_src_0\";s:81:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/doitac1.png\";s:10:\"img_link_0\";s:0:\"\";s:11:\"img_title_1\";s:0:\"\";s:9:\"img_src_1\";s:81:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/doitac2.png\";s:10:\"img_link_1\";s:0:\"\";s:11:\"img_title_2\";s:0:\"\";s:9:\"img_src_2\";s:81:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/doitac3.png\";s:10:\"img_link_2\";s:0:\"\";s:11:\"img_title_3\";s:0:\"\";s:9:\"img_src_3\";s:81:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/doitac4.png\";s:10:\"img_link_3\";s:0:\"\";s:11:\"img_title_4\";s:0:\"\";s:9:\"img_src_4\";s:81:\"http://khomaudepraothue.com/anhduongtaybac/wp-content/uploads/2018/01/doitac5.png\";s:10:\"img_link_4\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(146, 'widget_facebook-like-widget', 'a:3:{i:2;a:7:{s:5:\"title\";s:13:\"Like Facebook\";s:8:\"page_url\";s:41:\"https://www.facebook.com/webgiareRaoThue/\";s:5:\"width\";s:3:\"233\";s:12:\"color_scheme\";s:5:\"light\";s:10:\"show_faces\";s:2:\"on\";s:11:\"show_stream\";N;s:11:\"show_header\";N;}i:3;a:7:{s:5:\"title\";s:13:\"Like Facebook\";s:8:\"page_url\";s:41:\"https://www.facebook.com/webgiareRaoThue/\";s:5:\"width\";s:3:\"235\";s:12:\"color_scheme\";s:5:\"light\";s:10:\"show_faces\";s:2:\"on\";s:11:\"show_stream\";N;s:11:\"show_header\";N;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(147, 'widget_products-slider', 'a:2:{i:2;a:5:{s:5:\"title\";s:26:\"Sản phẩm khuyến mãi\";s:3:\"cat\";s:2:\"17\";s:6:\"numpro\";s:1:\"5\";s:8:\"autoplay\";s:0:\"\";s:5:\"limit\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(148, 'widget_imgpartner', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(151, '_cs_options', 'a:58:{s:7:\"favicon\";s:2:\"80\";s:4:\"logo\";s:3:\"133\";s:11:\"logo_mobile\";s:3:\"133\";s:10:\"mts_slides\";s:2:\"12\";s:13:\"numberproduct\";s:1:\"5\";s:16:\"product_category\";a:4:{i:2;a:1:{s:20:\"product_category_sub\";s:2:\"38\";}i:3;a:1:{s:20:\"product_category_sub\";s:2:\"39\";}i:4;a:1:{s:20:\"product_category_sub\";s:2:\"41\";}i:5;a:1:{s:20:\"product_category_sub\";s:2:\"42\";}}s:10:\"numberpost\";s:1:\"3\";s:10:\"responsive\";b:1;s:9:\"site_full\";b:1;s:12:\"layout_width\";s:6:\"custom\";s:13:\"layout_custom\";s:4:\"1020\";s:11:\"layout_home\";s:5:\"right\";s:15:\"layout_category\";s:5:\"right\";s:13:\"layout_single\";s:5:\"right\";s:11:\"layout_page\";s:5:\"right\";s:10:\"main_color\";s:0:\"\";s:10:\"background\";a:6:{s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:0:\"\";s:8:\"position\";s:0:\"\";s:10:\"attachment\";s:0:\"\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";}s:8:\"gr_mennu\";s:319:\"background-image: -moz-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\r\n                          background-image: -webkit-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\r\n                          background-image: -ms-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\";s:7:\"bg_menu\";a:6:{s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:0:\"\";s:8:\"position\";s:0:\"\";s:10:\"attachment\";s:0:\"\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";}s:15:\"gr_widget_title\";s:319:\"background-image: -moz-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\r\n                          background-image: -webkit-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\r\n                          background-image: -ms-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\";s:15:\"bg_widget_title\";a:6:{s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:0:\"\";s:8:\"position\";s:0:\"\";s:10:\"attachment\";s:0:\"\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";}s:17:\"bg_category_title\";a:6:{s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:9:\"no-repeat\";s:8:\"position\";s:11:\"left center\";s:10:\"attachment\";s:0:\"\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";}s:17:\"gr_category_title\";s:307:\"background-image: -moz-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\r\n                    background-image: -webkit-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\r\n                    background-image: -ms-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\";s:9:\"bg_footer\";a:6:{s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:9:\"no-repeat\";s:8:\"position\";s:13:\"center center\";s:10:\"attachment\";s:0:\"\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";}s:9:\"gr_footer\";s:307:\"background-image: -moz-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\r\n                    background-image: -webkit-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\r\n                    background-image: -ms-linear-gradient( 90deg, rgb(220,34,39) 0%, rgb(238,58,63) 100%);\";s:10:\"bg_submenu\";a:6:{s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:0:\"\";s:8:\"position\";s:0:\"\";s:10:\"attachment\";s:0:\"\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";}s:13:\"bg_hover_menu\";a:6:{s:5:\"image\";s:0:\"\";s:6:\"repeat\";s:0:\"\";s:8:\"position\";s:0:\"\";s:10:\"attachment\";s:0:\"\";s:4:\"size\";s:0:\"\";s:5:\"color\";s:0:\"\";}s:13:\"layout_header\";s:7:\"default\";s:24:\"vertical_mega_menu_title\";s:23:\"Danh mục sản phẩm\";s:9:\"style_prd\";s:15:\"product_style_1\";s:13:\"tooltip_image\";b:1;s:13:\"zoomimg_style\";s:8:\"vertical\";s:24:\"rt_options_archive_image\";b:1;s:14:\"style_category\";s:1:\"3\";s:20:\"before_footer_widget\";s:1:\"1\";s:13:\"footer_column\";s:1:\"3\";s:9:\"copyright\";s:0:\"\";s:16:\"rt_header_script\";a:1:{i:1;a:1:{s:19:\"header_script_value\";s:0:\"\";}}s:16:\"rt_footer_script\";a:1:{i:1;a:1:{s:19:\"footer_script_value\";s:0:\"\";}}s:11:\"product_cat\";s:0:\"\";s:11:\"banner_full\";b:0;s:7:\"top_bar\";b:0;s:15:\"sticky_nav_menu\";b:0;s:18:\"vertical_mega_menu\";b:0;s:20:\"enable_header_search\";b:0;s:7:\"on_cart\";b:0;s:11:\"buy_now_btn\";b:0;s:9:\"icon_cart\";b:0;s:8:\"info_btn\";b:0;s:9:\"quickview\";b:0;s:16:\"quickview_mobile\";b:0;s:7:\"tooltip\";b:0;s:13:\"tooltip_title\";b:0;s:13:\"tooltip_price\";b:0;s:18:\"check_using_cmt_fb\";b:0;s:7:\"zoomimg\";b:0;s:18:\"rt_options_archive\";b:0;s:17:\"enable_breadcrumb\";b:0;}', 'yes'),
(154, 'recently_activated', 'a:0:{}', 'yes'),
(165, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.0.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1497500571;s:7:\"version\";s:3:\"4.8\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(166, 'count_per_day', 'a:31:{s:7:\"version\";s:5:\"3.5.7\";s:10:\"onlinetime\";i:300;s:4:\"user\";i:0;s:10:\"user_level\";i:0;s:9:\"autocount\";i:1;s:4:\"bots\";s:143:\"bot\nspider\nsearch\ncrawler\nask.com\nvalidator\nsnoopy\nsuchen.de\nsuchbaer.de\nshelob\nsemager\nxenu\nsuch_de\nia_archiver\nMicrosoft URL Control\nnetluchs\";s:15:\"dashboard_posts\";i:20;s:20:\"dashboard_last_posts\";i:20;s:19:\"dashboard_last_days\";i:7;s:13:\"show_in_lists\";i:1;s:10:\"chart_days\";i:60;s:12:\"chart_height\";i:200;s:9:\"countries\";i:20;s:17:\"exclude_countries\";s:0:\"\";s:9:\"startdate\";s:0:\"\";s:10:\"startcount\";s:0:\"\";s:10:\"startreads\";s:0:\"\";s:5:\"anoip\";i:0;s:12:\"massbotlimit\";i:25;s:7:\"clients\";s:42:\"Firefox, Edge, MSIE, Chrome, Safari, Opera\";s:4:\"ajax\";i:0;s:5:\"debug\";i:0;s:8:\"referers\";i:1;s:12:\"referers_cut\";i:0;s:8:\"fieldlen\";i:150;s:8:\"localref\";i:1;s:18:\"dashboard_referers\";i:20;s:18:\"referers_last_days\";i:7;s:12:\"no_front_css\";i:0;s:9:\"whocansee\";s:13:\"publish_posts\";s:11:\"backup_part\";i:10000;}', 'yes'),
(167, 'tadv_settings', 'a:6:{s:7:\"options\";s:15:\"menubar,advlist\";s:9:\"toolbar_1\";s:106:\"formatselect,bold,italic,blockquote,bullist,numlist,alignleft,aligncenter,alignright,link,unlink,undo,redo\";s:9:\"toolbar_2\";s:103:\"fontselect,fontsizeselect,outdent,indent,pastetext,removeformat,charmap,wp_more,forecolor,table,wp_help\";s:9:\"toolbar_3\";s:0:\"\";s:9:\"toolbar_4\";s:0:\"\";s:7:\"plugins\";s:104:\"anchor,code,insertdatetime,nonbreaking,print,searchreplace,table,visualblocks,visualchars,advlist,wptadv\";}', 'yes'),
(168, 'tadv_admin_settings', 'a:1:{s:7:\"options\";a:0:{}}', 'yes'),
(169, 'tadv_version', '4000', 'yes'),
(170, 'user_role_editor', 'a:1:{s:11:\"ure_version\";s:6:\"4.40.1\";}', 'yes'),
(171, 'rt_backup_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'no'),
(172, 'ure_tasks_queue', 'a:0:{}', 'yes'),
(173, 'woocommerce_default_country', 'VN', 'yes'),
(174, 'woocommerce_allowed_countries', 'all', 'yes'),
(175, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(176, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(177, 'woocommerce_ship_to_countries', 'disabled', 'yes'),
(178, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(179, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(180, 'woocommerce_calc_taxes', 'no', 'yes'),
(181, 'woocommerce_demo_store', 'no', 'yes'),
(182, 'woocommerce_demo_store_notice', 'Đây là cửa hàng demo nhằm mục đích thử nghiệm &mdash; các đơn hàng sẽ không có hiệu lực.', 'no'),
(183, 'woocommerce_currency', 'VND', 'yes'),
(184, 'woocommerce_currency_pos', 'right', 'yes'),
(185, 'woocommerce_price_thousand_sep', '.', 'yes'),
(186, 'woocommerce_price_decimal_sep', '.', 'yes'),
(187, 'woocommerce_price_num_decimals', '0', 'yes'),
(188, 'woocommerce_weight_unit', 'kg', 'yes'),
(189, 'woocommerce_dimension_unit', 'cm', 'yes'),
(190, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(191, 'woocommerce_review_rating_required', 'yes', 'no'),
(192, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(193, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(194, 'woocommerce_shop_page_id', '', 'yes'),
(195, 'woocommerce_shop_page_display', '', 'yes'),
(196, 'woocommerce_category_archive_display', '', 'yes'),
(197, 'woocommerce_default_catalog_orderby', 'menu_order', 'yes'),
(198, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(199, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(200, 'shop_catalog_image_size', 'a:3:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";i:0;}', 'yes'),
(201, 'shop_single_image_size', 'a:3:{s:5:\"width\";s:3:\"600\";s:6:\"height\";s:3:\"600\";s:4:\"crop\";i:0;}', 'yes'),
(202, 'shop_thumbnail_image_size', 'a:3:{s:5:\"width\";s:3:\"180\";s:6:\"height\";s:3:\"180\";s:4:\"crop\";i:0;}', 'yes'),
(203, 'woocommerce_manage_stock', 'yes', 'yes'),
(204, 'woocommerce_hold_stock_minutes', '60', 'no'),
(205, 'woocommerce_notify_low_stock', 'yes', 'no'),
(206, 'woocommerce_notify_no_stock', 'yes', 'no'),
(207, 'woocommerce_stock_email_recipient', 'phamtuan170291@gmail.com', 'no'),
(208, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(209, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(210, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(211, 'woocommerce_stock_format', '', 'yes'),
(212, 'woocommerce_file_download_method', 'force', 'no'),
(213, 'woocommerce_downloads_require_login', 'no', 'no'),
(214, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(215, 'woocommerce_prices_include_tax', 'no', 'yes'),
(216, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(217, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(218, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(219, 'woocommerce_tax_classes', 'Reduced rate\nZero rate', 'yes'),
(220, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(221, 'woocommerce_tax_display_cart', 'excl', 'no'),
(222, 'woocommerce_price_display_suffix', '', 'yes'),
(223, 'woocommerce_tax_total_display', 'itemized', 'no'),
(224, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(225, 'woocommerce_shipping_cost_requires_address', 'no', 'no'),
(226, 'woocommerce_ship_to_destination', 'billing', 'no'),
(227, 'woocommerce_shipping_debug_mode', 'no', 'no'),
(228, 'woocommerce_enable_coupons', 'yes', 'yes'),
(229, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(230, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(231, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(232, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(233, 'woocommerce_cart_page_id', '8', 'yes'),
(234, 'woocommerce_checkout_page_id', '9', 'yes'),
(235, 'woocommerce_terms_page_id', '', 'no'),
(236, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(237, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(238, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(239, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(240, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(241, 'woocommerce_myaccount_page_id', '10', 'yes'),
(242, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(243, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(244, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(245, 'woocommerce_registration_generate_username', 'yes', 'no'),
(246, 'woocommerce_registration_generate_password', 'no', 'no'),
(247, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(248, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(249, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(250, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(251, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(252, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(253, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(254, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(255, 'woocommerce_email_from_name', 'RT &#8211; Core', 'no'),
(256, 'woocommerce_email_from_address', 'phamtuan170291@gmail.com', 'no'),
(257, 'woocommerce_email_header_image', '', 'no'),
(258, 'woocommerce_email_footer_text', 'RT &#8211; Core - Powered by WooCommerce', 'no'),
(259, 'woocommerce_email_base_color', '#96588a', 'no'),
(260, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(261, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(262, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(263, 'woocommerce_api_enabled', 'yes', 'yes'),
(269, 'wp_smtp_options', 'a:9:{s:4:\"from\";s:16:\"cskh@raothue.net\";s:8:\"fromname\";s:8:\"RT Group\";s:4:\"host\";s:16:\"mail.smtp2go.com\";s:10:\"smtpsecure\";s:3:\"ssl\";s:4:\"port\";s:3:\"465\";s:8:\"smtpauth\";s:3:\"yes\";s:8:\"username\";s:24:\"hoangngoctan@raothue.com\";s:8:\"password\";s:12:\"JY77BPMwrnEV\";s:10:\"deactivate\";s:0:\"\";}', 'yes'),
(270, 'pagenavi_options', 'a:15:{s:10:\"pages_text\";s:0:\"\";s:12:\"current_text\";s:13:\"%PAGE_NUMBER%\";s:9:\"page_text\";s:13:\"%PAGE_NUMBER%\";s:10:\"first_text\";s:15:\"« Trang đầu\";s:9:\"last_text\";s:15:\"Trang cuối »\";s:9:\"prev_text\";s:2:\"«\";s:9:\"next_text\";s:2:\"»\";s:12:\"dotleft_text\";s:3:\"...\";s:13:\"dotright_text\";s:3:\"...\";s:9:\"num_pages\";i:5;s:23:\"num_larger_page_numbers\";i:3;s:28:\"larger_page_numbers_multiple\";i:10;s:11:\"always_show\";i:0;s:16:\"use_pagenavi_css\";i:1;s:5:\"style\";i:1;}', 'yes'),
(271, 'wpseo', 'a:18:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:5:\"7.0.3\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";b:0;s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1498547015;}', 'yes'),
(273, 'wpseo_titles', 'a:87:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:12:\"%%sitename%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:0;s:20:\"breadcrumbs-404crumb\";s:0:\"\";s:23:\"breadcrumbs-blog-remove\";b:0;s:20:\"breadcrumbs-boldlast\";b:1;s:25:\"breadcrumbs-archiveprefix\";s:0:\"\";s:18:\"breadcrumbs-enable\";b:1;s:16:\"breadcrumbs-home\";s:11:\"Trang chủ\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:0:\"\";s:15:\"breadcrumbs-sep\";s:2:\"»\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:17:\"stripcategorybase\";b:1;s:10:\"title-post\";s:9:\"%%title%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:10:\"title-page\";s:9:\"%%title%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:16:\"title-attachment\";s:9:\"%%title%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:18:\"title-tax-category\";s:14:\"%%term_title%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:14:\"%%term_title%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:14:\"%%term_title%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;s:23:\"post_types-post-maintax\";i:0;s:22:\"noindex-subpages-wpseo\";b:0;s:13:\"title-product\";s:9:\"%%title%%\";s:16:\"metadesc-product\";s:0:\"\";s:15:\"noindex-product\";b:0;s:16:\"showdate-product\";b:0;s:23:\"title-ptarchive-product\";s:9:\"%%title%%\";s:26:\"metadesc-ptarchive-product\";s:0:\"\";s:25:\"bctitle-ptarchive-product\";s:0:\"\";s:25:\"noindex-ptarchive-product\";b:0;s:21:\"title-tax-product_cat\";s:14:\"%%term_title%%\";s:24:\"metadesc-tax-product_cat\";s:0:\"\";s:23:\"noindex-tax-product_cat\";b:0;s:21:\"title-tax-product_tag\";s:14:\"%%term_title%%\";s:24:\"metadesc-tax-product_tag\";s:0:\"\";s:23:\"noindex-tax-product_tag\";b:0;s:32:\"title-tax-product_shipping_class\";s:14:\"%%term_title%%\";s:35:\"metadesc-tax-product_shipping_class\";s:0:\"\";s:34:\"noindex-tax-product_shipping_class\";b:0;s:29:\"post_types-attachment-maintax\";i:0;s:26:\"post_types-product-maintax\";i:0;s:29:\"taxonomy-product_cat-ptparent\";i:0;s:29:\"taxonomy-product_tag-ptparent\";i:0;s:40:\"taxonomy-product_shipping_class-ptparent\";i:0;}', 'yes'),
(274, 'wpseo_social', 'a:20:{s:9:\"fb_admins\";a:0:{}s:12:\"fbconnectkey\";s:32:\"2cdd605acc9428232c289a10caf5055e\";s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:7:\"summary\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}', 'yes'),
(279, 'woocommerce_admin_notices', 'a:1:{i:0;s:14:\"template_files\";}', 'yes'),
(281, '_transient_woocommerce_webhook_ids', 'a:0:{}', 'yes'),
(282, 'widget_countperday_widget', 'a:2:{i:2;a:30:{s:5:\"title\";s:22:\"Thống kê truy cập\";s:5:\"order\";s:199:\"show|getreadsall|getreadstoday|getreadsyesterday|getreadslastweek|getreadsthismonth|getuserall|getusertoday|getuseryesterday|getuserlastweek|getuserthismonth|getuserperday|getuseronline|getfirstcount\";s:4:\"show\";i:0;s:11:\"getreadsall\";s:1:\"1\";s:13:\"getreadstoday\";s:1:\"1\";s:17:\"getreadsyesterday\";s:1:\"1\";s:16:\"getreadslastweek\";i:0;s:17:\"getreadsthismonth\";i:0;s:10:\"getuserall\";i:0;s:12:\"getusertoday\";i:0;s:16:\"getuseryesterday\";i:0;s:15:\"getuserlastweek\";i:0;s:16:\"getuserthismonth\";i:0;s:13:\"getuserperday\";i:0;s:13:\"getuseronline\";s:1:\"1\";s:13:\"getfirstcount\";i:0;s:9:\"show_name\";s:9:\"This post\";s:16:\"getreadsall_name\";s:10:\"Tất cả\";s:18:\"getreadstoday_name\";s:8:\"Hôm qua\";s:22:\"getreadsyesterday_name\";s:8:\"Hôm nay\";s:21:\"getreadslastweek_name\";s:15:\"Reads last week\";s:22:\"getreadsthismonth_name\";s:15:\"Reads per month\";s:15:\"getuserall_name\";s:14:\"Total visitors\";s:17:\"getusertoday_name\";s:14:\"Visitors today\";s:21:\"getuseryesterday_name\";s:18:\"Visitors yesterday\";s:20:\"getuserlastweek_name\";s:18:\"Visitors last week\";s:21:\"getuserthismonth_name\";s:18:\"Visitors per month\";s:18:\"getuserperday_name\";s:16:\"Visitors per day\";s:18:\"getuseronline_name\";s:20:\"Đang trực tuyến\";s:18:\"getfirstcount_name\";s:17:\"Counter starts on\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(283, 'widget_countperday_popular_posts_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(284, 'widget_woocommerce_product_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(285, 'widget_woocommerce_rating_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(286, 'widget_metaslider_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes');
INSERT INTO `rt_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(287, 'widget_rt_post_by_category_widget', 'a:2:{i:2;a:11:{s:5:\"title\";s:30:\"Bài viết theo chuyên mục\";s:5:\"style\";s:1:\"1\";s:6:\"number\";s:1:\"6\";s:3:\"cat\";s:1:\"2\";s:14:\"thumb_position\";s:3:\"top\";s:7:\"heading\";s:2:\"h4\";s:12:\"on_off_thumb\";i:1;s:10:\"first_post\";i:1;s:10:\"other_post\";i:0;s:7:\"excerpt\";i:0;s:4:\"meta\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(288, 'widget_rt-posts-slider-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(289, 'widget_rt_products_by_category_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(293, 'duplicate_post_copytitle', '1', 'yes'),
(294, 'duplicate_post_copydate', '0', 'yes'),
(295, 'duplicate_post_copystatus', '0', 'yes'),
(296, 'duplicate_post_copyslug', '1', 'yes'),
(297, 'duplicate_post_copyexcerpt', '1', 'yes'),
(298, 'duplicate_post_copycontent', '1', 'yes'),
(299, 'duplicate_post_copythumbnail', '1', 'yes'),
(300, 'duplicate_post_copytemplate', '1', 'yes'),
(301, 'duplicate_post_copyformat', '1', 'yes'),
(302, 'duplicate_post_copyauthor', '0', 'yes'),
(303, 'duplicate_post_copypassword', '0', 'yes'),
(304, 'duplicate_post_copyattachments', '0', 'yes'),
(305, 'duplicate_post_copychildren', '0', 'yes'),
(306, 'duplicate_post_copycomments', '0', 'yes'),
(307, 'duplicate_post_copymenuorder', '1', 'yes'),
(308, 'duplicate_post_taxonomies_blacklist', 'a:0:{}', 'yes'),
(309, 'duplicate_post_blacklist', '', 'yes'),
(310, 'duplicate_post_types_enabled', 'a:2:{i:0;s:4:\"post\";i:1;s:4:\"page\";}', 'yes'),
(311, 'duplicate_post_show_row', '1', 'yes'),
(312, 'duplicate_post_show_adminbar', '1', 'yes'),
(313, 'duplicate_post_show_submitbox', '1', 'yes'),
(314, 'duplicate_post_show_bulkactions', '1', 'yes'),
(317, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(320, 'wpseo_sitemap_1_cache_validator', '2KKB1', 'no'),
(321, 'wpseo_sitemap_page_cache_validator', 'YCLe', 'no'),
(327, 'woocommerce_allow_tracking', 'no', 'yes'),
(328, 'wpseo_sitemap_product_cache_validator', '3Bfea', 'no'),
(334, 'wpseo_sitemap_cache_validator_global', 'zCWA', 'no'),
(337, 'rewrite_rules', '', 'yes'),
(343, 'metaslider_systemcheck', 'a:2:{s:16:\"wordPressVersion\";b:0;s:12:\"imageLibrary\";b:0;}', 'no'),
(344, 'ml-slider_children', 'a:0:{}', 'yes'),
(349, 'ure_role_additional_options_values', 'a:1:{s:12:\"shop_manager\";a:0:{}}', 'yes'),
(353, 'wpseo_sitemap_author_cache_validator', '2KKB3', 'no'),
(356, 'wpseo_sitemap_post_cache_validator', 'feqp', 'no'),
(374, 'wpseo_sitemap_category_cache_validator', 'NpNx', 'no'),
(378, 'wpseo_sitemap_product_cat_cache_validator', '3BfdI', 'no'),
(385, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(386, '_transient_product_query-transient-version', '1512986314', 'yes'),
(387, '_transient_product-transient-version', '1512986315', 'yes'),
(390, 'count_per_day_online', 'a:1:{s:13:\"118.70.80.185\";a:2:{i:0;i:1528938879;i:1;i:0;}}', 'yes'),
(402, 'wpseo_sitemap_42_cache_validator', 'dw7x', 'no'),
(407, 'wpseo_sitemap_46_cache_validator', '3471g', 'no'),
(411, 'wpseo_sitemap_48_cache_validator', '346Zj', 'no'),
(413, 'wpseo_sitemap_50_cache_validator', '346Xy', 'no'),
(430, 'count_per_day_search', 'a:2:{s:10:\"2017-06-15\";a:2:{i:0;s:2:\"ro\";i:1;s:4:\"nano\";}s:10:\"2017-12-12\";a:1:{i:0;s:14:\"tranh tường\";}}', 'yes'),
(472, 'woocommerce_permalinks', 'a:4:{s:13:\"category_base\";s:8:\"danh-muc\";s:8:\"tag_base\";s:0:\"\";s:14:\"attribute_base\";s:0:\"\";s:12:\"product_base\";s:0:\"\";}', 'yes'),
(480, 'wpseo_sitemap_18_cache_validator', '2tu2', 'no'),
(507, 'widget_rt_widget_product', 'a:2:{i:2;a:9:{s:5:\"title\";s:1:\"S\";s:3:\"tax\";s:2:\"26\";s:2:\"on\";s:1:\"1\";s:5:\"slide\";s:8:\"vertical\";s:7:\"numberp\";s:1:\"3\";s:6:\"numbsl\";s:1:\"1\";s:8:\"numbshow\";s:1:\"2\";s:10:\"speedslide\";s:4:\"1000\";s:9:\"style_pro\";s:1:\"2\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(508, 'widget_rt_widget_archive', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(509, 'widget_rt_widget_post', 'a:3:{i:2;a:14:{s:5:\"title\";s:9:\"Tin tức\";s:2:\"on\";N;s:5:\"slide\";s:8:\"vertical\";s:7:\"numberp\";s:1:\"5\";s:6:\"numbsl\";s:1:\"1\";s:8:\"numbshow\";s:1:\"3\";s:10:\"speedslide\";s:4:\"1000\";s:3:\"tax\";s:1:\"2\";s:9:\"thumbnail\";s:1:\"1\";s:7:\"stthumb\";s:10:\"align-left\";s:8:\"fstthumb\";N;s:7:\"excerpt\";N;s:8:\"nbexerpt\";s:3:\"100\";s:10:\"style_post\";s:1:\"2\";}i:3;a:14:{s:5:\"title\";s:23:\"Tin tức & sự kiện\";s:2:\"on\";N;s:5:\"slide\";s:8:\"vertical\";s:7:\"numberp\";s:1:\"4\";s:6:\"numbsl\";s:0:\"\";s:8:\"numbshow\";s:0:\"\";s:10:\"speedslide\";s:4:\"1000\";s:3:\"tax\";s:1:\"2\";s:9:\"thumbnail\";s:1:\"1\";s:7:\"stthumb\";s:10:\"align-left\";s:8:\"fstthumb\";N;s:7:\"excerpt\";N;s:8:\"nbexerpt\";s:0:\"\";s:10:\"style_post\";s:1:\"1\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(510, 'widget_rt_widget_tab', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(511, 'woocommerce_enable_reviews', 'yes', 'yes'),
(584, 'wpseo_sitemap_63_cache_validator', '4yd4s', 'no'),
(589, 'wpseo_sitemap_65_cache_validator', '4yd6e', 'no'),
(636, '_transient_timeout_plugin_slugs', '1521166279', 'no'),
(637, '_transient_plugin_slugs', 'a:9:{i:0;s:27:\"colorpicker/colorpicker.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:25:\"count-per-day/counter.php\";i:3;s:23:\"ml-slider/ml-slider.php\";i:4;s:37:\"tinymce-advanced/tinymce-advanced.php\";i:5;s:37:\"user-role-editor/user-role-editor.php\";i:6;s:27:\"woocommerce/woocommerce.php\";i:7;s:19:\"wp-smtp/wp-smtp.php\";i:8;s:24:\"wordpress-seo/wp-seo.php\";}', 'no'),
(644, 'widget_black-studio-tinymce', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(663, 'widget_woocommerce_price_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(777, '_transient_yoast_i18n_wordpress-seo_promo_hide', '1', 'yes'),
(804, 'wpseo_sitemap_13_cache_validator', 'R2ri', 'no'),
(805, 'wpseo_sitemap_54_cache_validator', 'R2sW', 'no'),
(853, 'loginizer_ins_time', '1500544359', 'yes'),
(854, 'loginizer_promo_time', '1500544359', 'yes'),
(991, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(997, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:25:\"mailtrunggian01@gmail.com\";s:7:\"version\";s:5:\"4.8.1\";s:9:\"timestamp\";i:1501725262;}', 'no'),
(1045, 'wpseo_sitemap_67_cache_validator', '4yd5F', 'no'),
(1187, 'widget_rt-widget-text', 'a:3:{i:2;a:3:{s:5:\"title\";s:21:\"Thông tin liên hệ\";s:4:\"text\";s:397:\"CÔNG TY CỔ PHẦN HỢP TÁC & PHÁT TRIỂN ÁNH DƯƠNG TÂY BẮC\r\n<i class=\"fa fa-home\" aria-hidden=\"true\"></i>Địa chỉ: Số 7 đường Mỹ Đình, Phường Mỹ Đình 2, Quận Nam Từ Liêm, Tp. Hà Nội.\r\n<i class=\"fa fa-phone\" aria-hidden=\"true\"></i>Điện thoại: 0982 906 369 -0966 996 343\r\n<i class=\"fa fa-envelope\" aria-hidden=\"true\"></i>Email: anhduongtaybac@gmail.com\";s:6:\"filter\";b:1;}i:3;a:3:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:58:\"© Copyright 2018. Thiết kế và phát triển bởi RT\";s:6:\"filter\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(1249, 'wpseo_sitemap_40_cache_validator', '3473K', 'no'),
(1260, 'wpseo_sitemap_28_cache_validator', '35ZGa', 'no'),
(1261, 'wpseo_sitemap_35_cache_validator', '35ZE7', 'no'),
(1262, 'wpseo_sitemap_36_cache_validator', '35ZCS', 'no'),
(1263, 'wpseo_sitemap_37_cache_validator', 'dHGD', 'no'),
(1264, 'wpseo_sitemap_38_cache_validator', 'dHG2', 'no'),
(1265, 'wpseo_sitemap_39_cache_validator', '35ZzS', 'no'),
(1266, 'wpseo_sitemap_23_cache_validator', 'dxIi', 'no'),
(1267, 'wpseo_sitemap_24_cache_validator', '34mVB', 'no'),
(1268, 'wpseo_sitemap_25_cache_validator', '34mZA', 'no'),
(1269, 'wpseo_sitemap_26_cache_validator', '34n4U', 'no'),
(1270, 'wpseo_sitemap_27_cache_validator', '34n6S', 'no'),
(1282, 'widget_video-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1301, 'wpseo_sitemap_83_cache_validator', '2U8jR', 'no'),
(1305, 'wpseo_sitemap_85_cache_validator', '2UesA', 'no'),
(1309, 'wpseo_sitemap_87_cache_validator', '2Uod4', 'no'),
(1313, 'wpseo_sitemap_89_cache_validator', '2UtUk', 'no'),
(1317, 'wpseo_sitemap_91_cache_validator', '2UzTK', 'no'),
(1321, 'wpseo_sitemap_93_cache_validator', '2UFxK', 'no'),
(1325, 'wpseo_sitemap_95_cache_validator', 'cGht', 'no'),
(1329, 'wpseo_sitemap_97_cache_validator', '5c7VS', 'no'),
(1344, 'wpseo_taxonomy_meta', 'a:2:{s:11:\"product_cat\";a:2:{i:31;a:2:{s:13:\"wpseo_linkdex\";s:2:\"-9\";s:19:\"wpseo_content_score\";s:2:\"30\";}i:30;a:2:{s:13:\"wpseo_linkdex\";s:2:\"-9\";s:19:\"wpseo_content_score\";s:2:\"30\";}}s:8:\"category\";a:1:{i:33;a:2:{s:13:\"wpseo_linkdex\";s:2:\"-2\";s:19:\"wpseo_content_score\";s:2:\"30\";}}}', 'yes'),
(1374, 'product_cat_children', 'a:1:{i:29;a:2:{i:0;i:30;i:1;i:31;}}', 'yes'),
(1395, 'wpseo_sitemap_17_cache_validator', '3oAy6', 'no'),
(1435, 'wpseo_sitemap_106_cache_validator', '3HucN', 'no'),
(1627, '_transient_wc_attribute_taxonomies', 'a:4:{i:0;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"2\";s:14:\"attribute_name\";s:8:\"bao-hanh\";s:15:\"attribute_label\";s:11:\"Bảo hành\";s:14:\"attribute_type\";s:4:\"text\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}i:1;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"3\";s:14:\"attribute_name\";s:7:\"mau-sac\";s:15:\"attribute_label\";s:10:\"Màu sắc\";s:14:\"attribute_type\";s:4:\"text\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}i:2;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"4\";s:14:\"attribute_name\";s:12:\"noi-san-xuat\";s:15:\"attribute_label\";s:17:\"Nơi sản xuất\";s:14:\"attribute_type\";s:4:\"text\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}i:3;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"5\";s:14:\"attribute_name\";s:11:\"thuong-hieu\";s:15:\"attribute_label\";s:15:\"Thương hiệu\";s:14:\"attribute_type\";s:4:\"text\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}}', 'yes'),
(1829, '_transient_orders-transient-version', '1512403063', 'yes'),
(1832, '_transient_wc_count_comments', 'O:8:\"stdClass\":7:{s:8:\"approved\";s:1:\"1\";s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(1878, 'duplicate_post_version', '3.2.1', 'yes'),
(1879, 'duplicate_post_show_notice', '1', 'no'),
(1886, 'woocommerce_store_address', '', 'yes'),
(1887, 'woocommerce_store_address_2', '', 'yes'),
(1888, 'woocommerce_store_city', '', 'yes'),
(1889, 'woocommerce_store_postcode', '', 'yes'),
(1893, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:4:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:62:\"https://downloads.wordpress.org/release/vi/wordpress-4.9.5.zip\";s:6:\"locale\";s:2:\"vi\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:62:\"https://downloads.wordpress.org/release/vi/wordpress-4.9.5.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.5\";s:7:\"version\";s:5:\"4.9.5\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.5-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.5-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.5\";s:7:\"version\";s:5:\"4.9.5\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.5.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.5-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.5-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.5\";s:7:\"version\";s:5:\"4.9.5\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:3;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.8.6.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.8.6.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.8.6-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.8.6-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.8.6-partial-1.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.8.6-rollback-1.zip\";}s:7:\"current\";s:5:\"4.8.6\";s:7:\"version\";s:5:\"4.8.6\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.8.1\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1523863066;s:15:\"version_checked\";s:5:\"4.8.1\";s:12:\"translations\";a:0:{}}', 'no'),
(1895, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1523863068;s:7:\"checked\";a:1:{s:2:\"RT\";s:5:\"1.0.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(1896, 'wpseo_license_server_version', '2', 'yes'),
(2007, 'ms_hide_all_ads_until', '1514217632', 'yes'),
(2035, 'ms_ads_first_seen_on', '1516613190', 'yes'),
(2047, '_transient_timeout_wc_low_stock_count', '1519205219', 'no'),
(2048, '_transient_wc_low_stock_count', '0', 'no'),
(2049, '_transient_timeout_wc_outofstock_count', '1519205219', 'no'),
(2050, '_transient_wc_outofstock_count', '0', 'no'),
(2072, 'wpseo_sitemap_20_cache_validator', '3HuUh', 'no'),
(2073, 'wpseo_sitemap_22_cache_validator', '3HuUn', 'no'),
(2117, 'category_children', 'a:0:{}', 'yes'),
(2155, 'wpseo_sitemap_123_cache_validator', 'Y7AG', 'no'),
(2156, 'wpseo_sitemap_125_cache_validator', 'Y7AM', 'no'),
(2157, 'wpseo_sitemap_126_cache_validator', 'Y7AS', 'no'),
(2346, '_transient_timeout_wc_upgrade_notice_3.2.6', '1517370718', 'no'),
(2347, '_transient_wc_upgrade_notice_3.2.6', '', 'no'),
(2358, 'woocommerce_version', '3.2.6', 'yes'),
(2359, 'woocommerce_db_version', '3.2.6', 'yes'),
(2364, '_transient_timeout_wpseo_link_table_inaccessible', '1548821562', 'no'),
(2365, '_transient_wpseo_link_table_inaccessible', '0', 'no'),
(2366, '_transient_timeout_wpseo_meta_table_inaccessible', '1548821562', 'no'),
(2367, '_transient_wpseo_meta_table_inaccessible', '0', 'no'),
(2401, '_site_transient_timeout_browser_b876c8fd7fc402e60530b64622320f7a', '1517997758', 'no'),
(2402, '_site_transient_browser_b876c8fd7fc402e60530b64622320f7a', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"63.0.3239.132\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(2731, '_transient_doing_cron', '1528938877.8258008956909179687500', 'yes'),
(2738, '_site_transient_timeout_browser_991ed2b567018dce880762b1b51b2e49', '1519981075', 'no'),
(2739, '_site_transient_browser_991ed2b567018dce880762b1b51b2e49', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"62.4.3202.126\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(2782, '_site_transient_timeout_browser_49da57eac7f840522fef2b86e883cffa', '1520584006', 'no'),
(2783, '_site_transient_browser_49da57eac7f840522fef2b86e883cffa', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"64.0.3282.186\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(2789, '_transient_is_multi_author', '0', 'yes'),
(2796, '_site_transient_timeout_browser_1bfbf9a57c5f615b2bbd52e6bed82654', '1521684577', 'no'),
(2797, '_site_transient_browser_1bfbf9a57c5f615b2bbd52e6bed82654', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"62.4.3202.154\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(2800, '_transient_timeout_wc_upgrade_notice_3.3.3', '1521166200', 'no'),
(2801, '_transient_wc_upgrade_notice_3.3.3', '', 'no'),
(2805, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1521090658', 'no'),
(2806, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4440;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:2648;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2543;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2408;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1857;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1639;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1631;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1447;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1383;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1380;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1378;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1302;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1280;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1186;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1088;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1056;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1015;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:993;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:870;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:863;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:823;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:797;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:791;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:699;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:689;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:683;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:674;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:672;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:654;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:651;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:639;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:635;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:631;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:610;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:609;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:599;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:599;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:587;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:584;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:584;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:558;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:545;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:535;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:530;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:519;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:512;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:510;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:504;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:489;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:486;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:485;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:484;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:478;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:471;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:465;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:462;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:453;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:451;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:436;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:426;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:423;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:418;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:416;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:416;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:411;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:410;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:402;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:397;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:390;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:383;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:378;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:361;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:354;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:353;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:350;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:343;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:341;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:339;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:337;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:335;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:334;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:334;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:333;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:329;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:328;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:326;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:317;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:311;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:305;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:302;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:302;}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";i:300;}s:7:\"adsense\";a:3:{s:4:\"name\";s:7:\"adsense\";s:4:\"slug\";s:7:\"adsense\";s:5:\"count\";i:295;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:292;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:292;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:290;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:290;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:287;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:286;}s:8:\"lightbox\";a:3:{s:4:\"name\";s:8:\"lightbox\";s:4:\"slug\";s:8:\"lightbox\";s:5:\"count\";i:285;}}', 'no'),
(2808, 'wpseo_sitemap_attachment_cache_validator', '4tBQ', 'no'),
(2809, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1523863066;s:8:\"response\";a:4:{s:23:\"ml-slider/ml-slider.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:23:\"w.org/plugins/ml-slider\";s:4:\"slug\";s:9:\"ml-slider\";s:6:\"plugin\";s:23:\"ml-slider/ml-slider.php\";s:11:\"new_version\";s:5:\"3.7.2\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/ml-slider/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/ml-slider.3.7.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:62:\"https://ps.w.org/ml-slider/assets/icon-256x256.png?rev=1837669\";s:2:\"1x\";s:54:\"https://ps.w.org/ml-slider/assets/icon.svg?rev=1837669\";s:3:\"svg\";s:54:\"https://ps.w.org/ml-slider/assets/icon.svg?rev=1837669\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/ml-slider/assets/banner-1544x500.png?rev=1837669\";s:2:\"1x\";s:64:\"https://ps.w.org/ml-slider/assets/banner-772x250.png?rev=1837669\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.5\";s:12:\"requires_php\";N;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:37:\"user-role-editor/user-role-editor.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:30:\"w.org/plugins/user-role-editor\";s:4:\"slug\";s:16:\"user-role-editor\";s:6:\"plugin\";s:37:\"user-role-editor/user-role-editor.php\";s:11:\"new_version\";s:6:\"4.40.3\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/user-role-editor/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/user-role-editor.4.40.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-256x256.jpg?rev=1020390\";s:2:\"1x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-128x128.jpg?rev=1020390\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/user-role-editor/assets/banner-772x250.png?rev=1263116\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.5\";s:12:\"requires_php\";N;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.3.5\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.3.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=1440831\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=1629184\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.5\";s:12:\"requires_php\";N;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:3:\"7.2\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wordpress-seo.7.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1834347\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1834347\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}s:6:\"tested\";s:5:\"4.9.5\";s:12:\"requires_php\";N;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.0.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.0.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:25:\"count-per-day/counter.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/count-per-day\";s:4:\"slug\";s:13:\"count-per-day\";s:6:\"plugin\";s:25:\"count-per-day/counter.php\";s:11:\"new_version\";s:5:\"3.5.7\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/count-per-day/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/count-per-day.3.5.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/count-per-day/assets/icon-256x256.png?rev=987085\";s:2:\"1x\";s:65:\"https://ps.w.org/count-per-day/assets/icon-128x128.png?rev=987085\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:67:\"https://ps.w.org/count-per-day/assets/banner-772x250.png?rev=517175\";}s:11:\"banners_rtl\";a:0:{}}s:37:\"tinymce-advanced/tinymce-advanced.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:30:\"w.org/plugins/tinymce-advanced\";s:4:\"slug\";s:16:\"tinymce-advanced\";s:6:\"plugin\";s:37:\"tinymce-advanced/tinymce-advanced.php\";s:11:\"new_version\";s:5:\"4.6.7\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/tinymce-advanced/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/tinymce-advanced.4.6.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/tinymce-advanced/assets/icon-256x256.png?rev=971511\";s:2:\"1x\";s:68:\"https://ps.w.org/tinymce-advanced/assets/icon-128x128.png?rev=971511\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:70:\"https://ps.w.org/tinymce-advanced/assets/banner-772x250.png?rev=894078\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.5\";s:12:\"requires_php\";N;s:13:\"compatibility\";a:0:{}}s:19:\"wp-smtp/wp-smtp.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/wp-smtp\";s:4:\"slug\";s:7:\"wp-smtp\";s:6:\"plugin\";s:19:\"wp-smtp/wp-smtp.php\";s:11:\"new_version\";s:5:\"1.1.9\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/wp-smtp/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/wp-smtp.1.1.9.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:51:\"https://s.w.org/plugins/geopattern-icon/wp-smtp.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(2810, 'colorws_color_main_one', '174873', 'yes'),
(2811, 'colorws_active_color_primary', '1', 'yes'),
(2812, 'colorws_color_primary', '2b2b2b', 'yes'),
(2813, 'colorws_active_color_text', '1', 'yes'),
(2814, 'colorws_color_text', 'ffffff', 'yes'),
(2815, 'colorws_div_bg', '.main-navigation,.widget-title,.heading .titles,.widget-title', 'yes'),
(2816, 'colorws_div_bg_primary', '.site-footer', 'yes'),
(2817, 'colorws_div_cl', '.heading a,.widget-title,.site-content,.main-navigation li a', 'yes'),
(2818, 'colorws_div_border', '', 'yes'),
(2837, '_site_transient_timeout_available_translations', '1522143818', 'no');
INSERT INTO `rt_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(2838, '_site_transient_available_translations', 'a:109:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-04 12:02:13\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-29 08:49:40\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-30 18:40:55\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.1/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-09 09:24:45\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-04 16:58:43\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.7.9\";s:7:\"updated\";s:19:\"2018-03-21 07:56:32\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.9/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-08 21:01:45\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 08:46:26\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-19 16:27:32\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-27 19:10:04\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-09 11:51:58\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-09 11:53:31\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.8.1/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-14 20:03:25\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-04 15:29:24\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.8.1/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 10:51:51\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-02 03:57:05\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-25 17:31:04\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-25 19:47:01\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-25 10:03:08\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:53:43\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-26 10:38:53\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-30 16:09:17\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-13 17:00:30\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-01 04:48:11\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.7.9\";s:7:\"updated\";s:19:\"2017-11-15 14:57:21\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.9/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-28 20:09:49\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-31 15:12:02\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-18 14:39:36\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 16:37:11\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-19 12:08:05\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:3:\"4.8\";s:7:\"updated\";s:19:\"2017-06-09 15:50:45\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 11:00:29\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-13 19:34:52\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 09:14:18\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 12:37:07\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-26 12:45:35\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-31 06:54:10\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-12 21:37:24\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 10:29:26\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-17 21:32:24\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:39\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 12:45:08\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-04-13 13:55:54\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-10 18:53:47\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-03 23:23:50\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:3:\"4.8\";s:7:\"updated\";s:19:\"2017-06-12 09:20:11\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-22 15:33:00\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.1/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 10:48:16\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:25\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 11:02:15\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-03-17 20:40:40\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.7/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:3:\"4.8\";s:7:\"updated\";s:19:\"2017-07-05 19:40:47\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/4.8/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.7.9\";s:7:\"updated\";s:19:\"2017-11-15 14:11:50\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.9/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-02 21:02:39\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-31 08:47:10\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-17 11:00:54\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-30 07:58:32\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.8.1/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-27 16:44:39\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-01 07:32:10\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.1/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-06 08:34:38\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-05 18:31:50\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/4.8.1/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-10 19:12:13\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-26 21:35:20\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-19 13:05:58\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-19 20:27:57\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-09 13:26:18\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-12 12:51:50\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.7.9\";s:7:\"updated\";s:19:\"2017-11-06 12:08:03\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.9/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 12:07:44\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-19 08:58:31\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.7.9\";s:7:\"updated\";s:19:\"2018-03-02 17:10:03\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.9/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-31 11:38:12\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-05 09:23:39\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-19 19:56:39\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-07-28 14:27:29\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-11 16:54:43\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-13 04:19:14\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.1/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-09-12 11:35:05\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-04 07:53:05\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.8.1\";s:7:\"updated\";s:19:\"2017-08-14 16:47:28\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.1/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}', 'no'),
(2843, '_transient_timeout_wc_related_99', '1523919477', 'no'),
(2844, '_transient_wc_related_99', 'a:5:{i:0;s:3:\"100\";i:1;s:3:\"101\";i:2;s:3:\"102\";i:3;s:3:\"103\";i:4;s:3:\"104\";}', 'no'),
(2845, '_transient_timeout_wc_related_100', '1523924024', 'no'),
(2846, '_transient_wc_related_100', 'a:5:{i:0;s:2:\"99\";i:1;s:3:\"101\";i:2;s:3:\"102\";i:3;s:3:\"103\";i:4;s:3:\"104\";}', 'no'),
(2847, '_transient_timeout_wc_related_101', '1523928571', 'no'),
(2848, '_transient_wc_related_101', 'a:5:{i:0;s:2:\"99\";i:1;s:3:\"100\";i:2;s:3:\"102\";i:3;s:3:\"103\";i:4;s:3:\"104\";}', 'no'),
(2849, '_transient_timeout__woocommerce_helper_subscriptions', '1523863966', 'no'),
(2850, '_transient__woocommerce_helper_subscriptions', 'a:0:{}', 'no'),
(2851, '_site_transient_timeout_theme_roots', '1523864866', 'no'),
(2852, '_site_transient_theme_roots', 'a:1:{s:2:\"RT\";s:7:\"/themes\";}', 'no'),
(2853, '_transient_timeout__woocommerce_helper_updates', '1523906266', 'no'),
(2854, '_transient__woocommerce_helper_updates', 'a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1523863066;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}', 'no'),
(2855, '_site_transient_timeout_browser_efc56fe28520bcd166ef136f44025003', '1524467869', 'no'),
(2856, '_site_transient_browser_efc56fe28520bcd166ef136f44025003', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"65.0.3325.181\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(2857, '_transient_timeout_wpseo-statistics-totals', '1523949471', 'no'),
(2858, '_transient_wpseo-statistics-totals', 'a:1:{i:1;a:2:{s:6:\"scores\";a:1:{i:0;a:4:{s:8:\"seo_rank\";s:2:\"na\";s:5:\"label\";s:46:\"Posts <strong>without</strong> a focus keyword\";s:5:\"count\";s:2:\"11\";s:4:\"link\";s:119:\"http://khomaudepraothue.com/anhduongtaybac/wp-admin/edit.php?post_status=publish&#038;post_type=post&#038;seo_filter=na\";}}s:8:\"division\";a:5:{s:3:\"bad\";i:0;s:2:\"ok\";i:0;s:4:\"good\";i:0;s:2:\"na\";i:1;s:7:\"noindex\";i:0;}}}', 'no'),
(2859, '_transient_timeout_wc_related_102', '1524187395', 'no'),
(2860, '_transient_wc_related_102', 'a:5:{i:0;s:2:\"99\";i:1;s:3:\"100\";i:2;s:3:\"101\";i:3;s:3:\"103\";i:4;s:3:\"104\";}', 'no'),
(2861, '_transient_timeout_wc_related_103', '1524381363', 'no'),
(2862, '_transient_wc_related_103', 'a:5:{i:0;s:2:\"99\";i:1;s:3:\"100\";i:2;s:3:\"101\";i:3;s:3:\"102\";i:4;s:3:\"104\";}', 'no'),
(2863, '_transient_timeout_wc_related_104', '1528284012', 'no'),
(2864, '_transient_wc_related_104', 'a:5:{i:0;s:2:\"99\";i:1;s:3:\"100\";i:2;s:3:\"101\";i:3;s:3:\"102\";i:4;s:3:\"103\";}', 'no'),
(2865, '_transient_timeout_wc_term_counts', '1530789612', 'no'),
(2866, '_transient_wc_term_counts', 'a:8:{i:24;s:1:\"6\";i:28;s:1:\"6\";i:29;s:1:\"6\";i:30;s:1:\"6\";i:31;s:1:\"6\";i:27;s:1:\"6\";i:25;s:1:\"6\";i:26;s:1:\"6\";}', 'no');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_postmeta`
--

CREATE TABLE `rt_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_postmeta`
--

INSERT INTO `rt_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(6, 2, '_edit_lock', '1497500417:1'),
(7, 2, '_edit_last', '1'),
(8, 2, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(9, 6, '_form', '<div class=\"form-lienhe\">\n<div class=\"box-colum-1\"><div class=\"left\"><label>Họ tên</label>[text text-545 placeholder \"Nhập họ và tên\"]</div><div class=\"right\"><label>Điện thoại</label>[number number-683 placeholder \"Nhập số điện thoại\"]</div></div>\n<div class=\"box-colum-2\"><label>Địa chỉ</label>[text text-546 placeholder \"Địa chỉ\"]</div>\n<div class=\"box-colum-3\"><label>Nội dung</label>[textarea textarea-444 placeholder \"Nhập nội dung liên hệ\"]</div>\n<div class=\"submits\">[submit \"Gửi liên hệ\"]</div>\n</div>'),
(10, 6, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:26:\"RT - Core \"[your-subject]\"\";s:6:\"sender\";s:44:\"[your-name] <wordpress@khomaudepraothue.com>\";s:9:\"recipient\";s:24:\"phamtuan170291@gmail.com\";s:4:\"body\";s:227:\"Họ tên:[text-545]\nĐiện thoại:[number-683]\nĐịa chỉ:[text-546]\nNội dung:[textarea-444]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on RT - Core (http://raothue.ddns.net/demo/rt-core)\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(11, 6, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:26:\"RT - Core \"[your-subject]\"\";s:6:\"sender\";s:38:\"RT - Core <wordpress@raothue.ddns.net>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:126:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on RT - Core (http://raothue.ddns.net/demo/rt-core)\";s:18:\"additional_headers\";s:34:\"Reply-To: phamtuan170291@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(12, 6, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(13, 6, '_additional_settings', ''),
(14, 6, '_locale', 'vi'),
(18, 12, 'ml-slider_settings', 'a:35:{s:4:\"type\";s:4:\"nivo\";s:6:\"random\";s:5:\"false\";s:8:\"cssClass\";s:0:\"\";s:8:\"printCss\";s:4:\"true\";s:7:\"printJs\";s:4:\"true\";s:5:\"width\";s:4:\"1000\";s:6:\"height\";s:1:\"0\";s:3:\"spw\";s:1:\"7\";s:3:\"sph\";s:1:\"5\";s:5:\"delay\";s:4:\"3000\";s:6:\"sDelay\";i:30;s:7:\"opacity\";d:0.6999999999999999555910790149937383830547332763671875;s:10:\"titleSpeed\";i:500;s:6:\"effect\";s:6:\"random\";s:10:\"navigation\";s:5:\"false\";s:5:\"links\";s:4:\"true\";s:10:\"hoverPause\";s:4:\"true\";s:5:\"theme\";s:7:\"default\";s:9:\"direction\";s:10:\"horizontal\";s:7:\"reverse\";s:5:\"false\";s:14:\"animationSpeed\";s:3:\"600\";s:8:\"prevText\";s:1:\"<\";s:8:\"nextText\";s:1:\">\";s:6:\"slices\";s:2:\"15\";s:6:\"center\";s:5:\"false\";s:9:\"smartCrop\";s:4:\"true\";s:12:\"carouselMode\";s:5:\"false\";s:14:\"carouselMargin\";s:1:\"5\";s:6:\"easing\";s:6:\"linear\";s:8:\"autoPlay\";s:4:\"true\";s:11:\"thumb_width\";i:150;s:12:\"thumb_height\";i:100;s:9:\"fullWidth\";s:5:\"false\";s:10:\"noConflict\";s:5:\"false\";s:12:\"smoothHeight\";s:5:\"false\";}'),
(22, 15, '_edit_last', '1'),
(23, 15, '_edit_lock', '1497508416:1'),
(24, 15, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(25, 15, '_yoast_wpseo_content_score', '30'),
(44, 19, '_menu_item_type', 'post_type'),
(45, 19, '_menu_item_menu_item_parent', '0'),
(46, 19, '_menu_item_object_id', '15'),
(47, 19, '_menu_item_object', 'page'),
(48, 19, '_menu_item_target', ''),
(49, 19, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(50, 19, '_menu_item_xfn', ''),
(51, 19, '_menu_item_url', ''),
(62, 21, '_menu_item_type', 'post_type'),
(63, 21, '_menu_item_menu_item_parent', '159'),
(64, 21, '_menu_item_object_id', '2'),
(65, 21, '_menu_item_object', 'page'),
(66, 21, '_menu_item_target', ''),
(67, 21, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(68, 21, '_menu_item_xfn', ''),
(69, 21, '_menu_item_url', ''),
(431, 53, '_wp_attachment_image_alt', ''),
(432, 53, 'ml-slider_type', 'image'),
(434, 53, 'ml-slider_crop_position', 'center-center'),
(448, 60, '_menu_item_type', 'custom'),
(449, 60, '_menu_item_menu_item_parent', '163'),
(450, 60, '_menu_item_object_id', '60'),
(451, 60, '_menu_item_object', 'custom'),
(452, 60, '_menu_item_target', ''),
(453, 60, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(454, 60, '_menu_item_xfn', ''),
(455, 60, '_menu_item_url', '#'),
(457, 61, '_menu_item_type', 'custom'),
(458, 61, '_menu_item_menu_item_parent', '163'),
(459, 61, '_menu_item_object_id', '61'),
(460, 61, '_menu_item_object', 'custom'),
(461, 61, '_menu_item_target', ''),
(462, 61, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(463, 61, '_menu_item_xfn', ''),
(464, 61, '_menu_item_url', '#'),
(539, 74, '_wp_attached_file', '2017/09/1.jpg'),
(540, 74, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1200;s:4:\"file\";s:13:\"2017/09/1.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:14:\"1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"1-180x135.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:135;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"1-600x450.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(541, 75, '_wp_attached_file', '2017/09/2.jpg'),
(542, 75, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1200;s:4:\"file\";s:13:\"2017/09/2.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:14:\"2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"2-180x135.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:135;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"2-600x450.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(543, 76, '_wp_attached_file', '2017/09/3.jpg'),
(544, 76, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1200;s:4:\"file\";s:13:\"2017/09/3.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"3-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"3-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:14:\"3-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"3-180x135.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:135;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"3-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"3-600x450.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(545, 77, '_wp_attached_file', '2017/09/4.jpg'),
(546, 77, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1200;s:4:\"file\";s:13:\"2017/09/4.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"4-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"4-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:14:\"4-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"4-180x135.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:135;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"4-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"4-600x450.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(547, 78, '_wp_attached_file', '2017/09/5.jpg'),
(548, 78, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1200;s:4:\"file\";s:13:\"2017/09/5.jpg\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"5-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"5-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:14:\"5-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"5-180x135.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:135;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"5-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"5-600x450.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:28:\"meta-slider-resized-1200x450\";a:4:{s:4:\"file\";s:14:\"5-1200x450.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:28:\"meta-slider-resized-1200x350\";a:4:{s:4:\"file\";s:14:\"5-1200x350.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:28:\"meta-slider-resized-1000x350\";a:4:{s:4:\"file\";s:14:\"5-1000x350.jpg\";s:5:\"width\";i:1000;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(549, 79, '_wp_attached_file', '2017/09/6.jpg'),
(550, 79, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1200;s:4:\"file\";s:13:\"2017/09/6.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"6-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"6-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:14:\"6-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"6-180x135.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:135;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"6-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"6-600x450.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(551, 80, '_wp_attached_file', '2017/09/logo.png'),
(552, 80, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:304;s:6:\"height\";i:65;s:4:\"file\";s:16:\"2017/09/logo.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-150x65.png\";s:5:\"width\";i:150;s:6:\"height\";i:65;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"logo-300x64.png\";s:5:\"width\";i:300;s:6:\"height\";i:64;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-180x38.png\";s:5:\"width\";i:180;s:6:\"height\";i:38;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"logo-300x64.png\";s:5:\"width\";i:300;s:6:\"height\";i:64;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(553, 81, '_edit_last', '1'),
(554, 81, '_edit_lock', '1504595809:1'),
(555, 81, '_thumbnail_id', '74'),
(557, 81, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(558, 81, '_yoast_wpseo_content_score', '30'),
(559, 81, '_yoast_wpseo_primary_category', '2'),
(560, 83, '_thumbnail_id', '75'),
(561, 83, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(562, 83, '_yoast_wpseo_content_score', '30'),
(563, 83, '_yoast_wpseo_primary_category', '2'),
(564, 83, '_dp_original', '81'),
(565, 83, '_edit_lock', '1504595832:1'),
(566, 83, '_edit_last', '1'),
(568, 83, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(569, 85, '_thumbnail_id', '76'),
(570, 85, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(571, 85, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(572, 85, '_yoast_wpseo_content_score', '30'),
(573, 85, '_yoast_wpseo_primary_category', '2'),
(575, 85, '_dp_original', '83'),
(576, 85, '_edit_lock', '1504595869:1'),
(577, 85, '_edit_last', '1'),
(579, 85, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(580, 87, '_thumbnail_id', '77'),
(581, 87, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(582, 87, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(583, 87, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(584, 87, '_yoast_wpseo_content_score', '30'),
(585, 87, '_yoast_wpseo_primary_category', '2'),
(587, 87, '_dp_original', '85'),
(588, 87, '_edit_lock', '1504595890:1'),
(589, 87, '_edit_last', '1'),
(591, 87, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(592, 89, '_thumbnail_id', '78'),
(593, 89, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(594, 89, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(595, 89, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(596, 89, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(597, 89, '_yoast_wpseo_content_score', '30'),
(598, 89, '_yoast_wpseo_primary_category', '2'),
(600, 89, '_dp_original', '87'),
(601, 89, '_edit_lock', '1504595912:1'),
(602, 89, '_edit_last', '1'),
(604, 89, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(605, 91, '_thumbnail_id', '79'),
(606, 91, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(607, 91, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(608, 91, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(609, 91, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(610, 91, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(611, 91, '_yoast_wpseo_content_score', '30'),
(612, 91, '_yoast_wpseo_primary_category', '2'),
(614, 91, '_dp_original', '89'),
(615, 91, '_edit_lock', '1504595933:1'),
(616, 91, '_edit_last', '1'),
(618, 91, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(619, 93, '_thumbnail_id', '75'),
(620, 93, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(621, 93, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(622, 93, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(623, 93, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(624, 93, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(625, 93, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(626, 93, '_yoast_wpseo_content_score', '30'),
(627, 93, '_yoast_wpseo_primary_category', '2'),
(629, 93, '_dp_original', '91'),
(630, 93, '_edit_lock', '1504595955:1'),
(631, 93, '_edit_last', '1'),
(633, 93, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(634, 95, '_thumbnail_id', '77'),
(635, 95, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(636, 95, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(637, 95, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(638, 95, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(639, 95, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(640, 95, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(641, 95, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(642, 95, '_yoast_wpseo_content_score', '30'),
(643, 95, '_yoast_wpseo_primary_category', '2'),
(645, 95, '_dp_original', '93'),
(646, 95, '_edit_lock', '1504595983:1'),
(647, 95, '_edit_last', '1'),
(649, 95, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(667, 99, '_wc_review_count', '0'),
(668, 99, '_wc_rating_count', 'a:0:{}'),
(669, 99, '_wc_average_rating', '0'),
(670, 99, '_edit_last', '1'),
(671, 99, '_edit_lock', '1504596767:1'),
(672, 99, '_thumbnail_id', '76'),
(673, 99, '_sku', ''),
(674, 99, '_regular_price', '4500000'),
(675, 99, '_sale_price', '3900000'),
(676, 99, '_sale_price_dates_from', ''),
(677, 99, '_sale_price_dates_to', ''),
(678, 99, 'total_sales', '0'),
(679, 99, '_tax_status', 'taxable'),
(680, 99, '_tax_class', ''),
(681, 99, '_manage_stock', 'no'),
(682, 99, '_backorders', 'no'),
(683, 99, '_sold_individually', 'no'),
(684, 99, '_weight', ''),
(685, 99, '_length', ''),
(686, 99, '_width', ''),
(687, 99, '_height', ''),
(688, 99, '_upsell_ids', 'a:0:{}'),
(689, 99, '_crosssell_ids', 'a:0:{}'),
(690, 99, '_purchase_note', ''),
(691, 99, '_default_attributes', 'a:0:{}'),
(692, 99, '_virtual', 'no'),
(693, 99, '_downloadable', 'no'),
(694, 99, '_product_image_gallery', '77,78,79'),
(695, 99, '_download_limit', '-1'),
(696, 99, '_download_expiry', '-1'),
(697, 99, '_stock', NULL),
(698, 99, '_stock_status', 'instock'),
(699, 99, '_product_version', '3.1.2'),
(700, 99, '_price', '3900000'),
(701, 99, '_yoast_wpseo_primary_product_cat', '24'),
(702, 99, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(703, 99, '_yoast_wpseo_content_score', '60'),
(704, 100, '_sku', ''),
(705, 100, '_regular_price', '4500000'),
(706, 100, '_sale_price', '3900000'),
(707, 100, '_sale_price_dates_from', ''),
(708, 100, '_sale_price_dates_to', ''),
(709, 100, 'total_sales', '0'),
(710, 100, '_tax_status', 'taxable'),
(711, 100, '_tax_class', ''),
(712, 100, '_manage_stock', 'no'),
(713, 100, '_backorders', 'no'),
(714, 100, '_sold_individually', 'no'),
(715, 100, '_weight', ''),
(716, 100, '_length', ''),
(717, 100, '_width', ''),
(718, 100, '_height', ''),
(719, 100, '_upsell_ids', 'a:0:{}'),
(720, 100, '_crosssell_ids', 'a:0:{}'),
(721, 100, '_purchase_note', ''),
(722, 100, '_default_attributes', 'a:0:{}'),
(723, 100, '_virtual', 'no'),
(724, 100, '_downloadable', 'no'),
(725, 100, '_product_image_gallery', '77,78,79'),
(726, 100, '_download_limit', '-1'),
(727, 100, '_download_expiry', '-1'),
(728, 100, '_thumbnail_id', '74'),
(729, 100, '_stock', NULL),
(730, 100, '_stock_status', 'instock'),
(731, 100, '_wc_average_rating', '0'),
(732, 100, '_wc_rating_count', 'a:0:{}'),
(733, 100, '_wc_review_count', '0'),
(734, 100, '_downloadable_files', 'a:0:{}'),
(735, 100, '_product_attributes', 'a:0:{}'),
(736, 100, '_product_version', '3.1.2'),
(737, 100, '_price', '3900000'),
(738, 100, '_yoast_wpseo_primary_product_cat', '24'),
(739, 100, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(740, 100, '_yoast_wpseo_content_score', '60'),
(741, 100, '_edit_lock', '1504596796:1'),
(742, 100, '_edit_last', '1'),
(743, 101, '_sku', ''),
(744, 101, '_regular_price', '4500000'),
(745, 101, '_sale_price', '3900000'),
(746, 101, '_sale_price_dates_from', ''),
(747, 101, '_sale_price_dates_to', ''),
(748, 101, 'total_sales', '0'),
(749, 101, '_tax_status', 'taxable'),
(750, 101, '_tax_class', ''),
(751, 101, '_manage_stock', 'no'),
(752, 101, '_backorders', 'no'),
(753, 101, '_sold_individually', 'no'),
(754, 101, '_weight', ''),
(755, 101, '_length', ''),
(756, 101, '_width', ''),
(757, 101, '_height', ''),
(758, 101, '_upsell_ids', 'a:0:{}'),
(759, 101, '_crosssell_ids', 'a:0:{}'),
(760, 101, '_purchase_note', ''),
(761, 101, '_default_attributes', 'a:0:{}'),
(762, 101, '_virtual', 'no'),
(763, 101, '_downloadable', 'no'),
(764, 101, '_product_image_gallery', '77,78,79'),
(765, 101, '_download_limit', '-1'),
(766, 101, '_download_expiry', '-1'),
(767, 101, '_thumbnail_id', '75'),
(768, 101, '_stock', NULL),
(769, 101, '_stock_status', 'instock'),
(770, 101, '_wc_average_rating', '0'),
(771, 101, '_wc_rating_count', 'a:0:{}'),
(772, 101, '_wc_review_count', '0'),
(773, 101, '_downloadable_files', 'a:0:{}'),
(774, 101, '_product_attributes', 'a:0:{}'),
(775, 101, '_product_version', '3.1.2'),
(776, 101, '_price', '3900000'),
(777, 101, '_yoast_wpseo_primary_product_cat', '24'),
(778, 101, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(779, 101, '_yoast_wpseo_content_score', '60'),
(780, 101, '_edit_lock', '1504596834:1'),
(781, 101, '_edit_last', '1'),
(782, 102, '_sku', ''),
(783, 102, '_regular_price', '4500000'),
(784, 102, '_sale_price', '3900000'),
(785, 102, '_sale_price_dates_from', ''),
(786, 102, '_sale_price_dates_to', ''),
(787, 102, 'total_sales', '0'),
(788, 102, '_tax_status', 'taxable'),
(789, 102, '_tax_class', ''),
(790, 102, '_manage_stock', 'no'),
(791, 102, '_backorders', 'no'),
(792, 102, '_sold_individually', 'no'),
(793, 102, '_weight', ''),
(794, 102, '_length', ''),
(795, 102, '_width', ''),
(796, 102, '_height', ''),
(797, 102, '_upsell_ids', 'a:0:{}'),
(798, 102, '_crosssell_ids', 'a:0:{}'),
(799, 102, '_purchase_note', ''),
(800, 102, '_default_attributes', 'a:0:{}'),
(801, 102, '_virtual', 'no'),
(802, 102, '_downloadable', 'no'),
(803, 102, '_product_image_gallery', '77,78,79'),
(804, 102, '_download_limit', '-1'),
(805, 102, '_download_expiry', '-1'),
(806, 102, '_thumbnail_id', '77'),
(807, 102, '_stock', NULL),
(808, 102, '_stock_status', 'instock'),
(809, 102, '_wc_average_rating', '0'),
(810, 102, '_wc_rating_count', 'a:0:{}'),
(811, 102, '_wc_review_count', '0'),
(812, 102, '_downloadable_files', 'a:0:{}'),
(813, 102, '_product_attributes', 'a:0:{}'),
(814, 102, '_product_version', '3.1.2'),
(815, 102, '_price', '3900000'),
(816, 102, '_yoast_wpseo_primary_product_cat', '24'),
(817, 102, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(818, 102, '_yoast_wpseo_content_score', '60'),
(819, 102, '_edit_lock', '1504596855:1'),
(820, 102, '_edit_last', '1'),
(821, 103, '_sku', ''),
(822, 103, '_regular_price', '4500000'),
(823, 103, '_sale_price', '3900000'),
(824, 103, '_sale_price_dates_from', ''),
(825, 103, '_sale_price_dates_to', ''),
(826, 103, 'total_sales', '0'),
(827, 103, '_tax_status', 'taxable'),
(828, 103, '_tax_class', ''),
(829, 103, '_manage_stock', 'no'),
(830, 103, '_backorders', 'no'),
(831, 103, '_sold_individually', 'no'),
(832, 103, '_weight', ''),
(833, 103, '_length', ''),
(834, 103, '_width', ''),
(835, 103, '_height', ''),
(836, 103, '_upsell_ids', 'a:0:{}'),
(837, 103, '_crosssell_ids', 'a:0:{}'),
(838, 103, '_purchase_note', ''),
(839, 103, '_default_attributes', 'a:0:{}'),
(840, 103, '_virtual', 'no'),
(841, 103, '_downloadable', 'no'),
(842, 103, '_product_image_gallery', '77,78,79'),
(843, 103, '_download_limit', '-1'),
(844, 103, '_download_expiry', '-1'),
(845, 103, '_thumbnail_id', '78'),
(846, 103, '_stock', NULL),
(847, 103, '_stock_status', 'instock'),
(848, 103, '_wc_average_rating', '0'),
(849, 103, '_wc_rating_count', 'a:0:{}'),
(850, 103, '_wc_review_count', '0'),
(851, 103, '_downloadable_files', 'a:0:{}'),
(852, 103, '_product_attributes', 'a:0:{}'),
(853, 103, '_product_version', '3.1.2'),
(854, 103, '_price', '3900000'),
(855, 103, '_yoast_wpseo_primary_product_cat', '24'),
(856, 103, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(857, 103, '_yoast_wpseo_content_score', '60'),
(858, 103, '_edit_lock', '1504596908:1'),
(859, 103, '_edit_last', '1'),
(860, 104, '_sku', 'A0001'),
(861, 104, '_regular_price', '4500000'),
(862, 104, '_sale_price', '3900000'),
(863, 104, '_sale_price_dates_from', ''),
(864, 104, '_sale_price_dates_to', ''),
(865, 104, 'total_sales', '0'),
(866, 104, '_tax_status', 'taxable'),
(867, 104, '_tax_class', ''),
(868, 104, '_manage_stock', 'no'),
(869, 104, '_backorders', 'no'),
(870, 104, '_sold_individually', 'no'),
(871, 104, '_weight', ''),
(872, 104, '_length', ''),
(873, 104, '_width', ''),
(874, 104, '_height', ''),
(875, 104, '_upsell_ids', 'a:0:{}'),
(876, 104, '_crosssell_ids', 'a:0:{}'),
(877, 104, '_purchase_note', ''),
(878, 104, '_default_attributes', 'a:0:{}'),
(879, 104, '_virtual', 'no'),
(880, 104, '_downloadable', 'no'),
(881, 104, '_product_image_gallery', '77,78,79'),
(882, 104, '_download_limit', '-1'),
(883, 104, '_download_expiry', '-1'),
(884, 104, '_thumbnail_id', '79'),
(885, 104, '_stock', NULL),
(886, 104, '_stock_status', 'instock'),
(887, 104, '_wc_average_rating', '5.00'),
(888, 104, '_wc_rating_count', 'a:1:{i:5;i:1;}'),
(889, 104, '_wc_review_count', '1'),
(890, 104, '_downloadable_files', 'a:0:{}'),
(891, 104, '_product_attributes', 'a:4:{s:11:\"pa_bao-hanh\";a:6:{s:4:\"name\";s:11:\"pa_bao-hanh\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}s:10:\"pa_mau-sac\";a:6:{s:4:\"name\";s:10:\"pa_mau-sac\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:1;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}s:15:\"pa_noi-san-xuat\";a:6:{s:4:\"name\";s:15:\"pa_noi-san-xuat\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:2;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}s:14:\"pa_thuong-hieu\";a:6:{s:4:\"name\";s:14:\"pa_thuong-hieu\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:3;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(892, 104, '_product_version', '3.2.5'),
(893, 104, '_price', '3900000'),
(894, 104, '_yoast_wpseo_primary_product_cat', '24'),
(895, 104, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(896, 104, '_yoast_wpseo_content_score', '60'),
(897, 104, '_edit_lock', '1513003023:1'),
(898, 104, '_edit_last', '1'),
(899, 105, '_thumbnail_id', '134'),
(900, 105, '_wp_attachment_image_alt', ''),
(901, 105, 'ml-slider_type', 'image'),
(902, 78, '_wp_attachment_backup_sizes', 'a:3:{s:16:\"resized-1200x450\";a:5:{s:4:\"path\";s:57:\"C:wampwwwRT-Aug/wp-content/uploads/2017/09/5-1200x450.jpg\";s:4:\"file\";s:14:\"5-1200x450.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"resized-1200x350\";a:5:{s:4:\"path\";s:57:\"C:wampwwwRT-Aug/wp-content/uploads/2017/09/5-1200x350.jpg\";s:4:\"file\";s:14:\"5-1200x350.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:16:\"resized-1000x350\";a:5:{s:4:\"path\";s:65:\"D:xampphtdocscode-toiuu/wp-content/uploads/2017/09/5-1000x350.jpg\";s:4:\"file\";s:14:\"5-1000x350.jpg\";s:5:\"width\";i:1000;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}}'),
(903, 105, 'ml-slider_crop_position', 'center-center'),
(913, 107, '_menu_item_type', 'post_type'),
(914, 107, '_menu_item_menu_item_parent', '159'),
(915, 107, '_menu_item_object_id', '2'),
(916, 107, '_menu_item_object', 'page'),
(917, 107, '_menu_item_target', ''),
(918, 107, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(919, 107, '_menu_item_xfn', ''),
(920, 107, '_menu_item_url', ''),
(923, 110, '_menu_item_type', 'custom'),
(924, 110, '_menu_item_menu_item_parent', '0'),
(925, 110, '_menu_item_object_id', '110'),
(926, 110, '_menu_item_object', 'custom'),
(927, 110, '_menu_item_target', ''),
(928, 110, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(929, 110, '_menu_item_xfn', ''),
(930, 110, '_menu_item_url', 'http://khomaudepraothue.com/anhduongtaybac'),
(933, 95, 'post_views_count', '16'),
(934, 93, 'post_views_count', '16'),
(935, 91, 'post_views_count', '14'),
(936, 89, 'post_views_count', '12'),
(937, 87, 'post_views_count', '11'),
(938, 85, 'post_views_count', '11'),
(939, 83, 'post_views_count', '12'),
(940, 81, 'post_views_count', '13'),
(941, 113, '_edit_last', '1'),
(942, 113, '_wp_page_template', 'default'),
(943, 113, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(944, 113, '_yoast_wpseo_content_score', '30'),
(945, 113, '_edit_lock', '1516678998:1'),
(956, 116, '_edit_last', '1'),
(957, 116, '_wp_page_template', 'default'),
(958, 116, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(959, 116, '_yoast_wpseo_content_score', '30'),
(960, 116, '_edit_lock', '1516678988:1'),
(975, 124, '_menu_item_type', 'post_type'),
(976, 124, '_menu_item_menu_item_parent', '0'),
(977, 124, '_menu_item_object_id', '116'),
(978, 124, '_menu_item_object', 'page'),
(979, 124, '_menu_item_target', ''),
(980, 124, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(981, 124, '_menu_item_xfn', ''),
(982, 124, '_menu_item_url', ''),
(1002, 127, '_menu_item_type', 'post_type'),
(1003, 127, '_menu_item_menu_item_parent', '0'),
(1004, 127, '_menu_item_object_id', '113'),
(1005, 127, '_menu_item_object', 'page'),
(1006, 127, '_menu_item_target', ''),
(1007, 127, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1008, 127, '_menu_item_xfn', ''),
(1009, 127, '_menu_item_url', ''),
(1011, 128, '_menu_item_type', 'post_type'),
(1012, 128, '_menu_item_menu_item_parent', '0'),
(1013, 128, '_menu_item_object_id', '15'),
(1014, 128, '_menu_item_object', 'page'),
(1015, 128, '_menu_item_target', ''),
(1016, 128, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1017, 128, '_menu_item_xfn', ''),
(1018, 128, '_menu_item_url', ''),
(1020, 129, '_wp_attached_file', '2017/09/map.png'),
(1021, 129, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:300;s:6:\"height\";i:150;s:4:\"file\";s:15:\"2017/09/map.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"map-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"map-300x150.png\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:14:\"map-180x90.png\";s:5:\"width\";i:180;s:6:\"height\";i:90;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"map-300x150.png\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1026, 131, '_wp_attached_file', '2017/12/2.jpg'),
(1027, 131, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:807;s:4:\"file\";s:13:\"2017/12/2.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"2-242x300.jpg\";s:5:\"width\";i:242;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"2-145x180.jpg\";s:5:\"width\";i:145;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"2-242x300.jpg\";s:5:\"width\";i:242;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"2-483x600.jpg\";s:5:\"width\";i:483;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1028, 133, '_wp_attached_file', '2018/01/banner.png'),
(1029, 133, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:169;s:4:\"file\";s:18:\"2018/01/banner.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"banner-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"banner-300x51.png\";s:5:\"width\";i:300;s:6:\"height\";i:51;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"banner-768x130.png\";s:5:\"width\";i:768;s:6:\"height\";i:130;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"banner-180x30.png\";s:5:\"width\";i:180;s:6:\"height\";i:30;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:17:\"banner-300x51.png\";s:5:\"width\";i:300;s:6:\"height\";i:51;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"banner-600x101.png\";s:5:\"width\";i:600;s:6:\"height\";i:101;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1030, 134, '_wp_attached_file', '2018/01/slider1.png'),
(1031, 134, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:743;s:6:\"height\";i:300;s:4:\"file\";s:19:\"2018/01/slider1.png\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"slider1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"slider1-300x121.png\";s:5:\"width\";i:300;s:6:\"height\";i:121;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"slider1-180x73.png\";s:5:\"width\";i:180;s:6:\"height\";i:73;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:19:\"slider1-300x121.png\";s:5:\"width\";i:300;s:6:\"height\";i:121;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"slider1-600x242.png\";s:5:\"width\";i:600;s:6:\"height\";i:242;s:9:\"mime-type\";s:9:\"image/png\";}s:27:\"meta-slider-resized-743x260\";a:4:{s:4:\"file\";s:19:\"slider1-743x260.png\";s:5:\"width\";i:743;s:6:\"height\";i:260;s:9:\"mime-type\";s:9:\"image/png\";}s:23:\"meta-slider-resized-0x0\";a:4:{s:4:\"file\";s:15:\"slider1-0x0.png\";s:5:\"width\";i:743;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:25:\"meta-slider-resized-743x0\";a:4:{s:4:\"file\";s:17:\"slider1-743x0.png\";s:5:\"width\";i:743;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1032, 135, '_wp_attached_file', '2018/01/slider2.png'),
(1033, 135, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:743;s:6:\"height\";i:300;s:4:\"file\";s:19:\"2018/01/slider2.png\";s:5:\"sizes\";a:8:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"slider2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"slider2-300x121.png\";s:5:\"width\";i:300;s:6:\"height\";i:121;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"slider2-180x73.png\";s:5:\"width\";i:180;s:6:\"height\";i:73;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:19:\"slider2-300x121.png\";s:5:\"width\";i:300;s:6:\"height\";i:121;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"slider2-600x242.png\";s:5:\"width\";i:600;s:6:\"height\";i:242;s:9:\"mime-type\";s:9:\"image/png\";}s:27:\"meta-slider-resized-743x260\";a:4:{s:4:\"file\";s:19:\"slider2-743x260.png\";s:5:\"width\";i:743;s:6:\"height\";i:260;s:9:\"mime-type\";s:9:\"image/png\";}s:23:\"meta-slider-resized-0x0\";a:4:{s:4:\"file\";s:15:\"slider2-0x0.png\";s:5:\"width\";i:743;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:25:\"meta-slider-resized-743x0\";a:4:{s:4:\"file\";s:17:\"slider2-743x0.png\";s:5:\"width\";i:743;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1034, 136, '_thumbnail_id', '135'),
(1035, 136, '_wp_attachment_image_alt', ''),
(1036, 136, 'ml-slider_type', 'image'),
(1037, 135, '_wp_attachment_backup_sizes', 'a:3:{s:15:\"resized-743x260\";a:5:{s:4:\"path\";s:102:\"/home/ngoctanr/cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/slider2-743x260.png\";s:4:\"file\";s:19:\"slider2-743x260.png\";s:5:\"width\";i:743;s:6:\"height\";i:260;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"resized-0x0\";a:5:{s:4:\"path\";s:98:\"/home/ngoctanr/cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/slider2-0x0.png\";s:4:\"file\";s:15:\"slider2-0x0.png\";s:5:\"width\";i:743;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"resized-743x0\";a:5:{s:4:\"path\";s:100:\"/home/ngoctanr/cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/slider2-743x0.png\";s:4:\"file\";s:17:\"slider2-743x0.png\";s:5:\"width\";i:743;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}'),
(1038, 136, 'ml-slider_crop_position', 'center-center'),
(1039, 134, '_wp_attachment_backup_sizes', 'a:3:{s:15:\"resized-743x260\";a:5:{s:4:\"path\";s:102:\"/home/ngoctanr/cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/slider1-743x260.png\";s:4:\"file\";s:19:\"slider1-743x260.png\";s:5:\"width\";i:743;s:6:\"height\";i:260;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"resized-0x0\";a:5:{s:4:\"path\";s:98:\"/home/ngoctanr/cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/slider1-0x0.png\";s:4:\"file\";s:15:\"slider1-0x0.png\";s:5:\"width\";i:743;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"resized-743x0\";a:5:{s:4:\"path\";s:100:\"/home/ngoctanr/cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/slider1-743x0.png\";s:4:\"file\";s:17:\"slider1-743x0.png\";s:5:\"width\";i:743;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}'),
(1040, 138, '_edit_last', '1'),
(1041, 138, '_edit_lock', '1516679109:1'),
(1042, 138, '_wp_page_template', 'default'),
(1043, 138, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1044, 138, '_yoast_wpseo_content_score', '30'),
(1045, 140, '_edit_last', '1'),
(1046, 140, '_edit_lock', '1516679003:1'),
(1047, 140, '_wp_page_template', 'default'),
(1048, 140, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1049, 140, '_yoast_wpseo_content_score', '30'),
(1050, 140, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1056, 145, '_edit_last', '1'),
(1057, 145, '_wp_page_template', 'default'),
(1058, 145, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1059, 145, '_yoast_wpseo_content_score', '30'),
(1060, 145, '_edit_lock', '1516679002:1'),
(1079, 147, '_edit_last', '1'),
(1080, 147, '_wp_page_template', 'default'),
(1081, 147, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1082, 147, '_yoast_wpseo_content_score', '30'),
(1083, 147, '_edit_lock', '1516678991:1'),
(1084, 152, '_edit_last', '1'),
(1085, 152, '_wp_page_template', 'default'),
(1086, 152, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1087, 152, '_yoast_wpseo_content_score', '30'),
(1088, 152, '_edit_lock', '1516678961:1'),
(1089, 154, '_edit_last', '1'),
(1090, 154, '_wp_page_template', 'default'),
(1091, 154, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}');
INSERT INTO `rt_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1092, 154, '_yoast_wpseo_content_score', '30'),
(1093, 154, '_edit_lock', '1516678988:1'),
(1094, 156, '_menu_item_type', 'post_type'),
(1095, 156, '_menu_item_menu_item_parent', '0'),
(1096, 156, '_menu_item_object_id', '138'),
(1097, 156, '_menu_item_object', 'page'),
(1098, 156, '_menu_item_target', ''),
(1099, 156, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1100, 156, '_menu_item_xfn', ''),
(1101, 156, '_menu_item_url', ''),
(1103, 157, '_menu_item_type', 'post_type'),
(1104, 157, '_menu_item_menu_item_parent', '0'),
(1105, 157, '_menu_item_object_id', '140'),
(1106, 157, '_menu_item_object', 'page'),
(1107, 157, '_menu_item_target', ''),
(1108, 157, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1109, 157, '_menu_item_xfn', ''),
(1110, 157, '_menu_item_url', ''),
(1121, 159, '_menu_item_type', 'taxonomy'),
(1122, 159, '_menu_item_menu_item_parent', '0'),
(1123, 159, '_menu_item_object_id', '2'),
(1124, 159, '_menu_item_object', 'category'),
(1125, 159, '_menu_item_target', ''),
(1126, 159, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1127, 159, '_menu_item_xfn', ''),
(1128, 159, '_menu_item_url', ''),
(1130, 160, '_menu_item_type', 'post_type'),
(1131, 160, '_menu_item_menu_item_parent', '0'),
(1132, 160, '_menu_item_object_id', '145'),
(1133, 160, '_menu_item_object', 'page'),
(1134, 160, '_menu_item_target', ''),
(1135, 160, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1136, 160, '_menu_item_xfn', ''),
(1137, 160, '_menu_item_url', ''),
(1139, 161, '_menu_item_type', 'taxonomy'),
(1140, 161, '_menu_item_menu_item_parent', '0'),
(1141, 161, '_menu_item_object_id', '40'),
(1142, 161, '_menu_item_object', 'category'),
(1143, 161, '_menu_item_target', ''),
(1144, 161, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1145, 161, '_menu_item_xfn', ''),
(1146, 161, '_menu_item_url', ''),
(1148, 162, '_menu_item_type', 'taxonomy'),
(1149, 162, '_menu_item_menu_item_parent', '0'),
(1150, 162, '_menu_item_object_id', '41'),
(1151, 162, '_menu_item_object', 'category'),
(1152, 162, '_menu_item_target', ''),
(1153, 162, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1154, 162, '_menu_item_xfn', ''),
(1155, 162, '_menu_item_url', ''),
(1157, 163, '_menu_item_type', 'taxonomy'),
(1158, 163, '_menu_item_menu_item_parent', '0'),
(1159, 163, '_menu_item_object_id', '39'),
(1160, 163, '_menu_item_object', 'category'),
(1161, 163, '_menu_item_target', ''),
(1162, 163, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1163, 163, '_menu_item_xfn', ''),
(1164, 163, '_menu_item_url', ''),
(1166, 164, '_menu_item_type', 'taxonomy'),
(1167, 164, '_menu_item_menu_item_parent', '0'),
(1168, 164, '_menu_item_object_id', '42'),
(1169, 164, '_menu_item_object', 'category'),
(1170, 164, '_menu_item_target', ''),
(1171, 164, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1172, 164, '_menu_item_xfn', ''),
(1173, 164, '_menu_item_url', ''),
(1175, 165, '_menu_item_type', 'taxonomy'),
(1176, 165, '_menu_item_menu_item_parent', '0'),
(1177, 165, '_menu_item_object_id', '38'),
(1178, 165, '_menu_item_object', 'category'),
(1179, 165, '_menu_item_target', ''),
(1180, 165, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1181, 165, '_menu_item_xfn', ''),
(1182, 165, '_menu_item_url', ''),
(1184, 166, '_edit_last', '1'),
(1185, 166, '_edit_lock', '1516676519:1'),
(1186, 167, '_edit_last', '1'),
(1187, 167, '_edit_lock', '1516676520:1'),
(1188, 168, '_edit_last', '1'),
(1189, 168, '_edit_lock', '1516678946:1'),
(1190, 169, '_wp_attached_file', '2018/01/nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400.jpg'),
(1191, 169, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"file\";s:62:\"2018/01/nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:62:\"nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:62:\"nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:62:\"nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400-180x120.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:120;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:62:\"nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:62:\"nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1192, 170, '_wp_attached_file', '2018/01/tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban.jpg'),
(1193, 170, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"file\";s:62:\"2018/01/tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:62:\"tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:62:\"tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:62:\"tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban-180x120.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:120;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:62:\"tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:62:\"tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1194, 171, '_wp_attached_file', '2018/01/xuat-khau-lao-dong-dieu-duong.jpg'),
(1195, 171, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"file\";s:41:\"2018/01/xuat-khau-lao-dong-dieu-duong.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"xuat-khau-lao-dong-dieu-duong-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"xuat-khau-lao-dong-dieu-duong-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:41:\"xuat-khau-lao-dong-dieu-duong-180x120.jpg\";s:5:\"width\";i:180;s:6:\"height\";i:120;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:41:\"xuat-khau-lao-dong-dieu-duong-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:41:\"xuat-khau-lao-dong-dieu-duong-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1196, 166, '_thumbnail_id', '169'),
(1198, 166, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1199, 166, '_yoast_wpseo_content_score', '30'),
(1200, 166, '_yoast_wpseo_primary_category', '2'),
(1201, 167, '_thumbnail_id', '170'),
(1203, 167, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1204, 167, '_yoast_wpseo_content_score', '30'),
(1205, 167, '_yoast_wpseo_primary_category', '40'),
(1206, 168, '_thumbnail_id', '171'),
(1207, 168, '_encloseme', '1'),
(1208, 168, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1209, 168, '_yoast_wpseo_content_score', '30'),
(1210, 168, '_yoast_wpseo_primary_category', '40'),
(1211, 175, '_wp_attached_file', '2018/01/support.png'),
(1212, 175, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:235;s:6:\"height\";i:157;s:4:\"file\";s:19:\"2018/01/support.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"support-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"support-180x120.png\";s:5:\"width\";i:180;s:6:\"height\";i:120;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1227, 177, '_wp_attached_file', '2018/01/map.png'),
(1228, 177, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:307;s:6:\"height\";i:215;s:4:\"file\";s:15:\"2018/01/map.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"map-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"map-300x210.png\";s:5:\"width\";i:300;s:6:\"height\";i:210;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"map-180x126.png\";s:5:\"width\";i:180;s:6:\"height\";i:126;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"map-300x210.png\";s:5:\"width\";i:300;s:6:\"height\";i:210;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1229, 178, '_menu_item_type', 'post_type'),
(1230, 178, '_menu_item_menu_item_parent', '0'),
(1231, 178, '_menu_item_object_id', '147'),
(1232, 178, '_menu_item_object', 'page'),
(1233, 178, '_menu_item_target', ''),
(1234, 178, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1235, 178, '_menu_item_xfn', ''),
(1236, 178, '_menu_item_url', ''),
(1238, 179, '_menu_item_type', 'post_type'),
(1239, 179, '_menu_item_menu_item_parent', '0'),
(1240, 179, '_menu_item_object_id', '152'),
(1241, 179, '_menu_item_object', 'page'),
(1242, 179, '_menu_item_target', ''),
(1243, 179, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1244, 179, '_menu_item_xfn', ''),
(1245, 179, '_menu_item_url', ''),
(1247, 180, '_menu_item_type', 'post_type'),
(1248, 180, '_menu_item_menu_item_parent', '0'),
(1249, 180, '_menu_item_object_id', '154'),
(1250, 180, '_menu_item_object', 'page'),
(1251, 180, '_menu_item_target', ''),
(1252, 180, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1253, 180, '_menu_item_xfn', ''),
(1254, 180, '_menu_item_url', ''),
(1259, 116, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1260, 154, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1261, 138, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1262, 147, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1263, 140, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1264, 113, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1265, 145, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(1266, 188, '_wp_attached_file', '2018/01/icon1.png'),
(1267, 188, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:32;s:6:\"height\";i:32;s:4:\"file\";s:17:\"2018/01/icon1.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1268, 189, '_wp_attached_file', '2018/01/icon2.png'),
(1269, 189, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:32;s:6:\"height\";i:32;s:4:\"file\";s:17:\"2018/01/icon2.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1270, 190, '_wp_attached_file', '2018/01/icon3.png'),
(1271, 190, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:32;s:6:\"height\";i:32;s:4:\"file\";s:17:\"2018/01/icon3.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1272, 191, '_wp_attached_file', '2018/01/icon4.png'),
(1273, 191, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:32;s:6:\"height\";i:32;s:4:\"file\";s:17:\"2018/01/icon4.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1274, 192, '_wp_attached_file', '2018/01/icon5.png'),
(1275, 192, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:32;s:6:\"height\";i:32;s:4:\"file\";s:17:\"2018/01/icon5.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1276, 193, '_form', '<div class=\"form-thongtin\"><div class=\"left\">NHẬN THÔNG TIN MIỄN PHÍ</div><div class=\"right\">[email email-853 placeholder \"Nhập email của bạn...\"][submit \"Đăng ký\"]</div></div>'),
(1277, 193, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:25:\"RT - Aug \"[your-subject]\"\";s:6:\"sender\";s:44:\"[your-name] <wordpress@khomaudepraothue.com>\";s:9:\"recipient\";s:25:\"mailtrunggian01@gmail.com\";s:4:\"body\";s:216:\"NHẬN THÔNG TIN MIỄN PHÍ:[email-853]\n\nNội dung thông điệp:\n[your-message]\n\n-- \nEmail này được gửi đến từ form liên hệ của website RT - Aug (http://cuongrt.raothue.com/phong/anhduongtaybac)\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(1278, 193, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:25:\"RT - Aug \"[your-subject]\"\";s:6:\"sender\";s:40:\"RT - Aug <wordpress@cuongrt.raothue.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:173:\"Nội dung thông điệp:\n[your-message]\n\n-- \nEmail này được gửi đến từ form liên hệ của website RT - Aug (http://cuongrt.raothue.com/phong/anhduongtaybac)\";s:18:\"additional_headers\";s:35:\"Reply-To: mailtrunggian01@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(1279, 193, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:53:\"Xin cảm ơn, form đã được gửi thành công.\";s:12:\"mail_sent_ng\";s:118:\"Có lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\";s:16:\"validation_error\";s:86:\"Có một hoặc nhiều mục nhập có lỗi. Vui lòng kiểm tra và thử lại.\";s:4:\"spam\";s:118:\"Có lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\";s:12:\"accept_terms\";s:67:\"Bạn phải chấp nhận điều khoản trước khi gửi form.\";s:16:\"invalid_required\";s:28:\"Mục này là bắt buộc.\";s:16:\"invalid_too_long\";s:36:\"Nhập quá số kí tự cho phép.\";s:17:\"invalid_too_short\";s:44:\"Nhập ít hơn số kí tự tối thiểu.\";s:12:\"invalid_date\";s:46:\"Định dạng ngày tháng không hợp lệ.\";s:14:\"date_too_early\";s:58:\"Ngày này trước ngày sớm nhất được cho phép.\";s:13:\"date_too_late\";s:54:\"Ngày này quá ngày gần nhất được cho phép.\";s:13:\"upload_failed\";s:36:\"Tải file lên không thành công.\";s:24:\"upload_file_type_invalid\";s:69:\"Bạn không được phép tải lên file theo định dạng này.\";s:21:\"upload_file_too_large\";s:31:\"File kích thước quá lớn.\";s:23:\"upload_failed_php_error\";s:36:\"Tải file lên không thành công.\";s:14:\"invalid_number\";s:38:\"Định dạng số không hợp lệ.\";s:16:\"number_too_small\";s:48:\"Con số nhỏ hơn số nhỏ nhất cho phép.\";s:16:\"number_too_large\";s:48:\"Con số lớn hơn số lớn nhất cho phép.\";s:23:\"quiz_answer_not_correct\";s:30:\"Câu trả lời chưa đúng.\";s:17:\"captcha_not_match\";s:34:\"Bạn đã nhập sai mã CAPTCHA.\";s:13:\"invalid_email\";s:38:\"Địa chỉ e-mail không hợp lệ.\";s:11:\"invalid_url\";s:22:\"URL không hợp lệ.\";s:11:\"invalid_tel\";s:39:\"Số điện thoại không hợp lệ.\";}'),
(1280, 193, '_additional_settings', ''),
(1281, 193, '_locale', 'vi'),
(1284, 167, 'post_views_count', '26'),
(1285, 168, 'post_views_count', '53'),
(1286, 166, 'post_views_count', '26'),
(1292, 194, '_wp_attached_file', '2018/01/doitac1.png'),
(1293, 194, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:235;s:6:\"height\";i:48;s:4:\"file\";s:19:\"2018/01/doitac1.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac1-150x48.png\";s:5:\"width\";i:150;s:6:\"height\";i:48;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac1-180x37.png\";s:5:\"width\";i:180;s:6:\"height\";i:37;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1294, 195, '_wp_attached_file', '2018/01/doitac2.png'),
(1295, 195, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:235;s:6:\"height\";i:48;s:4:\"file\";s:19:\"2018/01/doitac2.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac2-150x48.png\";s:5:\"width\";i:150;s:6:\"height\";i:48;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac2-180x37.png\";s:5:\"width\";i:180;s:6:\"height\";i:37;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1296, 196, '_wp_attached_file', '2018/01/doitac3.png'),
(1297, 196, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:235;s:6:\"height\";i:48;s:4:\"file\";s:19:\"2018/01/doitac3.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac3-150x48.png\";s:5:\"width\";i:150;s:6:\"height\";i:48;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac3-180x37.png\";s:5:\"width\";i:180;s:6:\"height\";i:37;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1298, 197, '_wp_attached_file', '2018/01/doitac4.png'),
(1299, 197, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:235;s:6:\"height\";i:48;s:4:\"file\";s:19:\"2018/01/doitac4.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac4-150x48.png\";s:5:\"width\";i:150;s:6:\"height\";i:48;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac4-180x37.png\";s:5:\"width\";i:180;s:6:\"height\";i:37;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1300, 198, '_wp_attached_file', '2018/01/doitac5.png'),
(1301, 198, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:235;s:6:\"height\";i:52;s:4:\"file\";s:19:\"2018/01/doitac5.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac5-150x52.png\";s:5:\"width\";i:150;s:6:\"height\";i:52;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"doitac5-180x40.png\";s:5:\"width\";i:180;s:6:\"height\";i:40;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1302, 201, '_form', '<div class=\"form-dangky\">Giới tính (*):[text* text-915 akismet:author] Họ và tên của bạn (*):[text* text-129 akismet:author] Địa chỉ liên hệ (*):[text* text-224 akismet:author] Trình độ (*):[text* text-225 akismet:author] Điện thoại (*):[tel* tel-86] [submit \"Gửi\"]</div>'),
(1303, 201, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:79:\"Công ty Cổ Phần và Phát triển Ánh Dương Tây Bắc \"[your-subject]\"\";s:6:\"sender\";s:44:\"[your-name] <wordpress@khomaudepraothue.com>\";s:9:\"recipient\";s:25:\"mailtrunggian01@gmail.com\";s:4:\"body\";s:297:\"Gửi đến từ: [your-name] <[your-email]>\nTiêu đề: [your-subject]\n\nNội dung thông điệp:\n[your-message]\n\n-- \nEmail này được gửi đến từ form liên hệ của website Công ty Cổ Phần và Phát triển Ánh Dương Tây Bắc (http://khomaudepraothue.com/anhduongtaybac)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(1304, 201, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:79:\"Công ty Cổ Phần và Phát triển Ánh Dương Tây Bắc \"[your-subject]\"\";s:6:\"sender\";s:95:\"Công ty Cổ Phần và Phát triển Ánh Dương Tây Bắc <wordpress@khomaudepraothue.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:222:\"Nội dung thông điệp:\n[your-message]\n\n-- \nEmail này được gửi đến từ form liên hệ của website Công ty Cổ Phần và Phát triển Ánh Dương Tây Bắc (http://khomaudepraothue.com/anhduongtaybac)\";s:18:\"additional_headers\";s:35:\"Reply-To: mailtrunggian01@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(1305, 201, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:53:\"Xin cảm ơn, form đã được gửi thành công.\";s:12:\"mail_sent_ng\";s:118:\"Có lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\";s:16:\"validation_error\";s:86:\"Có một hoặc nhiều mục nhập có lỗi. Vui lòng kiểm tra và thử lại.\";s:4:\"spam\";s:118:\"Có lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\";s:12:\"accept_terms\";s:67:\"Bạn phải chấp nhận điều khoản trước khi gửi form.\";s:16:\"invalid_required\";s:28:\"Mục này là bắt buộc.\";s:16:\"invalid_too_long\";s:36:\"Nhập quá số kí tự cho phép.\";s:17:\"invalid_too_short\";s:44:\"Nhập ít hơn số kí tự tối thiểu.\";s:12:\"invalid_date\";s:46:\"Định dạng ngày tháng không hợp lệ.\";s:14:\"date_too_early\";s:58:\"Ngày này trước ngày sớm nhất được cho phép.\";s:13:\"date_too_late\";s:54:\"Ngày này quá ngày gần nhất được cho phép.\";s:13:\"upload_failed\";s:36:\"Tải file lên không thành công.\";s:24:\"upload_file_type_invalid\";s:69:\"Bạn không được phép tải lên file theo định dạng này.\";s:21:\"upload_file_too_large\";s:31:\"File kích thước quá lớn.\";s:23:\"upload_failed_php_error\";s:36:\"Tải file lên không thành công.\";s:14:\"invalid_number\";s:38:\"Định dạng số không hợp lệ.\";s:16:\"number_too_small\";s:48:\"Con số nhỏ hơn số nhỏ nhất cho phép.\";s:16:\"number_too_large\";s:48:\"Con số lớn hơn số lớn nhất cho phép.\";s:23:\"quiz_answer_not_correct\";s:30:\"Câu trả lời chưa đúng.\";s:17:\"captcha_not_match\";s:34:\"Bạn đã nhập sai mã CAPTCHA.\";s:13:\"invalid_email\";s:38:\"Địa chỉ e-mail không hợp lệ.\";s:11:\"invalid_url\";s:22:\"URL không hợp lệ.\";s:11:\"invalid_tel\";s:39:\"Số điện thoại không hợp lệ.\";}'),
(1306, 201, '_additional_settings', ''),
(1307, 201, '_locale', 'vi'),
(1311, 201, '_config_errors', 'a:1:{s:23:\"mail.additional_headers\";a:1:{i:0;a:2:{s:4:\"code\";i:102;s:4:\"args\";a:3:{s:7:\"message\";s:47:\"Cú pháp không hợp lệ trong mục %name%.\";s:6:\"params\";a:1:{s:4:\"name\";s:8:\"Reply-To\";}s:4:\"link\";s:68:\"https://contactform7.com/configuration-errors/invalid-mailbox-syntax\";}}}}');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_posts`
--

CREATE TABLE `rt_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_posts`
--

INSERT INTO `rt_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(2, 1, '2017-06-15 04:20:37', '2017-06-15 04:20:37', 'Đây là một trang mẫu. Nó khác với một bài blog bởi vì nó sẽ là một trang tĩnh và sẽ được thêm vào thanh menu của trang web của bạn (trong hầu hết theme). Mọi người thường bắt đầu bằng một trang Giới thiệu để giới thiệu bản thân đến người dùng tiềm năng. Bạn có thể viết như sau:\r\n<blockquote>Xin chào! Tôi là người giao thư bằng xe đạp vào ban ngày, một diễn viên đầy tham vọng vào ban đêm, và đây là trang web của tôi. Tôi sống ở Los Angeles, có một chú cho tuyệt vời tên là Jack, và tôi thích uống cocktail.</blockquote>\r\n...hay như thế này:\r\n<blockquote>Công ty XYZ Doohickey được thành lập vào năm 1971, và đã cung cấp đồ dùng chất lượng cho công chúng kể từ đó. Nằm ở thành phố Gotham, XYZ tạo việc làm cho hơn 2.000 người và làm tất cả những điều tuyệt vời cho cộng đồng Gotham.</blockquote>\r\nLà người dùng WordPress mới, bạn nên truy cập <a href=\"http://raothue.ddns.net/demo/rt-core/wp-admin/\">trang quản trị</a> để xóa trang này và tạo các trang mới cho nội dung của bạn. Chúc vui vẻ!', 'Trang Mẫu', '', 'publish', 'closed', 'open', '', 'trang-mau', '', '', '2017-06-15 04:22:29', '2017-06-15 04:22:29', '', 0, 'http://raothue.ddns.net/demo/rt-core/?page_id=2', 0, 'page', '', 0),
(5, 1, '2017-06-15 04:22:29', '2017-06-15 04:22:29', 'Đây là một trang mẫu. Nó khác với một bài blog bởi vì nó sẽ là một trang tĩnh và sẽ được thêm vào thanh menu của trang web của bạn (trong hầu hết theme). Mọi người thường bắt đầu bằng một trang Giới thiệu để giới thiệu bản thân đến người dùng tiềm năng. Bạn có thể viết như sau:\r\n<blockquote>Xin chào! Tôi là người giao thư bằng xe đạp vào ban ngày, một diễn viên đầy tham vọng vào ban đêm, và đây là trang web của tôi. Tôi sống ở Los Angeles, có một chú cho tuyệt vời tên là Jack, và tôi thích uống cocktail.</blockquote>\r\n...hay như thế này:\r\n<blockquote>Công ty XYZ Doohickey được thành lập vào năm 1971, và đã cung cấp đồ dùng chất lượng cho công chúng kể từ đó. Nằm ở thành phố Gotham, XYZ tạo việc làm cho hơn 2.000 người và làm tất cả những điều tuyệt vời cho cộng đồng Gotham.</blockquote>\r\nLà người dùng WordPress mới, bạn nên truy cập <a href=\"http://raothue.ddns.net/demo/rt-core/wp-admin/\">trang quản trị</a> để xóa trang này và tạo các trang mới cho nội dung của bạn. Chúc vui vẻ!', 'Trang Mẫu', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-06-15 04:22:29', '2017-06-15 04:22:29', '', 2, 'http://raothue.ddns.net/demo/rt-core/2-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2017-06-15 04:22:51', '2017-06-15 04:22:51', '<div class=\"form-lienhe\">\r\n<div class=\"box-colum-1\"><div class=\"left\"><label>Họ tên</label>[text text-545 placeholder \"Nhập họ và tên\"]</div><div class=\"right\"><label>Điện thoại</label>[number number-683 placeholder \"Nhập số điện thoại\"]</div></div>\r\n<div class=\"box-colum-2\"><label>Địa chỉ</label>[text text-546 placeholder \"Địa chỉ\"]</div>\r\n<div class=\"box-colum-3\"><label>Nội dung</label>[textarea textarea-444 placeholder \"Nhập nội dung liên hệ\"]</div>\r\n<div class=\"submits\">[submit \"Gửi liên hệ\"]</div>\r\n</div>\n1\nRT - Core \"[your-subject]\"\n[your-name] <wordpress@khomaudepraothue.com>\nphamtuan170291@gmail.com\nHọ tên:[text-545]\r\nĐiện thoại:[number-683]\r\nĐịa chỉ:[text-546]\r\nNội dung:[textarea-444]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on RT - Core (http://raothue.ddns.net/demo/rt-core)\n\n\n\n\n\nRT - Core \"[your-subject]\"\nRT - Core <wordpress@raothue.ddns.net>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on RT - Core (http://raothue.ddns.net/demo/rt-core)\nReply-To: phamtuan170291@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2018-02-28 14:53:48', '2018-02-28 07:53:48', '', 0, 'http://raothue.ddns.net/demo/rt-core/?post_type=wpcf7_contact_form&#038;p=6', 0, 'wpcf7_contact_form', '', 0),
(12, 1, '2017-06-15 04:28:56', '2017-06-15 04:28:56', '', 'Slide Home', '', 'publish', 'closed', 'closed', '', 'new-slider', '', '', '2018-01-22 23:03:33', '2018-01-22 16:03:33', '', 0, 'http://raothue.ddns.net/demo/rt-core/?post_type=ml-slider&#038;p=12', 0, 'ml-slider', '', 0),
(15, 1, '2017-06-15 06:35:55', '2017-06-15 06:35:55', '[contact-form-7 id=\"6\" title=\"Contact form 1\"]', 'Liên hệ', '', 'publish', 'closed', 'closed', '', 'lien-he', '', '', '2017-06-15 06:35:55', '2017-06-15 06:35:55', '', 0, 'http://raothue.ddns.net/demo/rt-core/?page_id=15', 0, 'page', '', 0),
(16, 1, '2017-06-15 06:35:55', '2017-06-15 06:35:55', '[contact-form-7 id=\"6\" title=\"Contact form 1\"]', 'Liên hệ', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2017-06-15 06:35:55', '2017-06-15 06:35:55', '', 15, 'http://raothue.ddns.net/demo/rt-core/15-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2017-06-15 06:36:40', '2017-06-15 06:36:40', ' ', '', '', 'publish', 'closed', 'closed', '', '19', '', '', '2018-02-23 15:58:29', '2018-02-23 08:58:29', '', 0, 'http://raothue.ddns.net/demo/rt-core/?p=19', 8, 'nav_menu_item', '', 0),
(21, 1, '2017-06-15 06:36:40', '2017-06-15 06:36:40', ' ', '', '', 'publish', 'closed', 'closed', '', '21', '', '', '2018-02-23 15:58:29', '2018-02-23 08:58:29', '', 0, 'http://raothue.ddns.net/demo/rt-core/?p=21', 5, 'nav_menu_item', '', 0),
(53, 1, '2017-06-15 07:30:00', '2017-06-15 07:30:00', '', 'Slider 12 - image', '', 'publish', 'closed', 'closed', '', 'slider-12-image', '', '', '2017-07-04 08:41:00', '2017-07-04 08:41:00', '', 0, 'http://raothue.ddns.net/demo/rt-core/?post_type=ml-slide&#038;p=53', 0, 'ml-slide', '', 0),
(60, 1, '2017-07-04 07:08:35', '2017-07-04 07:08:35', '', 'Sub 2', '', 'publish', 'closed', 'closed', '', 'sub-2', '', '', '2018-01-23 09:41:33', '2018-01-23 02:41:33', '', 0, 'http://localhost/RT/?p=60', 4, 'nav_menu_item', '', 0),
(61, 1, '2017-07-04 07:08:36', '2017-07-04 07:08:36', '', 'Sub 3', '', 'publish', 'closed', 'closed', '', 'sub-3', '', '', '2018-01-23 09:41:32', '2018-01-23 02:41:32', '', 0, 'http://localhost/RT/?p=61', 3, 'nav_menu_item', '', 0),
(74, 1, '2017-09-05 14:16:27', '2017-09-05 07:16:27', '', '1', '', 'inherit', 'open', 'closed', '', '1', '', '', '2017-09-05 14:16:27', '2017-09-05 07:16:27', '', 0, 'http://localhost/RT-Aug/wp-content/uploads/2017/09/1.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2017-09-05 14:16:29', '2017-09-05 07:16:29', '', '2', '', 'inherit', 'open', 'closed', '', '2', '', '', '2017-09-05 14:16:29', '2017-09-05 07:16:29', '', 0, 'http://localhost/RT-Aug/wp-content/uploads/2017/09/2.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2017-09-05 14:16:31', '2017-09-05 07:16:31', '', '3', '', 'inherit', 'open', 'closed', '', '3', '', '', '2017-09-05 14:16:31', '2017-09-05 07:16:31', '', 0, 'http://localhost/RT-Aug/wp-content/uploads/2017/09/3.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2017-09-05 14:16:33', '2017-09-05 07:16:33', '', '4', '', 'inherit', 'open', 'closed', '', '4', '', '', '2017-09-05 14:16:33', '2017-09-05 07:16:33', '', 0, 'http://localhost/RT-Aug/wp-content/uploads/2017/09/4.jpg', 0, 'attachment', 'image/jpeg', 0),
(78, 1, '2017-09-05 14:16:35', '2017-09-05 07:16:35', '', '5', '', 'inherit', 'open', 'closed', '', '5', '', '', '2017-09-05 14:16:35', '2017-09-05 07:16:35', '', 0, 'http://localhost/RT-Aug/wp-content/uploads/2017/09/5.jpg', 0, 'attachment', 'image/jpeg', 0),
(79, 1, '2017-09-05 14:16:37', '2017-09-05 07:16:37', '', '6', '', 'inherit', 'open', 'closed', '', '6', '', '', '2017-09-05 14:16:37', '2017-09-05 07:16:37', '', 0, 'http://localhost/RT-Aug/wp-content/uploads/2017/09/6.jpg', 0, 'attachment', 'image/jpeg', 0),
(80, 1, '2017-09-05 14:16:39', '2017-09-05 07:16:39', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2017-09-05 14:16:39', '2017-09-05 07:16:39', '', 0, 'http://localhost/RT-Aug/wp-content/uploads/2017/09/logo.png', 0, 'attachment', 'image/png', 0),
(81, 1, '2017-09-05 14:19:06', '2017-09-05 07:19:06', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'publish', 'open', 'open', '', 'iran-tuyen-bo-da-duoi-may-bay-tham-u2-cua', '', '', '2017-09-05 14:19:06', '2017-09-05 07:19:06', '', 0, 'http://localhost/RT-Aug/?p=81', 0, 'post', '', 0),
(82, 1, '2017-09-05 14:19:06', '2017-09-05 07:19:06', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2017-09-05 14:19:06', '2017-09-05 07:19:06', '', 81, 'http://localhost/RT-Aug/81-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2017-09-05 14:19:30', '2017-09-05 07:19:30', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'publish', 'open', 'open', '', 'iran-tuyen-bo-da-duoi-may-bay-tham-u2-cua-2', '', '', '2017-09-05 14:19:30', '2017-09-05 07:19:30', '', 0, 'http://localhost/RT-Aug/?p=83', 0, 'post', '', 0),
(84, 1, '2017-09-05 14:19:30', '2017-09-05 07:19:30', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2017-09-05 14:19:30', '2017-09-05 07:19:30', '', 83, 'http://localhost/RT-Aug/83-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2017-09-05 14:20:07', '2017-09-05 07:20:07', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'publish', 'open', 'open', '', 'iran-tuyen-bo-da-duoi-may-bay-tham-u2-cua-3', '', '', '2017-09-05 14:20:07', '2017-09-05 07:20:07', '', 0, 'http://localhost/RT-Aug/?p=85', 0, 'post', '', 0),
(86, 1, '2017-09-05 14:20:07', '2017-09-05 07:20:07', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2017-09-05 14:20:07', '2017-09-05 07:20:07', '', 85, 'http://localhost/RT-Aug/85-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2017-09-05 14:20:29', '2017-09-05 07:20:29', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'publish', 'open', 'open', '', 'iran-tuyen-bo-da-duoi-may-bay-tham-u2-cua-4', '', '', '2017-09-05 14:20:29', '2017-09-05 07:20:29', '', 0, 'http://localhost/RT-Aug/?p=87', 0, 'post', '', 0),
(88, 1, '2017-09-05 14:20:29', '2017-09-05 07:20:29', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-09-05 14:20:29', '2017-09-05 07:20:29', '', 87, 'http://localhost/RT-Aug/87-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2017-09-05 14:20:51', '2017-09-05 07:20:51', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'publish', 'open', 'open', '', 'iran-tuyen-bo-da-duoi-may-bay-tham-u2-cua-5', '', '', '2017-09-05 14:20:51', '2017-09-05 07:20:51', '', 0, 'http://localhost/RT-Aug/?p=89', 0, 'post', '', 0),
(90, 1, '2017-09-05 14:20:51', '2017-09-05 07:20:51', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2017-09-05 14:20:51', '2017-09-05 07:20:51', '', 89, 'http://localhost/RT-Aug/89-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2017-09-05 14:21:12', '2017-09-05 07:21:12', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'publish', 'open', 'open', '', 'iran-tuyen-bo-da-duoi-may-bay-tham-u2-cua-6', '', '', '2017-09-05 14:21:12', '2017-09-05 07:21:12', '', 0, 'http://localhost/RT-Aug/?p=91', 0, 'post', '', 0),
(92, 1, '2017-09-05 14:21:12', '2017-09-05 07:21:12', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2017-09-05 14:21:12', '2017-09-05 07:21:12', '', 91, 'http://localhost/RT-Aug/91-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2017-09-05 14:21:34', '2017-09-05 07:21:34', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'publish', 'open', 'open', '', 'iran-tuyen-bo-da-duoi-may-bay-tham-u2-cua-7', '', '', '2017-09-05 14:21:34', '2017-09-05 07:21:34', '', 0, 'http://localhost/RT-Aug/?p=93', 0, 'post', '', 0),
(94, 1, '2017-09-05 14:21:34', '2017-09-05 07:21:34', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2017-09-05 14:21:34', '2017-09-05 07:21:34', '', 93, 'http://localhost/RT-Aug/93-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2017-09-05 14:22:01', '2017-09-05 07:22:01', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'publish', 'open', 'open', '', 'iran-tuyen-bo-da-duoi-may-bay-tham-u2-cua-8', '', '', '2017-09-05 14:22:01', '2017-09-05 07:22:01', '', 0, 'http://localhost/RT-Aug/?p=95', 0, 'post', '', 0),
(96, 1, '2017-09-05 14:22:01', '2017-09-05 07:22:01', 'Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).\r\n\r\nChúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu \"Nội dung, nội dung, nội dung\" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn \"Lorem ipsum\" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).', 'Iran tuyên bố đã đuổi máy bay do thám U2 của Mỹ', '', 'inherit', 'closed', 'closed', '', '95-revision-v1', '', '', '2017-09-05 14:22:01', '2017-09-05 07:22:01', '', 95, 'http://localhost/RT-Aug/95-revision-v1/', 0, 'revision', '', 0),
(99, 1, '2017-09-05 14:34:55', '2017-09-05 07:34:55', 'Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.\r\n\r\nSed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.', 'Tranh vẽ tường khổ lớn D01', '', 'publish', 'open', 'closed', '', 'tranh-ve-tuong-kho-lon-d01', '', '', '2017-09-05 14:34:57', '2017-09-05 07:34:57', '', 0, 'http://localhost/RT-Aug/?post_type=product&#038;p=99', 0, 'product', '', 0);
INSERT INTO `rt_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(100, 1, '2017-09-05 14:35:15', '2017-09-05 07:35:15', 'Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.\r\n\r\nSed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.', 'Tranh vẽ tường khổ lớn D02', '', 'publish', 'open', 'closed', '', 'tranh-ve-tuong-kho-lon-d02', '', '', '2017-09-05 14:35:33', '2017-09-05 07:35:33', '', 0, 'http://localhost/RT-Aug/?post_type=product&#038;p=100', 0, 'product', '', 0),
(101, 1, '2017-09-05 14:35:43', '2017-09-05 07:35:43', 'Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.\r\n\r\nSed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.', 'Tranh vẽ tường khổ lớn D03', '', 'publish', 'open', 'closed', '', 'tranh-ve-tuong-kho-lon-d03', '', '', '2017-09-05 14:36:11', '2017-09-05 07:36:11', '', 0, 'http://localhost/RT-Aug/?post_type=product&#038;p=101', 0, 'product', '', 0),
(102, 1, '2017-09-05 14:36:18', '2017-09-05 07:36:18', 'Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.\r\n\r\nSed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.', 'Tranh vẽ tường khổ lớn D04', '', 'publish', 'open', 'closed', '', 'tranh-ve-tuong-kho-lon-d04', '', '', '2017-09-05 14:36:35', '2017-09-05 07:36:35', '', 0, 'http://localhost/RT-Aug/?post_type=product&#038;p=102', 0, 'product', '', 0),
(103, 1, '2017-09-05 14:36:42', '2017-09-05 07:36:42', 'Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.\r\n\r\nSed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.', 'Tranh vẽ tường khổ lớn D05', '', 'publish', 'open', 'closed', '', 'tranh-ve-tuong-kho-lon-d02-ban-sao', '', '', '2017-09-05 14:37:27', '2017-09-05 07:37:27', '', 0, 'http://localhost/RT-Aug/?post_type=product&#038;p=103', 0, 'product', '', 0),
(104, 1, '2017-09-05 14:37:36', '2017-09-05 07:37:36', 'Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.\r\n\r\nSed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Nulla quis lorem ut libero malesuada feugiat.\r\n\r\nDonec rutrum congue leo eget malesuada. Curabitur aliquet quam id dui posuere blandit. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.', 'Tranh vẽ tường khổ lớn D06', 'Sed porttitor lectus nibh. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Nulla quis lorem ut libero malesuada feugiat. Nulla quis lorem ut libero malesuada feugiat. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Praesent sapien massa, convallis a pellentesque nec', 'publish', 'open', 'closed', '', 'tranh-ve-tuong-kho-lon-d06', '', '', '2017-12-11 16:58:32', '2017-12-11 09:58:32', '', 0, 'http://localhost/RT-Aug/?post_type=product&#038;p=104', 0, 'product', '', 1),
(105, 1, '2017-09-05 15:58:57', '2017-09-05 08:58:57', '', 'Slider 12 - image', '', 'publish', 'closed', 'closed', '', 'slider-12-image-2', '', '', '2018-01-22 23:03:33', '2018-01-22 16:03:33', '', 0, 'http://localhost/RT-Aug/?post_type=ml-slide&#038;p=105', 0, 'ml-slide', '', 0),
(107, 1, '2017-09-05 16:10:43', '2017-09-05 09:10:43', ' ', '', '', 'publish', 'closed', 'closed', '', '107', '', '', '2018-02-23 15:58:29', '2018-02-23 08:58:29', '', 0, 'http://localhost/RT-Aug/?p=107', 6, 'nav_menu_item', '', 0),
(110, 1, '2017-09-05 17:22:12', '2017-09-05 10:22:12', '', 'Trang chủ', '', 'publish', 'closed', 'closed', '', 'trang-chu', '', '', '2018-02-23 15:58:29', '2018-02-23 08:58:29', '', 0, 'http://raothue.ddns.net/demo/RT-Aug/?p=110', 1, 'nav_menu_item', '', 0),
(113, 1, '2017-09-17 23:02:53', '2017-09-17 16:02:53', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Về chúng tôi', '', 'publish', 'closed', 'closed', '', 've-chung-toi', '', '', '2018-01-23 10:45:22', '2018-01-23 03:45:22', '', 0, 'http://localhost/code-toiuu/?page_id=113', 0, 'page', '', 0),
(116, 1, '2017-09-17 23:03:16', '2017-09-17 16:03:16', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Cam kết dịch vụ', '', 'publish', 'closed', 'closed', '', 'cam-ket-dich-vu', '', '', '2018-01-23 10:44:54', '2018-01-23 03:44:54', '', 0, 'http://localhost/code-toiuu/?page_id=116', 0, 'page', '', 0),
(117, 1, '2017-09-17 23:02:53', '2017-09-17 16:02:53', '', 'Về chúng tôi', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2017-09-17 23:02:53', '2017-09-17 16:02:53', '', 113, 'http://localhost/code-toiuu/113-revision-v1/', 0, 'revision', '', 0),
(120, 1, '2017-09-17 23:03:16', '2017-09-17 16:03:16', '', 'Cam kết dịch vụ', '', 'inherit', 'closed', 'closed', '', '116-revision-v1', '', '', '2017-09-17 23:03:16', '2017-09-17 16:03:16', '', 116, 'http://localhost/code-toiuu/116-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2017-09-17 23:04:02', '2017-09-17 16:04:02', ' ', '', '', 'publish', 'closed', 'closed', '', '124', '', '', '2018-01-23 10:43:35', '2018-01-23 03:43:35', '', 0, 'http://localhost/code-toiuu/?p=124', 5, 'nav_menu_item', '', 0),
(127, 1, '2017-09-17 23:04:02', '2017-09-17 16:04:02', ' ', '', '', 'publish', 'closed', 'closed', '', '127', '', '', '2018-01-23 10:43:35', '2018-01-23 03:43:35', '', 0, 'http://localhost/code-toiuu/?p=127', 1, 'nav_menu_item', '', 0),
(128, 1, '2017-09-17 23:04:03', '2017-09-17 16:04:03', ' ', '', '', 'publish', 'closed', 'closed', '', '128', '', '', '2018-01-23 10:43:35', '2018-01-23 03:43:35', '', 0, 'http://localhost/code-toiuu/?p=128', 6, 'nav_menu_item', '', 0),
(129, 1, '2017-09-17 23:09:50', '2017-09-17 16:09:50', '', 'map', '', 'inherit', 'open', 'closed', '', 'map', '', '', '2017-09-17 23:09:50', '2017-09-17 16:09:50', '', 0, 'http://localhost/code-toiuu/wp-content/uploads/2017/09/map.png', 0, 'attachment', 'image/png', 0),
(131, 1, '2017-12-10 20:55:07', '2017-12-10 13:55:07', '', '2', '', 'inherit', 'open', 'closed', '', '2-2', '', '', '2017-12-10 20:55:07', '2017-12-10 13:55:07', '', 0, 'http://localhost/code-toiuu/wp-content/uploads/2017/12/2.jpg', 0, 'attachment', 'image/jpeg', 0),
(133, 1, '2018-01-22 16:52:49', '2018-01-22 09:52:49', '', 'banner', '', 'inherit', 'open', 'closed', '', 'banner', '', '', '2018-01-22 16:52:49', '2018-01-22 09:52:49', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/banner.png', 0, 'attachment', 'image/png', 0),
(134, 1, '2018-01-22 16:57:16', '2018-01-22 09:57:16', '', 'slider1', '', 'inherit', 'open', 'closed', '', 'slider1', '', '', '2018-01-22 16:57:16', '2018-01-22 09:57:16', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/slider1.png', 0, 'attachment', 'image/png', 0),
(135, 1, '2018-01-22 16:57:36', '2018-01-22 09:57:36', '', 'slider2', '', 'inherit', 'open', 'closed', '', 'slider2', '', '', '2018-01-22 16:57:36', '2018-01-22 09:57:36', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/slider2.png', 0, 'attachment', 'image/png', 0),
(136, 1, '2018-01-22 16:57:40', '2018-01-22 09:57:40', '', 'Slider 12 - image', '', 'publish', 'closed', 'closed', '', 'slider-12-image-3', '', '', '2018-01-22 23:03:33', '2018-01-22 16:03:33', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?post_type=ml-slide&#038;p=136', 1, 'ml-slide', '', 0),
(138, 1, '2018-01-22 17:15:40', '2018-01-22 10:15:40', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Giới thiệu', '', 'publish', 'closed', 'closed', '', 'gioi-thieu', '', '', '2018-01-23 10:45:09', '2018-01-23 03:45:09', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?page_id=138', 0, 'page', '', 0),
(139, 1, '2018-01-22 17:15:40', '2018-01-22 10:15:40', '', 'Giới thiệu', '', 'inherit', 'closed', 'closed', '', '138-revision-v1', '', '', '2018-01-22 17:15:40', '2018-01-22 10:15:40', '', 138, 'http://cuongrt.raothue.com/phong/anhduongtaybac/138-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2018-01-22 17:16:22', '2018-01-22 10:16:22', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Thị trường XKLĐ', '', 'publish', 'closed', 'closed', '', 'thi-truong-xkld', '', '', '2018-01-23 10:45:32', '2018-01-23 03:45:32', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?page_id=140', 0, 'page', '', 0),
(141, 1, '2018-01-22 17:16:22', '2018-01-22 10:16:22', '', 'Thi trường XKLĐ', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2018-01-22 17:16:22', '2018-01-22 10:16:22', '', 140, 'http://cuongrt.raothue.com/phong/anhduongtaybac/140-revision-v1/', 0, 'revision', '', 0),
(142, 1, '2018-01-22 17:16:32', '2018-01-22 10:16:32', '', 'Thị trường XKLĐ', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2018-01-22 17:16:32', '2018-01-22 10:16:32', '', 140, 'http://cuongrt.raothue.com/phong/anhduongtaybac/140-revision-v1/', 0, 'revision', '', 0),
(145, 1, '2018-01-22 17:17:12', '2018-01-22 10:17:12', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Tuyển dụng', '', 'publish', 'closed', 'closed', '', 'tuyen-dung', '', '', '2018-01-23 10:45:28', '2018-01-23 03:45:28', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?page_id=145', 0, 'page', '', 0),
(146, 1, '2018-01-22 17:17:12', '2018-01-22 10:17:12', '', 'Tuyển dụng', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2018-01-22 17:17:12', '2018-01-22 10:17:12', '', 145, 'http://cuongrt.raothue.com/phong/anhduongtaybac/145-revision-v1/', 0, 'revision', '', 0),
(147, 1, '2018-01-22 17:18:35', '2018-01-22 10:18:35', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Hướng dẫn đăng ký', '', 'publish', 'closed', 'closed', '', 'huong-dan-dang-ky', '', '', '2018-01-23 10:45:14', '2018-01-23 03:45:14', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?page_id=147', 0, 'page', '', 0),
(151, 1, '2018-01-22 17:18:35', '2018-01-22 10:18:35', '', 'Hướng dẫn đăng ký', '', 'inherit', 'closed', 'closed', '', '147-revision-v1', '', '', '2018-01-22 17:18:35', '2018-01-22 10:18:35', '', 147, 'http://cuongrt.raothue.com/phong/anhduongtaybac/147-revision-v1/', 0, 'revision', '', 0),
(152, 1, '2018-01-22 17:18:55', '2018-01-22 10:18:55', '', 'Đơn hàng mới nhất', '', 'publish', 'closed', 'closed', '', 'don-hang-moi-nhat', '', '', '2018-01-22 17:18:55', '2018-01-22 10:18:55', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?page_id=152', 0, 'page', '', 0),
(153, 1, '2018-01-22 17:18:55', '2018-01-22 10:18:55', '', 'Đơn hàng mới nhất', '', 'inherit', 'closed', 'closed', '', '152-revision-v1', '', '', '2018-01-22 17:18:55', '2018-01-22 10:18:55', '', 152, 'http://cuongrt.raothue.com/phong/anhduongtaybac/152-revision-v1/', 0, 'revision', '', 0),
(154, 1, '2018-01-22 17:19:14', '2018-01-22 10:19:14', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Chính sách bảo mật', '', 'publish', 'closed', 'closed', '', 'chinh-sach-bao-mat', '', '', '2018-01-23 10:44:58', '2018-01-23 03:44:58', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?page_id=154', 0, 'page', '', 0),
(155, 1, '2018-01-22 17:19:14', '2018-01-22 10:19:14', '', 'Chính sách bảo mật', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2018-01-22 17:19:14', '2018-01-22 10:19:14', '', 154, 'http://cuongrt.raothue.com/phong/anhduongtaybac/154-revision-v1/', 0, 'revision', '', 0),
(156, 1, '2018-01-22 17:22:15', '2018-01-22 10:22:15', ' ', '', '', 'publish', 'closed', 'closed', '', '156', '', '', '2018-02-23 15:58:29', '2018-02-23 08:58:29', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=156', 2, 'nav_menu_item', '', 0),
(157, 1, '2018-01-22 17:22:15', '2018-01-22 10:22:15', ' ', '', '', 'publish', 'closed', 'closed', '', '157', '', '', '2018-02-23 15:58:29', '2018-02-23 08:58:29', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=157', 3, 'nav_menu_item', '', 0),
(159, 1, '2018-01-22 17:22:15', '2018-01-22 10:22:15', '', 'Tin tức & sự kiện', '', 'publish', 'closed', 'closed', '', 'tin-tuc-su-kien', '', '', '2018-02-23 15:58:29', '2018-02-23 08:58:29', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=159', 4, 'nav_menu_item', '', 0),
(160, 1, '2018-01-22 17:22:15', '2018-01-22 10:22:15', ' ', '', '', 'publish', 'closed', 'closed', '', '160', '', '', '2018-02-23 15:58:29', '2018-02-23 08:58:29', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=160', 7, 'nav_menu_item', '', 0),
(161, 1, '2018-01-23 09:41:33', '2018-01-23 02:41:33', ' ', '', '', 'publish', 'closed', 'closed', '', '161', '', '', '2018-01-23 09:41:33', '2018-01-23 02:41:33', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=161', 5, 'nav_menu_item', '', 0),
(162, 1, '2018-01-23 09:41:33', '2018-01-23 02:41:33', ' ', '', '', 'publish', 'closed', 'closed', '', '162', '', '', '2018-01-23 09:41:33', '2018-01-23 02:41:33', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=162', 6, 'nav_menu_item', '', 0),
(163, 1, '2018-01-23 09:41:32', '2018-01-23 02:41:32', ' ', '', '', 'publish', 'closed', 'closed', '', '163', '', '', '2018-01-23 09:41:32', '2018-01-23 02:41:32', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=163', 2, 'nav_menu_item', '', 0),
(164, 1, '2018-01-23 09:41:33', '2018-01-23 02:41:33', ' ', '', '', 'publish', 'closed', 'closed', '', '164', '', '', '2018-01-23 09:41:33', '2018-01-23 02:41:33', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=164', 7, 'nav_menu_item', '', 0),
(165, 1, '2018-01-23 09:41:32', '2018-01-23 02:41:32', ' ', '', '', 'publish', 'closed', 'closed', '', '165', '', '', '2018-01-23 09:41:32', '2018-01-23 02:41:32', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=165', 1, 'nav_menu_item', '', 0),
(166, 1, '2018-01-23 10:02:58', '2018-01-23 03:02:58', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Đơn hàng điều dưỡng tại Nhật Bản', 'Đơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.', 'publish', 'open', 'open', '', 'don-hang-dieu-duong-tai-nhat-ban', '', '', '2018-01-23 10:02:58', '2018-01-23 03:02:58', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=166', 0, 'post', '', 0),
(167, 1, '2018-01-23 10:03:01', '2018-01-23 03:03:01', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Các loại visa Hàn Quốc bạn nên biết?', 'Đơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.', 'publish', 'open', 'open', '', 'cac-loai-visa-han-quoc-ban-nen-biet', '', '', '2018-01-23 10:03:01', '2018-01-23 03:03:01', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=167', 0, 'post', '', 0),
(168, 1, '2018-01-23 10:03:06', '2018-01-23 03:03:06', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Đơn hàng lao động Cộng Hòa Séc.', 'Đơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.', 'publish', 'open', 'open', '', 'don-hang-lao-dong-cong-hoa-sec', '', '', '2018-01-23 10:03:06', '2018-01-23 03:03:06', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=168', 0, 'post', '', 0),
(169, 1, '2018-01-23 10:02:37', '2018-01-23 03:02:37', '', 'nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400', '', 'inherit', 'open', 'closed', '', 'nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400', '', '', '2018-01-23 10:02:37', '2018-01-23 03:02:37', '', 166, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/nghe-dau-bep-nghe-cua-nguoi-tho-chan-chinh-600x400.jpg', 0, 'attachment', 'image/jpeg', 0),
(170, 1, '2018-01-23 10:02:45', '2018-01-23 03:02:45', '', 'tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban', '', 'inherit', 'open', 'closed', '', 'tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban', '', '', '2018-01-23 10:02:45', '2018-01-23 03:02:45', '', 167, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/tuyen-dieu-duong-ho-ly-xuat-khau-lao-dong-nhat-ban.jpg', 0, 'attachment', 'image/jpeg', 0),
(171, 1, '2018-01-23 10:02:52', '2018-01-23 03:02:52', '', 'xuat-khau-lao-dong-dieu-duong', '', 'inherit', 'open', 'closed', '', 'xuat-khau-lao-dong-dieu-duong', '', '', '2018-01-23 10:02:52', '2018-01-23 03:02:52', '', 168, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/xuat-khau-lao-dong-dieu-duong.jpg', 0, 'attachment', 'image/jpeg', 0),
(172, 1, '2018-01-23 10:02:58', '2018-01-23 03:02:58', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Đơn hàng điều dưỡng tại Nhật Bản', 'Đơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.', 'inherit', 'closed', 'closed', '', '166-revision-v1', '', '', '2018-01-23 10:02:58', '2018-01-23 03:02:58', '', 166, 'http://cuongrt.raothue.com/phong/anhduongtaybac/166-revision-v1/', 0, 'revision', '', 0),
(173, 1, '2018-01-23 10:03:01', '2018-01-23 03:03:01', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Các loại visa Hàn Quốc bạn nên biết?', 'Đơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.', 'inherit', 'closed', 'closed', '', '167-revision-v1', '', '', '2018-01-23 10:03:01', '2018-01-23 03:03:01', '', 167, 'http://cuongrt.raothue.com/phong/anhduongtaybac/167-revision-v1/', 0, 'revision', '', 0),
(174, 1, '2018-01-23 10:03:06', '2018-01-23 03:03:06', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Đơn hàng lao động Cộng Hòa Séc.', 'Đơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.', 'inherit', 'closed', 'closed', '', '168-revision-v1', '', '', '2018-01-23 10:03:06', '2018-01-23 03:03:06', '', 168, 'http://cuongrt.raothue.com/phong/anhduongtaybac/168-revision-v1/', 0, 'revision', '', 0),
(175, 1, '2018-01-23 10:08:10', '2018-01-23 03:08:10', '', 'support', '', 'inherit', 'open', 'closed', '', 'support', '', '', '2018-01-23 10:08:10', '2018-01-23 03:08:10', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/support.png', 0, 'attachment', 'image/png', 0),
(177, 1, '2018-01-23 10:41:37', '2018-01-23 03:41:37', '', 'map', '', 'inherit', 'open', 'closed', '', 'map-2', '', '', '2018-01-23 10:41:37', '2018-01-23 03:41:37', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/map.png', 0, 'attachment', 'image/png', 0),
(178, 1, '2018-01-23 10:43:35', '2018-01-23 03:43:35', ' ', '', '', 'publish', 'closed', 'closed', '', '178', '', '', '2018-01-23 10:43:35', '2018-01-23 03:43:35', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=178', 2, 'nav_menu_item', '', 0),
(179, 1, '2018-01-23 10:43:35', '2018-01-23 03:43:35', ' ', '', '', 'publish', 'closed', 'closed', '', '179', '', '', '2018-01-23 10:43:35', '2018-01-23 03:43:35', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=179', 3, 'nav_menu_item', '', 0),
(180, 1, '2018-01-23 10:43:35', '2018-01-23 03:43:35', ' ', '', '', 'publish', 'closed', 'closed', '', '180', '', '', '2018-01-23 10:43:35', '2018-01-23 03:43:35', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?p=180', 4, 'nav_menu_item', '', 0),
(181, 1, '2018-01-23 10:44:54', '2018-01-23 03:44:54', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Cam kết dịch vụ', '', 'inherit', 'closed', 'closed', '', '116-revision-v1', '', '', '2018-01-23 10:44:54', '2018-01-23 03:44:54', '', 116, 'http://cuongrt.raothue.com/phong/anhduongtaybac/116-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `rt_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(182, 1, '2018-01-23 10:44:58', '2018-01-23 03:44:58', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Chính sách bảo mật', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2018-01-23 10:44:58', '2018-01-23 03:44:58', '', 154, 'http://cuongrt.raothue.com/phong/anhduongtaybac/154-revision-v1/', 0, 'revision', '', 0),
(183, 1, '2018-01-23 10:45:09', '2018-01-23 03:45:09', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Giới thiệu', '', 'inherit', 'closed', 'closed', '', '138-revision-v1', '', '', '2018-01-23 10:45:09', '2018-01-23 03:45:09', '', 138, 'http://cuongrt.raothue.com/phong/anhduongtaybac/138-revision-v1/', 0, 'revision', '', 0),
(184, 1, '2018-01-23 10:45:14', '2018-01-23 03:45:14', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Hướng dẫn đăng ký', '', 'inherit', 'closed', 'closed', '', '147-revision-v1', '', '', '2018-01-23 10:45:14', '2018-01-23 03:45:14', '', 147, 'http://cuongrt.raothue.com/phong/anhduongtaybac/147-revision-v1/', 0, 'revision', '', 0),
(185, 1, '2018-01-23 10:45:18', '2018-01-23 03:45:18', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Thị trường XKLĐ', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2018-01-23 10:45:18', '2018-01-23 03:45:18', '', 140, 'http://cuongrt.raothue.com/phong/anhduongtaybac/140-revision-v1/', 0, 'revision', '', 0),
(186, 1, '2018-01-23 10:45:22', '2018-01-23 03:45:22', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Về chúng tôi', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2018-01-23 10:45:22', '2018-01-23 03:45:22', '', 113, 'http://cuongrt.raothue.com/phong/anhduongtaybac/113-revision-v1/', 0, 'revision', '', 0),
(187, 1, '2018-01-23 10:45:28', '2018-01-23 03:45:28', 'Theo nhận định của các chuyên gia đầu ngành trong làng xuất khẩu lao động Nhật Bản thì năm 2017 làm năm bùng nổ của các đơn hàng. Năm trước các đơn hàng tuyển lao động đi Nhật đã rất nhiều, nhưng năm nay còn về nhiều hơn và với tốc độ tăng trưởng cao gấp 1,8 lần năm 2016. Đây là cơ hội rất lớn để các bạn lao động Việt có nhu cầu đi Nhật Bản làm việc kiếm tiền nên tranh thủ ngay. Chúng tôi sẽ phân tích cụ thể cho các bạn thấy tất cả các khía cạnh về đơn hàng đi lao động Nhật.\r\n\r\nTrong tình hình Olympic 2020 đang đến gần, các ngành dịch vụ tổng hợp, xây dựng, cơ khí… đều đang phát triển đồng đều. Nhu cầu tuyển dụng lao động cho các ngành này đã tăng 30% so với cùng kỳ năm ngoái. Làm cho số lượng thực tập sinh xuất cảnh trong 6 tháng đầu năm 2017 đã vượt chỉ tiêu. Các công xưởng ở Nhật Bản đang cạnh tranh nhau khốc liệt để có được nguồn lao động dồi dào đáp ứng nhu cầu sản xuất trong nước. Sự việc này kéo theo lương của lao động cũng tăng mạnh. Lương cơ bản 2017 so với năm trước đã tăng lên 30yên/h, vậy 1 tháng nếu làm chăm chỉ các bạn có thể nhận thu nhập 40tr/tháng là bình thường.\r\n\r\nĐơn hàng nào sẽ có mức lương trả cao nhất trong những năm tới? Câu hỏi này chắc hẳn ai cũng muốn đi tìm câu trả lời để lựa chọn cho mình một đơn hàng tốt nhất.\r\n\r\nTheo nhận định trên của các chuyên gia, nếu bạn muốn lựa chọn ngành nghề phù hợp với bản thân sẽ phụ thuộc vào nhiều yếu tố. Mỗi một người sẽ có đặc điểm khác nhau và sẽ phù hợp với ngành nghề khác nhau. Chúng tôi sẽ phân tích chuyên sâu hơn cho các bạn ở những bài sau, các bạn chú ý đón đọc nhé!\r\n', 'Tuyển dụng', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2018-01-23 10:45:28', '2018-01-23 03:45:28', '', 145, 'http://cuongrt.raothue.com/phong/anhduongtaybac/145-revision-v1/', 0, 'revision', '', 0),
(188, 1, '2018-01-23 10:59:44', '2018-01-23 03:59:44', '', 'icon1', '', 'inherit', 'open', 'closed', '', 'icon1', '', '', '2018-01-23 10:59:44', '2018-01-23 03:59:44', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/icon1.png', 0, 'attachment', 'image/png', 0),
(189, 1, '2018-01-23 10:59:54', '2018-01-23 03:59:54', '', 'icon2', '', 'inherit', 'open', 'closed', '', 'icon2', '', '', '2018-01-23 10:59:54', '2018-01-23 03:59:54', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/icon2.png', 0, 'attachment', 'image/png', 0),
(190, 1, '2018-01-23 11:00:06', '2018-01-23 04:00:06', '', 'icon3', '', 'inherit', 'open', 'closed', '', 'icon3', '', '', '2018-01-23 11:00:06', '2018-01-23 04:00:06', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/icon3.png', 0, 'attachment', 'image/png', 0),
(191, 1, '2018-01-23 11:00:18', '2018-01-23 04:00:18', '', 'icon4', '', 'inherit', 'open', 'closed', '', 'icon4', '', '', '2018-01-23 11:00:18', '2018-01-23 04:00:18', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/icon4.png', 0, 'attachment', 'image/png', 0),
(192, 1, '2018-01-23 11:00:31', '2018-01-23 04:00:31', '', 'icon5', '', 'inherit', 'open', 'closed', '', 'icon5', '', '', '2018-01-23 11:00:31', '2018-01-23 04:00:31', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/icon5.png', 0, 'attachment', 'image/png', 0),
(193, 1, '2018-01-23 11:11:40', '2018-01-23 04:11:40', '<div class=\"form-thongtin\"><div class=\"left\">NHẬN THÔNG TIN MIỄN PHÍ</div><div class=\"right\">[email email-853 placeholder \"Nhập email của bạn...\"][submit \"Đăng ký\"]</div></div>\n1\nRT - Aug \"[your-subject]\"\n[your-name] <wordpress@khomaudepraothue.com>\nmailtrunggian01@gmail.com\nNHẬN THÔNG TIN MIỄN PHÍ:[email-853]\r\n\r\nNội dung thông điệp:\r\n[your-message]\r\n\r\n-- \r\nEmail này được gửi đến từ form liên hệ của website RT - Aug (http://cuongrt.raothue.com/phong/anhduongtaybac)\n\n\n\n\n\nRT - Aug \"[your-subject]\"\nRT - Aug <wordpress@cuongrt.raothue.com>\n[your-email]\nNội dung thông điệp:\r\n[your-message]\r\n\r\n-- \r\nEmail này được gửi đến từ form liên hệ của website RT - Aug (http://cuongrt.raothue.com/phong/anhduongtaybac)\nReply-To: mailtrunggian01@gmail.com\n\n\n\nXin cảm ơn, form đã được gửi thành công.\nCó lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\nCó một hoặc nhiều mục nhập có lỗi. Vui lòng kiểm tra và thử lại.\nCó lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\nBạn phải chấp nhận điều khoản trước khi gửi form.\nMục này là bắt buộc.\nNhập quá số kí tự cho phép.\nNhập ít hơn số kí tự tối thiểu.\nĐịnh dạng ngày tháng không hợp lệ.\nNgày này trước ngày sớm nhất được cho phép.\nNgày này quá ngày gần nhất được cho phép.\nTải file lên không thành công.\nBạn không được phép tải lên file theo định dạng này.\nFile kích thước quá lớn.\nTải file lên không thành công.\nĐịnh dạng số không hợp lệ.\nCon số nhỏ hơn số nhỏ nhất cho phép.\nCon số lớn hơn số lớn nhất cho phép.\nCâu trả lời chưa đúng.\nBạn đã nhập sai mã CAPTCHA.\nĐịa chỉ e-mail không hợp lệ.\nURL không hợp lệ.\nSố điện thoại không hợp lệ.', 'form đăng ký', '', 'publish', 'closed', 'closed', '', 'form-dang-ky', '', '', '2018-02-28 14:54:23', '2018-02-28 07:54:23', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/?post_type=wpcf7_contact_form&#038;p=193', 0, 'wpcf7_contact_form', '', 0),
(194, 1, '2018-01-23 15:44:20', '2018-01-23 08:44:20', '', 'doitac1', '', 'inherit', 'open', 'closed', '', 'doitac1', '', '', '2018-01-23 15:44:20', '2018-01-23 08:44:20', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/doitac1.png', 0, 'attachment', 'image/png', 0),
(195, 1, '2018-01-23 15:44:30', '2018-01-23 08:44:30', '', 'doitac2', '', 'inherit', 'open', 'closed', '', 'doitac2', '', '', '2018-01-23 15:44:30', '2018-01-23 08:44:30', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/doitac2.png', 0, 'attachment', 'image/png', 0),
(196, 1, '2018-01-23 15:44:43', '2018-01-23 08:44:43', '', 'doitac3', '', 'inherit', 'open', 'closed', '', 'doitac3', '', '', '2018-01-23 15:44:43', '2018-01-23 08:44:43', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/doitac3.png', 0, 'attachment', 'image/png', 0),
(197, 1, '2018-01-23 15:44:55', '2018-01-23 08:44:55', '', 'doitac4', '', 'inherit', 'open', 'closed', '', 'doitac4', '', '', '2018-01-23 15:44:55', '2018-01-23 08:44:55', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/doitac4.png', 0, 'attachment', 'image/png', 0),
(198, 1, '2018-01-23 15:45:09', '2018-01-23 08:45:09', '', 'doitac5', '', 'inherit', 'open', 'closed', '', 'doitac5', '', '', '2018-01-23 15:45:09', '2018-01-23 08:45:09', '', 0, 'http://cuongrt.raothue.com/phong/anhduongtaybac/wp-content/uploads/2018/01/doitac5.png', 0, 'attachment', 'image/png', 0),
(200, 1, '2018-02-23 15:57:56', '0000-00-00 00:00:00', '', 'Lưu bản nháp tự động', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-02-23 15:57:56', '0000-00-00 00:00:00', '', 0, 'http://khomaudepraothue.com/anhduongtaybac/?p=200', 0, 'post', '', 0),
(201, 1, '2018-03-02 15:36:53', '2018-03-02 08:36:53', '<div class=\"form-dangky\">Giới tính (*):[text* text-915 akismet:author] Họ và tên của bạn (*):[text* text-129 akismet:author] Địa chỉ liên hệ (*):[text* text-224 akismet:author] Trình độ (*):[text* text-225 akismet:author] Điện thoại (*):[tel* tel-86] [submit \"Gửi\"]</div>\n1\nCông ty Cổ Phần và Phát triển Ánh Dương Tây Bắc \"[your-subject]\"\n[your-name] <wordpress@khomaudepraothue.com>\nmailtrunggian01@gmail.com\nGửi đến từ: [your-name] <[your-email]>\r\nTiêu đề: [your-subject]\r\n\r\nNội dung thông điệp:\r\n[your-message]\r\n\r\n-- \r\nEmail này được gửi đến từ form liên hệ của website Công ty Cổ Phần và Phát triển Ánh Dương Tây Bắc (http://khomaudepraothue.com/anhduongtaybac)\nReply-To: [your-email]\n\n\n\n\nCông ty Cổ Phần và Phát triển Ánh Dương Tây Bắc \"[your-subject]\"\nCông ty Cổ Phần và Phát triển Ánh Dương Tây Bắc <wordpress@khomaudepraothue.com>\n[your-email]\nNội dung thông điệp:\r\n[your-message]\r\n\r\n-- \r\nEmail này được gửi đến từ form liên hệ của website Công ty Cổ Phần và Phát triển Ánh Dương Tây Bắc (http://khomaudepraothue.com/anhduongtaybac)\nReply-To: mailtrunggian01@gmail.com\n\n\n\nXin cảm ơn, form đã được gửi thành công.\nCó lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\nCó một hoặc nhiều mục nhập có lỗi. Vui lòng kiểm tra và thử lại.\nCó lỗi xảy ra trong quá trình gửi. Xin vui lòng thử lại hoặc liên hệ người quản trị website.\nBạn phải chấp nhận điều khoản trước khi gửi form.\nMục này là bắt buộc.\nNhập quá số kí tự cho phép.\nNhập ít hơn số kí tự tối thiểu.\nĐịnh dạng ngày tháng không hợp lệ.\nNgày này trước ngày sớm nhất được cho phép.\nNgày này quá ngày gần nhất được cho phép.\nTải file lên không thành công.\nBạn không được phép tải lên file theo định dạng này.\nFile kích thước quá lớn.\nTải file lên không thành công.\nĐịnh dạng số không hợp lệ.\nCon số nhỏ hơn số nhỏ nhất cho phép.\nCon số lớn hơn số lớn nhất cho phép.\nCâu trả lời chưa đúng.\nBạn đã nhập sai mã CAPTCHA.\nĐịa chỉ e-mail không hợp lệ.\nURL không hợp lệ.\nSố điện thoại không hợp lệ.', 'Nộp hồ sơ', '', 'publish', 'closed', 'closed', '', 'nop-ho-so', '', '', '2018-03-02 15:41:00', '2018-03-02 08:41:00', '', 0, 'http://khomaudepraothue.com/anhduongtaybac/?post_type=wpcf7_contact_form&#038;p=201', 0, 'wpcf7_contact_form', '', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_termmeta`
--

CREATE TABLE `rt_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_termmeta`
--

INSERT INTO `rt_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 2, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(27, 24, 'order', '0'),
(28, 24, 'display_type', ''),
(29, 24, 'thumbnail_id', '0'),
(30, 24, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(31, 24, 'product_count_product_cat', '6'),
(32, 25, 'order', '0'),
(33, 25, 'display_type', ''),
(34, 25, 'thumbnail_id', '0'),
(35, 25, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(36, 26, 'order', '0'),
(37, 26, 'display_type', ''),
(38, 26, 'thumbnail_id', '0'),
(39, 26, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(40, 27, 'order', '0'),
(41, 27, 'display_type', ''),
(42, 27, 'thumbnail_id', '0'),
(43, 27, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(44, 28, 'order', '0'),
(45, 28, 'display_type', ''),
(46, 28, 'thumbnail_id', '0'),
(47, 28, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(48, 29, 'order', '0'),
(49, 29, 'display_type', ''),
(50, 29, 'thumbnail_id', '0'),
(51, 29, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(52, 30, 'order', '0'),
(53, 30, 'display_type', ''),
(54, 30, 'thumbnail_id', '78'),
(55, 30, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(56, 31, 'order', '0'),
(57, 31, 'display_type', ''),
(58, 31, 'thumbnail_id', '74'),
(59, 31, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(60, 28, 'product_count_product_cat', '6'),
(61, 29, 'product_count_product_cat', '6'),
(62, 30, 'product_count_product_cat', '6'),
(63, 31, 'product_count_product_cat', '6'),
(64, 27, 'product_count_product_cat', '6'),
(65, 25, 'product_count_product_cat', '6'),
(66, 26, 'product_count_product_cat', '6'),
(67, 32, 'order', '0'),
(68, 32, 'display_type', ''),
(69, 32, 'thumbnail_id', '0'),
(70, 32, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(71, 33, 'order_pa_bao-hanh', '0'),
(72, 34, 'order_pa_mau-sac', '0'),
(73, 35, 'order_pa_noi-san-xuat', '0'),
(74, 36, 'order_pa_thuong-hieu', '0'),
(75, 38, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(76, 39, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(77, 40, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(78, 41, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}'),
(79, 42, 'rt_sidebar', 'a:4:{s:4:\"area\";s:4:\"left\";s:17:\"left_sidebar_name\";s:9:\"sidebar-1\";s:18:\"right_sidebar_name\";s:9:\"sidebar-2\";s:12:\"is_overwrite\";b:0;}');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_terms`
--

CREATE TABLE `rt_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_terms`
--

INSERT INTO `rt_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(2, 'Tin tức', 'tin-tuc', 0),
(3, 'simple', 'simple', 0),
(4, 'grouped', 'grouped', 0),
(5, 'variable', 'variable', 0),
(6, 'external', 'external', 0),
(7, 'exclude-from-search', 'exclude-from-search', 0),
(8, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(9, 'featured', 'featured', 0),
(10, 'outofstock', 'outofstock', 0),
(11, 'rated-1', 'rated-1', 0),
(12, 'rated-2', 'rated-2', 0),
(13, 'rated-3', 'rated-3', 0),
(14, 'rated-4', 'rated-4', 0),
(15, 'rated-5', 'rated-5', 0),
(16, '12', '12', 0),
(22, 'Menu top', 'menu-top', 0),
(23, 'Danh Mục Thị Trường', 'danh-muc-thi-truong', 0),
(24, 'Sản phẩm', 'san-pham', 0),
(25, 'Tranh tường phòng khách', 'tranh-tuong-phong-khach', 0),
(26, 'Tranh tường phòng ngủ', 'tranh-tuong-phong-ngu', 0),
(27, 'Tranh tường phòng bé', 'tranh-tuong-phong-be', 0),
(28, 'Tranh tường café', 'tranh-tuong-cafe', 0),
(29, 'Tranh tường khách sạn', 'tranh-tuong-khach-san', 0),
(30, 'Tranh tường khách sạn khổ lớn', 'tranh-tuong-khach-san-kho-lon', 0),
(31, 'Tranh tường khách sạn khổ nhỏ', 'tranh-tuong-khach-san-kho-nho', 0),
(32, 'Test', 'test', 0),
(33, '12 Tháng', '12-thang', 0),
(34, 'Màu tím', 'mau-tim', 0),
(35, 'Nhật Bản', 'nhat-ban', 0),
(36, 'Việt Nam', 'viet-nam', 0),
(37, 'giới thiệu', 'gioi-thieu', 0),
(38, 'Thị trường Nhật Bản', 'thi-truong-nhat-ban', 0),
(39, 'Thị trường Hàn Quốc', 'thi-truong-han-quoc', 0),
(40, 'Thị trường Châu Á', 'thi-truong-chau-a', 0),
(41, 'Thị trường Châu Âu', 'thi-truong-chau-au', 0),
(42, 'Thị trường khác', 'thi-truong-khac', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_term_relationships`
--

CREATE TABLE `rt_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_term_relationships`
--

INSERT INTO `rt_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(19, 22, 0),
(21, 22, 0),
(53, 16, 0),
(60, 23, 0),
(61, 23, 0),
(81, 2, 0),
(83, 2, 0),
(85, 2, 0),
(87, 2, 0),
(89, 2, 0),
(91, 2, 0),
(93, 2, 0),
(95, 2, 0),
(99, 3, 0),
(99, 24, 0),
(99, 25, 0),
(99, 26, 0),
(99, 27, 0),
(99, 28, 0),
(99, 29, 0),
(99, 30, 0),
(99, 31, 0),
(100, 3, 0),
(100, 24, 0),
(100, 25, 0),
(100, 26, 0),
(100, 27, 0),
(100, 28, 0),
(100, 29, 0),
(100, 30, 0),
(100, 31, 0),
(101, 3, 0),
(101, 24, 0),
(101, 25, 0),
(101, 26, 0),
(101, 27, 0),
(101, 28, 0),
(101, 29, 0),
(101, 30, 0),
(101, 31, 0),
(102, 3, 0),
(102, 24, 0),
(102, 25, 0),
(102, 26, 0),
(102, 27, 0),
(102, 28, 0),
(102, 29, 0),
(102, 30, 0),
(102, 31, 0),
(103, 3, 0),
(103, 24, 0),
(103, 25, 0),
(103, 26, 0),
(103, 27, 0),
(103, 28, 0),
(103, 29, 0),
(103, 30, 0),
(103, 31, 0),
(104, 3, 0),
(104, 15, 0),
(104, 24, 0),
(104, 25, 0),
(104, 26, 0),
(104, 27, 0),
(104, 28, 0),
(104, 29, 0),
(104, 30, 0),
(104, 31, 0),
(104, 33, 0),
(104, 34, 0),
(104, 35, 0),
(104, 36, 0),
(105, 16, 0),
(107, 22, 0),
(110, 22, 0),
(124, 37, 0),
(127, 37, 0),
(128, 37, 0),
(136, 16, 0),
(156, 22, 0),
(157, 22, 0),
(159, 22, 0),
(160, 22, 0),
(161, 23, 0),
(162, 23, 0),
(163, 23, 0),
(164, 23, 0),
(165, 23, 0),
(166, 2, 0),
(166, 38, 0),
(166, 39, 0),
(166, 40, 0),
(166, 41, 0),
(166, 42, 0),
(167, 2, 0),
(167, 38, 0),
(167, 39, 0),
(167, 40, 0),
(167, 41, 0),
(167, 42, 0),
(168, 2, 0),
(168, 38, 0),
(168, 39, 0),
(168, 40, 0),
(168, 41, 0),
(168, 42, 0),
(178, 37, 0),
(179, 37, 0),
(180, 37, 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_term_taxonomy`
--

CREATE TABLE `rt_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_term_taxonomy`
--

INSERT INTO `rt_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(2, 2, 'category', '', 0, 11),
(3, 3, 'product_type', '', 0, 6),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_type', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_visibility', '', 0, 1),
(16, 16, 'ml-slider', '', 0, 3),
(22, 22, 'nav_menu', '', 0, 8),
(23, 23, 'nav_menu', '', 0, 7),
(24, 24, 'product_cat', '', 0, 6),
(25, 25, 'product_cat', '', 0, 6),
(26, 26, 'product_cat', '', 0, 6),
(27, 27, 'product_cat', '', 0, 6),
(28, 28, 'product_cat', '', 0, 6),
(29, 29, 'product_cat', '', 0, 6),
(30, 30, 'product_cat', '', 29, 6),
(31, 31, 'product_cat', '', 29, 6),
(32, 32, 'product_cat', '', 0, 0),
(33, 33, 'pa_bao-hanh', '', 0, 1),
(34, 34, 'pa_mau-sac', '', 0, 1),
(35, 35, 'pa_noi-san-xuat', '', 0, 1),
(36, 36, 'pa_thuong-hieu', '', 0, 1),
(37, 37, 'nav_menu', '', 0, 6),
(38, 38, 'category', '', 0, 3),
(39, 39, 'category', '', 0, 3),
(40, 40, 'category', '', 0, 3),
(41, 41, 'category', '', 0, 3),
(42, 42, 'category', '', 0, 3);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_usermeta`
--

CREATE TABLE `rt_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_usermeta`
--

INSERT INTO `rt_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'adminraothue'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'rt_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(12, 1, 'rt_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', 'black_studio_tinymce_widget'),
(14, 1, 'show_welcome_panel', '0'),
(16, 1, 'rt_user-settings', 'libraryContent=browse&hidetb=1&editor=html'),
(17, 1, 'rt_user-settings-time', '1505664910'),
(18, 1, 'rt_dashboard_quick_press_last_post_id', '200'),
(19, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:12:\"118.70.178.0\";}'),
(20, 1, 'rt_yoast_notifications', 'a:4:{i:0;a:2:{s:7:\"message\";s:561:\"To make sure all the links in your texts are counted, we need to analyze all your texts.\n					All you have to do is press the following button and we\'ll go through all your texts for you.\n					\n					<button type=\"button\" id=\"noticeRunLinkIndex\" class=\"button\">Count links</button>\n					\n					The Text link counter feature provides insights in how many links are found in your text and how many links are referring to your text. This is very helpful when you are improving your <a href=\"https://yoa.st/15m?utm_content=5.0.1\" target=\"_blank\">internal linking</a>.\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:19:\"wpseo-reindex-links\";s:5:\"nonce\";s:10:\"f97bcd1bcd\";s:8:\"priority\";d:0.80000000000000004;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:14:\"manage_options\";s:16:\"capability_check\";s:3:\"all\";}}i:1;a:2:{s:7:\"message\";s:315:\"Yoast SEO and WooCommerce can work together a lot better by adding a helper plugin. Please install Yoast WooCommerce SEO to make your life better. <a href=\"https://yoa.st/1o0?utm_content=7.0.3\" aria-label=\"More information about Yoast WooCommerce SEO\" target=\"_blank\" rel=\"noopener noreferrer\">More information</a>.\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:44:\"wpseo-suggested-plugin-yoast-woocommerce-seo\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:15:\"install_plugins\";}s:16:\"capability_check\";s:3:\"all\";}}i:2;a:2:{s:7:\"message\";s:185:\"Don\'t miss your crawl errors: <a href=\"http://khomaudepraothue.com/anhduongtaybac/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">connect with Google Search Console here</a>.\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";}}i:3;a:2:{s:7:\"message\";s:320:\"You do not have your postname in the URL of your posts and pages, it is highly recommended that you do. Consider setting your permalink structure to <strong>/%postname%/</strong>.<br/>You can fix this on the <a href=\"http://khomaudepraothue.com/anhduongtaybac/wp-admin/options-permalink.php\">Permalink settings page</a>.\";s:7:\"options\";a:8:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:30:\"wpseo-dismiss-permalink-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.80000000000000004;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";}}}'),
(38, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(39, 1, 'metaboxhidden_nav-menus', 'a:6:{i:0;s:21:\"add-post-type-product\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";i:3;s:15:\"add-product_tag\";i:4;s:19:\"menu-icons-settings\";i:5;s:30:\"woocommerce_endpoints_nav_link\";}'),
(40, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(41, 1, 'closedpostboxes_product', 'a:0:{}'),
(42, 1, 'metaboxhidden_product', 'a:2:{i:0;s:10:\"postcustom\";i:1;s:7:\"slugdiv\";}'),
(43, 1, 'meta-box-order_product', 'a:3:{s:4:\"side\";s:95:\"postimagediv,woocommerce-product-images,submitdiv,product_catdiv,tagsdiv-product_tag,rt_sidebar\";s:6:\"normal\";s:66:\"woocommerce-product-data,postcustom,slugdiv,postexcerpt,wpseo_meta\";s:8:\"advanced\";s:0:\"\";}'),
(44, 1, 'screen_layout_product', '2'),
(45, 1, 'manageedit-productcolumnshidden', 'a:6:{i:0;s:11:\"is_in_stock\";i:1;s:8:\"featured\";i:2;s:12:\"product_type\";i:3;s:11:\"wpseo-title\";i:4;s:14:\"wpseo-metadesc\";i:5;s:13:\"wpseo-focuskw\";}'),
(46, 1, 'closedpostboxes_post', 'a:1:{i:0;s:9:\"formatdiv\";}'),
(47, 1, 'metaboxhidden_post', 'a:5:{i:0;s:13:\"trackbacksdiv\";i:1;s:10:\"postcustom\";i:2;s:16:\"commentstatusdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}'),
(48, 1, 'meta-box-order_post', 'a:3:{s:4:\"side\";s:72:\"postimagediv,submitdiv,categorydiv,formatdiv,tagsdiv-post_tag,rt_sidebar\";s:6:\"normal\";s:94:\"wpseo_meta,postexcerpt,trackbacksdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}'),
(49, 1, 'screen_layout_post', '2'),
(68, 1, 'nav_menu_recently_edited', '22'),
(69, 1, '_yoast_wpseo_profile_updated', '1522133027'),
(70, 1, 'wpseo_title', ''),
(71, 1, 'wpseo_metadesc', ''),
(72, 1, 'wpseo_metakey', ''),
(73, 1, 'wpseo_noindex_author', ''),
(74, 1, 'wpseo_content_analysis_disable', ''),
(75, 1, 'wpseo_keyword_analysis_disable', ''),
(76, 1, 'billing_first_name', ''),
(77, 1, 'billing_last_name', ''),
(78, 1, 'billing_company', ''),
(79, 1, 'billing_address_1', ''),
(80, 1, 'billing_address_2', ''),
(81, 1, 'billing_city', ''),
(82, 1, 'billing_postcode', ''),
(83, 1, 'billing_country', ''),
(84, 1, 'billing_state', ''),
(85, 1, 'billing_phone', ''),
(86, 1, 'billing_email', 'mailtrunggian01@gmail.com'),
(87, 1, 'shipping_first_name', ''),
(88, 1, 'shipping_last_name', ''),
(89, 1, 'shipping_company', ''),
(90, 1, 'shipping_address_1', ''),
(91, 1, 'shipping_address_2', ''),
(92, 1, 'shipping_city', ''),
(93, 1, 'shipping_postcode', ''),
(94, 1, 'shipping_country', ''),
(95, 1, 'shipping_state', ''),
(96, 1, 'googleplus', ''),
(97, 1, 'twitter', ''),
(98, 1, 'facebook', ''),
(99, 1, 'last_update', '1522133027'),
(102, 1, 'rt_media_library_mode', 'grid'),
(103, 1, 'wpseo-remove-upsell-notice', '1'),
(104, 1, 'wpseo-reindex-links', 'seen'),
(105, 1, 'wpseo-dismiss-gsc', 'seen'),
(106, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:4:{s:32:\"c9e1074f5b3f9fc8ea15d152add07294\";a:10:{s:3:\"key\";s:32:\"c9e1074f5b3f9fc8ea15d152add07294\";s:10:\"product_id\";i:104;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:4;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:15600000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:15600000;s:8:\"line_tax\";i:0;}s:32:\"ec8956637a99787bd197eacd77acce5e\";a:10:{s:3:\"key\";s:32:\"ec8956637a99787bd197eacd77acce5e\";s:10:\"product_id\";i:102;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:3;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:11700000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:11700000;s:8:\"line_tax\";i:0;}s:32:\"38b3eff8baf56627478ec76a704e9b52\";a:10:{s:3:\"key\";s:32:\"38b3eff8baf56627478ec76a704e9b52\";s:10:\"product_id\";i:101;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:7;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:27300000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:27300000;s:8:\"line_tax\";i:0;}s:32:\"6974ce5ac660610b44d9b9fed0ff9548\";a:10:{s:3:\"key\";s:32:\"6974ce5ac660610b44d9b9fed0ff9548\";s:10:\"product_id\";i:103;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:3900000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:3900000;s:8:\"line_tax\";i:0;}}}'),
(109, 1, 'session_tokens', 'a:1:{s:64:\"34c72f1875cba26ba0662b4703bc253677204e53a09a13412c8fa496f39711fe\";a:4:{s:10:\"expiration\";i:1524035864;s:2:\"ip\";s:14:\"118.70.178.100\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36\";s:5:\"login\";i:1523863064;}}');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_users`
--

CREATE TABLE `rt_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_users`
--

INSERT INTO `rt_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'adminraothue', '$P$BDbOpfswaWGpHWxQYnMfIV7YByxdWr/', 'adminraothue', 'mailtrunggian01@gmail.com', '', '2017-06-15 04:20:37', '', 0, 'adminraothue');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_api_keys`
--

CREATE TABLE `rt_woocommerce_api_keys` (
  `key_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_attribute_taxonomies`
--

CREATE TABLE `rt_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_woocommerce_attribute_taxonomies`
--

INSERT INTO `rt_woocommerce_attribute_taxonomies` (`attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES
(2, 'bao-hanh', 'Bảo hành', 'text', 'menu_order', 0),
(3, 'mau-sac', 'Màu sắc', 'text', 'menu_order', 0),
(4, 'noi-san-xuat', 'Nơi sản xuất', 'text', 'menu_order', 0),
(5, 'thuong-hieu', 'Thương hiệu', 'text', 'menu_order', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_downloadable_product_permissions`
--

CREATE TABLE `rt_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `download_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_log`
--

CREATE TABLE `rt_woocommerce_log` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_order_itemmeta`
--

CREATE TABLE `rt_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_order_items`
--

CREATE TABLE `rt_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_payment_tokenmeta`
--

CREATE TABLE `rt_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `payment_token_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_payment_tokens`
--

CREATE TABLE `rt_woocommerce_payment_tokens` (
  `token_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_sessions`
--

CREATE TABLE `rt_woocommerce_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_woocommerce_sessions`
--

INSERT INTO `rt_woocommerce_sessions` (`session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(40, '1', 'a:7:{s:8:\"customer\";s:675:\"a:25:{s:2:\"id\";i:1;s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"VN\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"VN\";s:13:\"is_vat_exempt\";b:0;s:19:\"calculated_shipping\";b:0;s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:25:\"mailtrunggian01@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";s:4:\"cart\";s:1448:\"a:4:{s:32:\"c9e1074f5b3f9fc8ea15d152add07294\";a:10:{s:3:\"key\";s:32:\"c9e1074f5b3f9fc8ea15d152add07294\";s:10:\"product_id\";i:104;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:4;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:15600000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:15600000;s:8:\"line_tax\";i:0;}s:32:\"ec8956637a99787bd197eacd77acce5e\";a:10:{s:3:\"key\";s:32:\"ec8956637a99787bd197eacd77acce5e\";s:10:\"product_id\";i:102;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:3;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:11700000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:11700000;s:8:\"line_tax\";i:0;}s:32:\"38b3eff8baf56627478ec76a704e9b52\";a:10:{s:3:\"key\";s:32:\"38b3eff8baf56627478ec76a704e9b52\";s:10:\"product_id\";i:101;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:7;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:27300000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:27300000;s:8:\"line_tax\";i:0;}s:32:\"6974ce5ac660610b44d9b9fed0ff9548\";a:10:{s:3:\"key\";s:32:\"6974ce5ac660610b44d9b9fed0ff9548\";s:10:\"product_id\";i:103;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:3900000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:3900000;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:408:\"a:15:{s:8:\"subtotal\";s:8:\"58500000\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:1:\"0\";s:12:\"shipping_tax\";d:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";d:0;s:12:\"discount_tax\";d:0;s:19:\"cart_contents_total\";s:8:\"58500000\";s:17:\"cart_contents_tax\";d:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:1:\"0\";s:7:\"fee_tax\";d:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:8:\"58500000\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";}', 1520152007);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_shipping_zones`
--

CREATE TABLE `rt_woocommerce_shipping_zones` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_shipping_zone_locations`
--

CREATE TABLE `rt_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_shipping_zone_methods`
--

CREATE TABLE `rt_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `instance_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) UNSIGNED NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_tax_rates`
--

CREATE TABLE `rt_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT 0,
  `tax_rate_shipping` int(1) NOT NULL DEFAULT 1,
  `tax_rate_order` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_woocommerce_tax_rate_locations`
--

CREATE TABLE `rt_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_yoast_seo_links`
--

CREATE TABLE `rt_yoast_seo_links` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `target_post_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rt_yoast_seo_meta`
--

CREATE TABLE `rt_yoast_seo_meta` (
  `object_id` bigint(20) UNSIGNED NOT NULL,
  `internal_link_count` int(10) UNSIGNED DEFAULT NULL,
  `incoming_link_count` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rt_yoast_seo_meta`
--

INSERT INTO `rt_yoast_seo_meta` (`object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(8, 0, 0),
(9, 0, 0),
(10, 0, 0),
(20, 0, 0),
(22, 0, 0),
(81, 0, 0),
(83, 0, 0),
(85, 0, 0),
(87, 0, 0),
(89, 0, 0),
(91, 0, 0),
(93, 0, 0),
(95, 0, 0),
(97, 0, 0),
(99, 0, 0),
(100, 0, 0),
(101, 0, 0),
(102, 0, 0),
(103, 0, 0),
(104, 0, 0),
(113, 0, 0),
(114, 0, 0),
(115, 0, 0),
(116, 0, 0),
(118, 0, 0),
(119, 0, 0),
(121, 0, 0),
(122, 0, 0),
(123, 0, 0),
(125, 0, 0),
(126, 0, 0),
(130, 0, 0),
(132, 0, 0),
(137, 0, 0),
(138, 0, 0),
(140, 0, 0),
(143, 0, 0),
(144, 0, 0),
(145, 0, 0),
(147, 0, 0),
(148, 0, 0),
(149, 0, 0),
(150, 0, 0),
(152, 0, 0),
(154, 0, 0),
(158, 0, 0),
(166, 0, 0),
(167, 0, 0),
(168, 0, 0),
(176, 0, 0),
(199, 0, 0),
(202, 0, 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `rt_commentmeta`
--
ALTER TABLE `rt_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Chỉ mục cho bảng `rt_comments`
--
ALTER TABLE `rt_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Chỉ mục cho bảng `rt_cpd_counter`
--
ALTER TABLE `rt_cpd_counter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_dateip` (`date`,`ip`),
  ADD KEY `idx_page` (`page`);

--
-- Chỉ mục cho bảng `rt_links`
--
ALTER TABLE `rt_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Chỉ mục cho bảng `rt_options`
--
ALTER TABLE `rt_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Chỉ mục cho bảng `rt_postmeta`
--
ALTER TABLE `rt_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Chỉ mục cho bảng `rt_posts`
--
ALTER TABLE `rt_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Chỉ mục cho bảng `rt_termmeta`
--
ALTER TABLE `rt_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Chỉ mục cho bảng `rt_terms`
--
ALTER TABLE `rt_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Chỉ mục cho bảng `rt_term_relationships`
--
ALTER TABLE `rt_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Chỉ mục cho bảng `rt_term_taxonomy`
--
ALTER TABLE `rt_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Chỉ mục cho bảng `rt_usermeta`
--
ALTER TABLE `rt_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Chỉ mục cho bảng `rt_users`
--
ALTER TABLE `rt_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Chỉ mục cho bảng `rt_woocommerce_api_keys`
--
ALTER TABLE `rt_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Chỉ mục cho bảng `rt_woocommerce_attribute_taxonomies`
--
ALTER TABLE `rt_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Chỉ mục cho bảng `rt_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `rt_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Chỉ mục cho bảng `rt_woocommerce_log`
--
ALTER TABLE `rt_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Chỉ mục cho bảng `rt_woocommerce_order_itemmeta`
--
ALTER TABLE `rt_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Chỉ mục cho bảng `rt_woocommerce_order_items`
--
ALTER TABLE `rt_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Chỉ mục cho bảng `rt_woocommerce_payment_tokenmeta`
--
ALTER TABLE `rt_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Chỉ mục cho bảng `rt_woocommerce_payment_tokens`
--
ALTER TABLE `rt_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Chỉ mục cho bảng `rt_woocommerce_sessions`
--
ALTER TABLE `rt_woocommerce_sessions`
  ADD PRIMARY KEY (`session_key`),
  ADD UNIQUE KEY `session_id` (`session_id`);

--
-- Chỉ mục cho bảng `rt_woocommerce_shipping_zones`
--
ALTER TABLE `rt_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Chỉ mục cho bảng `rt_woocommerce_shipping_zone_locations`
--
ALTER TABLE `rt_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Chỉ mục cho bảng `rt_woocommerce_shipping_zone_methods`
--
ALTER TABLE `rt_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Chỉ mục cho bảng `rt_woocommerce_tax_rates`
--
ALTER TABLE `rt_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Chỉ mục cho bảng `rt_woocommerce_tax_rate_locations`
--
ALTER TABLE `rt_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Chỉ mục cho bảng `rt_yoast_seo_links`
--
ALTER TABLE `rt_yoast_seo_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `link_direction` (`post_id`,`type`);

--
-- Chỉ mục cho bảng `rt_yoast_seo_meta`
--
ALTER TABLE `rt_yoast_seo_meta`
  ADD UNIQUE KEY `object_id` (`object_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `rt_commentmeta`
--
ALTER TABLE `rt_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `rt_comments`
--
ALTER TABLE `rt_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `rt_cpd_counter`
--
ALTER TABLE `rt_cpd_counter`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=469;

--
-- AUTO_INCREMENT cho bảng `rt_links`
--
ALTER TABLE `rt_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_options`
--
ALTER TABLE `rt_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2867;

--
-- AUTO_INCREMENT cho bảng `rt_postmeta`
--
ALTER TABLE `rt_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1314;

--
-- AUTO_INCREMENT cho bảng `rt_posts`
--
ALTER TABLE `rt_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=203;

--
-- AUTO_INCREMENT cho bảng `rt_termmeta`
--
ALTER TABLE `rt_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT cho bảng `rt_terms`
--
ALTER TABLE `rt_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT cho bảng `rt_term_taxonomy`
--
ALTER TABLE `rt_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT cho bảng `rt_usermeta`
--
ALTER TABLE `rt_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT cho bảng `rt_users`
--
ALTER TABLE `rt_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_api_keys`
--
ALTER TABLE `rt_woocommerce_api_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_attribute_taxonomies`
--
ALTER TABLE `rt_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `rt_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_log`
--
ALTER TABLE `rt_woocommerce_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_order_itemmeta`
--
ALTER TABLE `rt_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_order_items`
--
ALTER TABLE `rt_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_payment_tokenmeta`
--
ALTER TABLE `rt_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_payment_tokens`
--
ALTER TABLE `rt_woocommerce_payment_tokens`
  MODIFY `token_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_sessions`
--
ALTER TABLE `rt_woocommerce_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_shipping_zones`
--
ALTER TABLE `rt_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_shipping_zone_locations`
--
ALTER TABLE `rt_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_shipping_zone_methods`
--
ALTER TABLE `rt_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_tax_rates`
--
ALTER TABLE `rt_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_woocommerce_tax_rate_locations`
--
ALTER TABLE `rt_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `rt_yoast_seo_links`
--
ALTER TABLE `rt_yoast_seo_links`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
